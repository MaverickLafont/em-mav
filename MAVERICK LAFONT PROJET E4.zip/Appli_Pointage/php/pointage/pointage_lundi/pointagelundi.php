<?php
session_start('cegelec');
include "../../connexion.php";
$Session_login = !empty($_SESSION['username'])?$_SESSION['username']:NULL;

//on met la requête dans une variable ($sql)
  $sql = "SELECT * FROM employe WHERE username = '$Session_login' ";

  // on execute la requete :
  $resultat = mysqli_query ($cx, $sql) or die('Erreur SQL !<br>'.$sql.'<br>'.mysql_error());
  // retourne un tableau qui contient la première ligne de $resultat
  $data = mysqli_fetch_array($resultat);

  mysqli_free_result ($resultat);
  mysqli_close ($cx);

#affaire
$affairelundi=$_POST['affairelundi'];
$heuresaffairelundi=$_POST['heuresaffairelundi'];

$affairelundi2=$_POST['affairelundi2'];
$heuresaffairelundi2=$_POST['heuresaffairelundi2'];

$affairelundi3=$_POST['affairelundi3'];
$heuresaffairelundi3=$_POST['heuresaffairelundi3'];

$affairelundi4=$_POST['affairelundi4'];
$heuresaffairelundi4=$_POST['heuresaffairelundi4'];

$affairelundi5=$_POST['affairelundi5'];
$heuresaffairelundi5=$_POST['heuresaffairelundi5'];

$affairelundi6=$_POST['affairelundi6'];
$heuresaffairelundi6=$_POST['heuresaffairelundi6'];

$affairelundi7=$_POST['affairelundi7'];
$heuresaffairelundi7=$_POST['heuresaffairelundi7'];


#prime
#heures
$heuresnuitlundi=$_POST['heuresnuitlundi'];
$heuresdiverslundi=$_POST['heuresdiverslundi'];
$heureschefequipelundi=$_POST['heureschefequipelundi'];
$heureshauteurmlundi=$_POST['heureshauteurmlundi'];
$heuresfourlundi=$_POST['heuresfourlundi'];
$heureschaleurlundi=$_POST['heureschaleurlundi'];
$heuresinsalubritelundi=$_POST['heuresinsalubritelundi'];
#montant
$montanttempsvoyagelundi=$_POST['montanttempsvoyagelundi'];
$montantchauffeurlundi=$_POST['montantchauffeurlundi'];
$montantdeplacementlundi=$_POST['montantdeplacementlundi'];
$primepanier=$_POST['primepanier'];

#absence journée
$absencej=$_POST['absencej'];

#absence heure
$delegation=$_POST['delegation'];
$visite_medicale=$_POST['visite_medicale'];
$formation=$_POST['formation'];

#date
$date_debut = $_GET['date'];
#semaine
$semaine = date('W', strtotime($date_debut));

if(count($data)>0){ 
  $matricule=$data["matricule"];
}

#requette sql insertion de données dans la base
include "../../connexion.php";

if(empty($heuresaffairelundi) and (empty($affairelundi) and (!empty($absencej) Or (!empty($delegation) Or (!empty($visite_medicale) Or (!empty($formation))))))) {
  $req="insert into pointage_affaire(employe_matricule_affaire,date_affaire,S,absencej,delegation,visite_medicale,formation) 
  values('$matricule','".$date_debut."','".$semaine."','".$absencej."','".$delegation."','".$visite_medicale."','".$formation."');";
$res=mysqli_query($cx,$req);
}
else {
    header('location: formpointagelundi.php?enregistrer=0.php&date='.$date_debut);
}
if(isset($res))
{
header('location: ../../employe/mainpage.php?enregistrer=1.php&date='.$date_debut);
}

if(!empty($heuresaffairelundi) and (empty($affairelundi))){
  header('location: formpointagelundi.php?enregistrer=0.php&date='.$date_debut);
}
if(empty($heuresaffairelundi) and (!empty($affairelundi))){
  header('location: formpointagelundi.php?enregistrer=0.php&date='.$date_debut);
}

$heureTotal = $heuresaffairelundi + $heuresaffairelundi2 + $heuresaffairelundi3 + $heuresaffairelundi4 + $heuresaffairelundi5 + $heuresaffairelundi6 + $heuresaffairelundi7;
if($heureTotal > 10){
  header('location: ../../employe/mainpage.php?heure=0.php&date='.$date_debut);
  $res1 = null;
} 
else {

    if(!empty($heuresaffairelundi) and (!empty($affairelundi))){
      $req1="insert into pointage_affaire(employe_matricule_affaire,date_affaire,S,numero_affaire,heure_affaire,prime_nuit,prime_divers,prime_chef_equipe,prime_hauteurM,prime_four,prime_chaleur,prime_insalubrite,prime_temps_voyage,prime_chauffeur,prime_panier,prime_deplacement,absencej,delegation,visite_medicale,formation)
      values('$matricule','".$date_debut."','".$semaine."','".$affairelundi."','".$heuresaffairelundi."','".$heuresnuitlundi."','".$heuresdiverslundi."','".$heureschefequipelundi."','".$heureshauteurmlundi."','".$heuresfourlundi."','".$heureschaleurlundi."','".$heuresinsalubritelundi."'
      ,'".$montanttempsvoyagelundi."','".$montantchauffeurlundi."','".$primepanier."','".$montantdeplacementlundi."','".$absencej."','".$delegation."','".$visite_medicale."','".$formation."');";
    $res1=mysqli_query($cx,$req1);
    }

    if(!empty($heuresaffairelundi2) and (!empty($affairelundi2))){
          $req2="insert into pointage_affaire(employe_matricule_affaire,date_affaire,S,numero_affaire,heure_affaire)
      values('$matricule','".$date_debut."','".$semaine."','".$affairelundi2."','".$heuresaffairelundi2."');";
      $res2=mysqli_query($cx,$req2);
        }

    if(!empty($heuresaffairelundi3) and (!empty($affairelundi3))){
      $req3="insert into pointage_affaire(employe_matricule_affaire,date_affaire,S,numero_affaire,heure_affaire) 
  values('$matricule','".$date_debut."','".$semaine."','".$affairelundi3."','".$heuresaffairelundi3."');";
  $res3=mysqli_query($cx,$req3);
    }

    if(!empty($heuresaffairelundi4) and (!empty($affairelundi4))){
      $req4="insert into pointage_affaire(employe_matricule_affaire,date_affaire,S,numero_affaire,heure_affaire) 
  values('$matricule','".$date_debut."','".$semaine."','".$affairelundi4."','".$heuresaffairelundi4."');";
  $res4=mysqli_query($cx,$req4);
    }
    
    if(!empty($heuresaffairelundi5) and (!empty($affairelundi5))){
      $req5="insert into pointage_affaire(employe_matricule_affaire,date_affaire,S,numero_affaire,heure_affaire) 
  values('$matricule','".$date_debut."','".$semaine."','".$affairelundi5."','".$heuresaffairelundi5."');";
  $res5=mysqli_query($cx,$req5);
    }

    if(!empty($heuresaffairelundi6) and (!empty($affairelundi6))){
      $req6="insert into pointage_affaire(employe_matricule_affaire,date_affaire,S,numero_affaire,heure_affaire) 
  values('$matricule','".$date_debut."','".$semaine."','".$affairelundi6."','".$heuresaffairelundi6."');";
  $res6=mysqli_query($cx,$req6);
    }

    if(!empty($heuresaffairelundi7) and (!empty($affairelundi7))){
      $req7="insert into pointage_affaire(employe_matricule_affaire,date_affaire,S,numero_affaire,heure_affaire) 
  values('$matricule','".$date_debut."','".$semaine."','".$affairelundi7."','".$heuresaffairelundi7."');";
  $res7=mysqli_query($cx,$req7);
    }
}

if($res1)
{
  header('location: ../../employe/mainpage.php?enregistrer=1.php&date='.$date_debut);
}
?>