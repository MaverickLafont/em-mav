<?php
session_start('cegelec');
include "../../connexion.php";
$Session_login = !empty($_SESSION['username'])?$_SESSION['username']:NULL;

//on met la requête dans une variable ($sql)
  $sql = "SELECT * FROM employe WHERE username = '$Session_login' ";

  // on execute la requete :
  $resultat = mysqli_query ($cx, $sql) or die('Erreur SQL !<br>'.$sql.'<br>'.mysql_error());
  // retourne un tableau qui contient la première ligne de $resultat
  $data = mysqli_fetch_array($resultat);

  if(count($data)>0){ 
    $matricule=$data["matricule"];
  }

$date_debut = $_GET['date'];
$semaine = date('W', strtotime($date_debut));

$rq="select * from pointage_affaire where date_affaire='$date_debut' AND employe_matricule_affaire='$matricule';";
$rs = mysqli_query($cx,$rq) or die('Erreur SQL !<br>'.$rq.'<br>'.mysql_error());
          if(empty($rs)){$l = null;} else {$i = 0; while ($l = mysqli_fetch_array($rs)){$tab_affaire[$i] = $l; $i++;}}
          if(isset($tab_affaire[0])) {$tab_affaire[0] = $tab_affaire[0];} else {$tab_affaire[0] = null;}
          if(isset($tab_affaire[1])) {$tab_affaire[1] = $tab_affaire[1];} else {$tab_affaire[1] = null;}
          if(isset($tab_affaire[2])) {$tab_affaire[2] = $tab_affaire[2];} else {$tab_affaire[2] = null;}
          if(isset($tab_affaire[3])) {$tab_affaire[3] = $tab_affaire[3];} else {$tab_affaire[3] = null;}
          if(isset($tab_affaire[4])) {$tab_affaire[4] = $tab_affaire[4];} else {$tab_affaire[4] = null;}
          if(isset($tab_affaire[5])) {$tab_affaire[5] = $tab_affaire[5];} else {$tab_affaire[5] = null;}
          if(isset($tab_affaire[6])) {$tab_affaire[6] = $tab_affaire[6];} else {$tab_affaire[6] = null;}
?>
<html>
  <head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="pointage_lundi.css"> 	
    <link rel="stylesheet" media="handheld" type="text/css" title="mobile" href="../css/mobile.css" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">
<title>Afficher / modifier</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">
  </head>

  <body>
  <nav class="site-header  navbar navbar-dark bg-dark">
          <div class="container d-flex flex-column flex-md-row justify-content-between">
            <input type="button" class="btn btn btn-outline-light"  style="margin-left:25%; width:50%;" value="Retour" onclick="javascript:location.href='../../employe/mainpage.php?date=<?php echo $date_debut;?>'" >     
          </div>
        </nav>
        <?php
         
echo "<form method='POST' action='modifaffairelundi.php?date=$date_debut'>";
   #div de début de la carte affaire
   echo "<div class='row'>";
   echo "<div class='col-sm-6'>";
     echo "<div class='card bg-light mb-3'>";
     echo "<div class='card-header' style='text-align:center;'><h1>Affaires</h1></div>";
       echo "<div class='card-body'>";
#AFFAIRE 1
#NUMERO AFFAIRE 1
$req1="select * from affaire;";
$res1=mysqli_query($cx,$req1);

if ($tab_affaire[0]['numero_affaire'] == 0) {$reponseaucun1 = "Aucune affaire enregistrée"; echo "<input type='hidden' name='ancien_numero_affaire1' value='0'></input> "; echo "<input type='hidden' name='ancien_heure_affaire1'  value='0'></input> ";} 
 if (!empty($tab_affaire[0]['numero_affaire'])) {
  $reponseaucun1= $tab_affaire[0]['numero_affaire'];
  echo "<input type='hidden' name='ancien_numero_affaire1'  value='".$tab_affaire[0]['numero_affaire']."'></input> ";
  echo "<input type='hidden' name='ancien_heure_affaire1'  value='".$tab_affaire[0]['heure_affaire']."'></input> ";
 }
if(isset($res1))
{
  echo "<span class='badge badge-dark' style='margin-left:42.8%;  width: 120px;'>N°1</span>";
  echo  "<div class='form-group'>";
  echo "<label for='exampleFormControlSelect1'></label>";
  echo "<select style='text-align: center;' name='numero_affaire1' class='custom-select' id='selectaffairelundi'>";
  
  $ligne=mysqli_fetch_array($res1);
  echo "<option value ='".$tab_affaire[0]['numero_affaire']."'> ".$reponseaucun1." </option>";
while($ligne!=false)
{

  echo "<option value ='".$ligne['num_affaire']."'> ".$ligne['num_affaire']." & ".$ligne['designation']." & matricule RA: ".$ligne['matricule']."</option>";
  $ligne=mysqli_fetch_array($res1);
}
echo "</select><br/>";
}
  echo "</div>";

#HEURE AFFAIRE 1  
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend'>";
    echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
    echo "</div>"; 
  echo "<input type='number'  step='0.5'  name='heure_affaire1' value='".$tab_affaire[0]['heure_affaire']."'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
echo "</div>";     
echo "<hr class='my-4'>";
######################################################################################################################################################################
#AFFAIRE 2
#NUMERO AFFAIRE 2
$req2="select * from affaire;";
$res2=mysqli_query($cx,$req2);

if ($tab_affaire[1]['numero_affaire'] == 0) {$reponseaucun2 = "Aucune affaire enregistrée"; echo "<input type='hidden' name='ancien_numero_affaire2' value='0'></input> "; echo "<input type='hidden' name='ancien_heure_affaire2'  value='0'></input> ";}  
 if (!empty($tab_affaire[1]['numero_affaire'])) {
  $reponseaucun2= $tab_affaire[1]['numero_affaire'];
  echo "<input type='hidden' name='ancien_numero_affaire2'  value='".$tab_affaire[1]['numero_affaire']."'></input> ";
  echo "<input type='hidden' name='ancien_heure_affaire2'  value='".$tab_affaire[1]['heure_affaire']."'></input> ";
 }

if(isset($res2))
{
  echo "<span class='badge badge-dark' style='margin-left:42.8%;  width: 120px;'>N°2</span>";
  echo  "<div class='form-group'>";
  echo "<label for='exampleFormControlSelect1'></label>";
  echo "<select style='text-align: center;' name='numero_affaire2' class='custom-select' id='selectaffairelundi'>";
  
  $ligne=mysqli_fetch_array($res2);
  echo "<option value ='".$tab_affaire[1]['numero_affaire']."'> ".$reponseaucun2." </option>";
while($ligne!=false)
{

  echo "<option value ='".$ligne['num_affaire']."'> ".$ligne['num_affaire']." & ".$ligne['designation']." & matricule RA: ".$ligne['matricule']."</option>";
  $ligne=mysqli_fetch_array($res2);
}
echo "</select><br/>";
}
  echo "</div>";

#HEURE AFFAIRE 2 
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend'>";
    echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
    echo "</div>"; 
  echo "<input type='number'  step='0.5'  name='heure_affaire2' value='".$tab_affaire[1]['heure_affaire']."' style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
echo "</div>";     

echo "<hr class='my-4'>";
######################################################################################################################################################################

#AFFAIRE 3
#NUMERO AFFAIRE 3
$req3="select * from affaire;";
$res3=mysqli_query($cx,$req3);

if ($tab_affaire[2]['numero_affaire'] == 0) {$reponseaucun3 = "Aucune affaire enregistrée"; echo "<input type='hidden' name='ancien_numero_affaire3' value='0'></input> "; echo "<input type='hidden' name='ancien_heure_affaire3'  value='0'></input> ";} 
 if (!empty($tab_affaire[2]['numero_affaire'])) {
  $reponseaucun3= $tab_affaire[2]['numero_affaire'];
  echo "<input type='hidden' name='ancien_numero_affaire3'  value='".$tab_affaire[2]['numero_affaire']."'></input> ";
  echo "<input type='hidden' name='ancien_heure_affaire3'  value='".$tab_affaire[2]['heure_affaire']."'></input> ";
 }

if(isset($res3))
{
  echo "<span class='badge badge-dark' style='margin-left:42.8%;  width: 120px;'>N°3</span>";
  echo  "<div class='form-group'>";
  echo "<label for='exampleFormControlSelect1'></label>";
  echo "<select style='text-align: center;' name='numero_affaire3' class='custom-select' id='selectaffairelundi'>";
  
  $ligne=mysqli_fetch_array($res3);
  echo "<option value ='".$l['numero_affaire3']."'> ".$reponseaucun3." </option>";
while($ligne!=false)
{

  echo "<option value ='".$ligne['num_affaire']."'> ".$ligne['num_affaire']." & ".$ligne['designation']." & matricule RA: ".$ligne['matricule']."</option>";
  $ligne=mysqli_fetch_array($res3);
}
echo "</select><br/>";
}
  echo "</div>";

#HEURE AFFAIRE 3
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend'>";
    echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
    echo "</div>"; 
  echo "<input type='number'  step='0.5'  name='heure_affaire3' value='".$tab_affaire[2]['heure_affaire']."'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
echo "</div>";     

echo "<hr class='my-4'>";
######################################################################################################################################################################

#AFFAIRE 4
#NUMERO AFFAIRE 4
$req4="select * from affaire;";
$res4=mysqli_query($cx,$req4);

if ($tab_affaire[3]['numero_affaire'] == 0) {$reponseaucun4 = "Aucune affaire enregistrée"; echo "<input type='hidden' name='ancien_numero_affaire4' value='0'></input> "; echo "<input type='hidden' name='ancien_heure_affaire4'  value='0'></input> ";} 
 if (!empty($tab_affaire[3]['numero_affaire'])) {
  $reponseaucun4= $tab_affaire[3]['numero_affaire'];
  echo "<input type='hidden' name='ancien_numero_affaire4'  value='".$tab_affaire[3]['numero_affaire']."'></input> ";
  echo "<input type='hidden' name='ancien_heure_affaire4'  value='".$tab_affaire[3]['heure_affaire']."'></input> ";
 }

if(isset($res4))
{
  echo "<span class='badge badge-dark' style='margin-left:42.8%;  width: 120px;'>N°4</span>";
  echo  "<div class='form-group'>";
  echo "<label for='exampleFormControlSelect1'></label>";
  echo "<select style='text-align: center;' name='numero_affaire4' class='custom-select' id='selectaffairelundi'>";
  
  $ligne=mysqli_fetch_array($res4);
  echo "<option value ='".$tab_affaire[3]['numero_affaire']."'> ".$reponseaucun4." </option>";
while($ligne!=false)
{

  echo "<option value ='".$ligne['num_affaire']."'> ".$ligne['num_affaire']." & ".$ligne['designation']." & matricule RA: ".$ligne['matricule']."</option>";
  $ligne=mysqli_fetch_array($res4);
}
echo "</select><br/>";
}
  echo "</div>";

#HEURE AFFAIRE 4
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend'>";
    echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
    echo "</div>"; 
  echo "<input type='number'  step='0.5'  name='heure_affaire4' value='".$tab_affaire[3]['heure_affaire']."'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
echo "</div>";     

echo "<hr class='my-4'>";
######################################################################################################################################################################

#AFFAIRE 5
#NUMERO AFFAIRE 5
$req5="select * from affaire;";
$res5=mysqli_query($cx,$req5);

if ($tab_affaire[4]['numero_affaire'] == 0) {$reponseaucun5 = "Aucune affaire enregistrée"; echo "<input type='hidden' name='ancien_numero_affaire5' value='0'></input> "; echo "<input type='hidden' name='ancien_heure_affaire5'  value='0'></input> ";} 
 if (!empty($tab_affaire[4]['numero_affaire'])) {
  $reponseaucun5= $tab_affaire[4]['numero_affaire'];
  echo "<input type='hidden' name='ancien_numero_affaire5'  value='".$tab_affaire[4]['numero_affaire']."'></input> ";
  echo "<input type='hidden' name='ancien_heure_affaire5'  value='".$tab_affaire[4]['heure_affaire']."'></input> ";
 }

if(isset($res5))
{
  echo "<span class='badge badge-dark' style='margin-left:42.8%;  width: 120px;'>N°5</span>";
  echo  "<div class='form-group'>";
  echo "<label for='exampleFormControlSelect1'></label>";
  echo "<select style='text-align: center;' name='numero_affaire5' class='custom-select' id='selectaffairelundi'>";
  
  $ligne=mysqli_fetch_array($res5);
  echo "<option value ='".$tab_affaire[4]['numero_affaire']."'> ".$reponseaucun5." </option>";
while($ligne!=false)
{

  echo "<option value ='".$ligne['num_affaire']."'> ".$ligne['num_affaire']." & ".$ligne['designation']." & matricule RA: ".$ligne['matricule']."</option>";
  $ligne=mysqli_fetch_array($res5);
}
echo "</select><br/>";
}
  echo "</div>";

#HEURE AFFAIRE 5
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend'>";
    echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
    echo "</div>"; 
  echo "<input type='number'  step='0.5'  name='heure_affaire5' value='".$tab_affaire[4]['heure_affaire']."'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
echo "</div>";     

echo "<hr class='my-4'>";
######################################################################################################################################################################

#AFFAIRE 6
#NUMERO AFFAIRE 6
$req6="select * from affaire;";
$res6=mysqli_query($cx,$req6);

if ($tab_affaire[5]['numero_affaire'] == 0) {$reponseaucun6 = "Aucune affaire enregistrée"; echo "<input type='hidden' name='ancien_numero_affaire6' value='0'></input> "; echo "<input type='hidden' name='ancien_heure_affaire6'  value='0'></input> ";} 
 if (!empty($tab_affaire[5]['numero_affaire'])) {
  $reponseaucun5= $tab_affaire[5]['numero_affaire'];
  echo "<input type='hidden' name='ancien_numero_affaire6'  value='".$tab_affaire[5]['numero_affaire']."'></input> ";
  echo "<input type='hidden' name='ancien_heure_affaire6'  value='".$tab_affaire[5]['heure_affaire']."'></input> ";
 }

if(isset($res6))
{
  echo "<span class='badge badge-dark' style='margin-left:42.8%;  width: 120px;'>N°6</span>";
  echo  "<div class='form-group'>";
  echo "<label for='exampleFormControlSelect1'></label>";
  echo "<select style='text-align: center;' name='numero_affaire6' class='custom-select' id='selectaffairelundi'>";
  
  $ligne=mysqli_fetch_array($res6);
  echo "<option value ='".$tab_affaire[5]['numero_affaire']."'> ".$reponseaucun6." </option>";
while($ligne!=false)
{

  echo "<option value ='".$ligne['num_affaire']."'> ".$ligne['num_affaire']." & ".$ligne['designation']." & matricule RA: ".$ligne['matricule']."</option>";
  $ligne=mysqli_fetch_array($res6);
}
echo "</select><br/>";
}
  echo "</div>";

#HEURE AFFAIRE 6
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend'>";
    echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
    echo "</div>"; 
  echo "<input type='number'  step='0.5'  name='heure_affaire6' value='".$tab_affaire[5]['heure_affaire']."' style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
echo "</div>";     

echo "<hr class='my-4'>";
######################################################################################################################################################################

#AFFAIRE 7
#NUMERO AFFAIRE 7
$req7="select * from affaire;";
$res7=mysqli_query($cx,$req7);

if ($tab_affaire[6]['numero_affaire'] == 0) {$reponseaucun7 = "Aucune affaire enregistrée"; echo "<input type='hidden' name='ancien_numero_affaire7' value='0'></input> "; echo "<input type='hidden' name='ancien_heure_affaire7' value='0'></input> ";} 
 if (!empty($tab_affaire[6]['numero_affaire'])) {
  $reponseaucun5= $tab_affaire[6]['numero_affaire'];
  echo "<input type='hidden' name='ancien_numero_affaire7'  value='".$tab_affaire[6]['numero_affaire']."'></input> ";
  echo "<input type='hidden' name='ancien_heure_affaire7'  value='".$tab_affaire[6]['heure_affaire']."'></input> ";
 }

if(isset($res7))
{
  echo "<span class='badge badge-dark' style='margin-left:42.8%;  width: 120px;'>N°7</span>";
  echo  "<div class='form-group'>";
  echo "<label for='exampleFormControlSelect1'></label>";
  echo "<select style='text-align: center;' name='numero_affaire7' class='custom-select' id='selectaffairelundi'>";
  
  $ligne=mysqli_fetch_array($res7);
  echo "<option value ='".$tab_affaire[6]['numero_affaire']."'> ".$reponseaucun7." </option>";
while($ligne!=false)
{

  echo "<option value ='".$ligne['num_affaire']."'> ".$ligne['num_affaire']." & ".$ligne['designation']." & matricule RA: ".$ligne['matricule']."</option>";
  $ligne=mysqli_fetch_array($res7);
}
echo "</select><br/>";
}
  echo "</div>";

#HEURE AFFAIRE 7
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend' >";
    echo "<span class='input-group-text' style='width: 125px; text-align: center; margin-bottom: 41.2px;'>Heures</span>";
    echo "</div>"; 
  echo "<input type='number'  step='0.5'  name='heure_affaire7' value='".$tab_affaire[6]['heure_affaire']."'  style='text-indent: 41.5%; margin-bottom: 41.2px;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
echo "</div>";     

######################################################################################################################################################################

#div de fin de la carte affaire
echo "</div>";
echo "</div>";
echo "</div>";

######################################################################################################################################################################
#div de début de la carte prime
echo "<div class='col-sm-6'>";
echo "<div class='card bg-light mb-3'>";
echo "<div class='card-header' style='text-align:center;'><h1>Primes</h1></div>";
  echo "<div class='card-body'>";

#PRIME NUIT
  echo "<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>NUIT</span>";    
  echo "<div class='input-group mb-3'>";
    echo "<div class='input-group-prepend'>";
      echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
      echo "</div>"; 
    echo "<input type='number'  step='0.5'  name='prime_nuit'  value='".$tab_affaire[0]['prime_nuit']."'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
  echo "</div>";     
  
  echo "<hr class='my-4'>";


#PRIME DIVERS
  echo "<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>DIVERS</span>";    
  echo "<div class='input-group mb-3'>";
    echo "<div class='input-group-prepend'>";
      echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
      echo "</div>"; 
    echo "<input type='number'  step='0.5'  name='prime_divers'  value='".$tab_affaire[0]['prime_divers']."'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
  echo "</div>";     
  
  echo "<hr class='my-4'>";

 #PRIME CHEF DEQUIPE
  echo "<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>CHEF D'EQUIPE</span>";    
  echo "<div class='input-group mb-3'>";
    echo "<div class='input-group-prepend'>";
      echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
      echo "</div>"; 
    echo "<input type='number'  step='0.5'  name='prime_chef_equipe'  value='".$tab_affaire[0]['prime_chef_equipe']."'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
  echo "</div>";     
  
  echo "<hr class='my-4'>";

  #PRIME HAUTEUR M
  echo "<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>HAUTEUR M</span>";    
  echo "<div class='input-group mb-3'>";
    echo "<div class='input-group-prepend'>";
      echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
      echo "</div>"; 
    echo "<input type='number'  step='0.5'  name='prime_hauteurM'  value='".$tab_affaire[0]['prime_hauteurM']."'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
  echo "</div>";     
  
  echo "<hr class='my-4'>";

  # PRIME FOUR
  echo "<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>FOUR</span>";    
  echo "<div class='input-group mb-3'>";
    echo "<div class='input-group-prepend'>";
      echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
      echo "</div>"; 
    echo "<input type='number'  step='0.5'  name='prime_four'  value='".$tab_affaire[0]['prime_four']."'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
  echo "</div>";     
  
  echo "<hr class='my-4'>";

#PRIME CHALEUR
echo "<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>CHALEUR</span>";    
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend'>";
    echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
    echo "</div>"; 
  echo "<input type='number'  step='0.5'  name='prime_chaleur'  value='".$tab_affaire[0]['prime_chaleur']."'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
echo "</div>";     

echo "<hr class='my-4'>";


#PRIME INSALUBRITE
echo "<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>INSALUBRITE</span>";    
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend'>";
    echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
    echo "</div>"; 
  echo "<input type='number'  step='0.5'  name='prime_insalubrite'  value='".$tab_affaire[0]['prime_insalubrite']."' style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
echo "</div>";     

echo "<hr class='my-4'>";

#PRIME TEMPS VOYAGE£
echo "<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>TEMPS VOYAGE</span>";    
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend'>";
    echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Franc CFP</span>";
    echo "</div>"; 
  echo "<input type='number'  step='0.5'  name='prime_temps_voyage'  value='".$tab_affaire[0]['prime_temps_voyage']."'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
echo "</div>";     

echo "<hr class='my-4'>";

#PRIME CHAUFFEUR
echo "<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>CHAUFFEUR</span>";    
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend'>";
    echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Franc CFP</span>";
    echo "</div>"; 
  echo "<input type='number'  step='0.5'  name='prime_chauffeur'  value='".$tab_affaire[0]['prime_chauffeur']."'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
echo "</div>";     

echo "<hr class='my-4'>";

#PRIME DEPLACEMENT
echo "<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>DEPLACEMENT</span>";    
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend'>";
    echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Franc CFP</span>";
    echo "</div>"; 
  echo "<input type='number'  step='0.5'  name='prime_deplacement'  value='".$tab_affaire[0]['prime_deplacement']."'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
echo "</div>";     

echo "<hr class='my-4'>";

if($tab_affaire[0]['prime_panier'] == 1) {
  $autre = 0;
  $reponse = "OUI";
  $autre2 = 1;
  $reponse2 = "NON";
} if($tab_affaire[0]['prime_panier'] == 0) {
  $autre = 1;
  $reponse = "NON";
  $autre2 = 0;
  $reponse2 = "OUI";
}
#PRIME PANIER
echo "<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>PANIER</span>";    
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend'>";
  echo "<span class='input-group-text' style='width: 125px; text-align: center;'>OUI/NON</span>";  
  echo "</div>";
  echo "<select  style='text-indent: 18%;' name='prime_panier' class='custom-select' id='inputGroupSelect01' >";
    echo "<option  value='$autre'>$reponse</option>";
    echo "<option value='$autre2'>$reponse2</option>";
  echo "</select>";
echo "</div>";
#div de fin de la carte prime
echo "</div>";
echo "</div>";
echo "</div>";
echo "</div>";
?>


 <!-- debut carte autres pointage-->


<!-- carte Absence à la journée -->
<div class="card text-center" style="margin-bottom: -18.5px;" >
  <div class="card-header">
   <h4> Autres </h4>
  </div>
  <div class="card-body">
  


  <div class="row">
  <div class="col-sm-6">
    <div class="card">
    <div class="card-header">Absence à la journée</div>
      <div class="card-body">
      
       <!-- radio boutons -->

      <?php 
      if (isset($tab_affaire[0]['absencej'])) {
        if (empty($tab_affaire[0]['absencej'])) {
          $checkedaucun = "checked";
        }
        if ($tab_affaire[0]['absencej'] == "M") {
          $checkedmaladie = "checked";
        }
        if ($tab_affaire[0]['absencej'] == "AT") {
          $checkedat = "checked";
        }
        if ($tab_affaire[0]['absencej'] == "ANA") {
          $checkedana = "checked";
        }
        if ($tab_affaire[0]['absencej'] == "JF") {
          $checkedjf = "checked";
        }
        if ($tab_affaire[0]['absencej'] == "CP") {
          $checkedcp = "checked";
        }
    } else {
      $checkedaucun = "checked";
    }
    if (isset($tab_affaire[0]['delegation'])) {
      $valdeleguation = $tab_affaire[0]['delegation'];
} else {

  $valdeleguation = "";
}
if (isset($tab_affaire[0]['visite_medicale'])) {
  $valvm = $tab_affaire[0]['visite_medicale'];
} else {

$valvm = "";
}
if (isset($tab_affaire[0]['formation'])) {
  $valformation = $tab_affaire[0]['formation'];
} else {

  $valformation = "";
}
      ?>

       <div class="card" >
  <ul class="list-group list-group-flush">
    <li class="list-group-item">

       <div class="form-check">
       <input class="form-check-input" type="radio" name="absencej" id="exampleRadios0"  value="" <?php if(isset($checkedaucun)){ echo $checkedaucun;} ?> >
       <label class="form-check-label" style="padding-right:20%; padding-left:20%; margin-left:-5%;" for="exampleRadios0" >
         Aucune
       </label>
     </div>
    </li>
  
<li class="list-group-item">
       <div class="form-check">
       <input class="form-check-input" type="radio" name="absencej" id="exampleRadios1" value="M" <?php if(isset($checkedmaladie)){ echo $checkedmaladie;} ?>>
       <label class="form-check-label" style="padding-right:20%; padding-left:20%; margin-left:-5%;" for="exampleRadios1">
         Maladie
       </label>
     </div>
  </li>

     <li class="list-group-item">
     <div class="form-check">
       <input class="form-check-input" type="radio" name="absencej" id="exampleRadios2" value="AT" <?php if(isset($checkedat)){ echo $checkedat;} ?>>
       <label class="form-check-label" style="padding-right:20%; padding-left:20%; margin-left:-5%;" for="exampleRadios2">
         Accident de travail
       </label>
     </div>
  </li>

  <li class="list-group-item">
     <div class="form-check">
       <input class="form-check-input" type="radio" name="absencej" id="exampleRadios3" value="ANA" <?php if(isset($checkedana)){ echo $checkedana;} ?>>
       <label class="form-check-label" style="padding-right:18%; padding-left:18%; margin-left:-5%;" for="exampleRadios3">
         Absence non autorisée
       </label>
     </div>
     </li>

     <li class="list-group-item">
     <div class="form-check">
       <input class="form-check-input" type="radio" name="absencej" id="exampleRadios4" value="JF" <?php if(isset($checkedjf)){ echo $checkedjf;} ?>>
       <label class="form-check-label" style="padding-right:20%; padding-left:20%; margin-left:-5%; " for="exampleRadios4">
         Jour férié
       </label>
     </div>
     </li>

     <li class="list-group-item">
     <div class="form-check">
       <input class="form-check-input" type="radio"  name="absencej" id="exampleRadios5" value="CP" <?php if(isset($checkedcp)){ echo $checkedcp;} ?>>
       <label class="form-check-label" style="padding-right:19%; padding-left:19%; margin-left:-5%; " for="exampleRadios5">
         Congé payé
       </label>
     </div>
     </li>
     </ul>
</div>

<!-- div fin carte absence journée -->
      </div>
    </div>
  </div>


<!-- carte Absence à l'heure -->
  <div class="col-sm-6">
    <div class="card">
    <div class="card-header">Absence à l'heure</div>
      <div class="card-body">
 

      <span class='badge badge-dark' style='  width: 120px;'>DELEGATION</span>    
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" style="width: 125px; text-align: center;">Heures</span>
  </div>
  <input type="number"  step="0.5"  name="delegation"  <?php echo "value='".$tab_affaire[0]['delegation']."'"?>  style='text-indent: 42%;' class="form-control" aria-label="Amount (to the nearest dollar)">
</div>      

<hr class='my-4'>
<span class='badge badge-dark' style='  width: 120px;'>VISITE MEDICALE</span>    
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" style="width: 125px; text-align: center;">Heures</span>
  </div>
  <input type="number"  step="0.5"  name="visite_medicale" <?php echo "value='".$tab_affaire[0]['visite_medicale']."'"?>  style='text-indent: 42%;' class="form-control" aria-label="Amount (to the nearest dollar)">
</div>      
<hr class='my-4'>
<span class='badge badge-dark' style='  width: 120px;'>FORMATION</span>    
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" style="width: 125px; text-align: center; margin-bottom:12.5px;">Heures</span>
  </div>
  <input type="number"  step="0.5"  name="formation" <?php echo "value='".$tab_affaire[0]['formation']."'"?> style='text-indent: 42%; margin-bottom:12.5px;' class="form-control" aria-label="Amount (to the nearest dollar)">
</div>      




       <!-- div fin de carte absence heure -->
      </div>
    </div>
  </div>
</div>

 
  </div>
  <div class="card-footer text-muted">
  <button type="submit" name='modifier' value='modifier' class="btn btn-danger" style="width:29%;">Modifer</button>

<!-- div fin de carte autres -->
  </div>
</div>


</form>
   <!-- Bootstrap core JavaScript
      ================================================== -->
      <!-- Placed at the end of the document so the pages load faster -->
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </body>
  </html>
  



    
<!--###################################################################--> 
<!--#                  Projet: Application de pointage                #-->  
<!--#                  Entreprise: Cegelec                            #-->  
<!--#                  Auteurs: Maverick Lafont & Emrik Lecomte       #--> 
<!--#                  Position: Job d'été MIJ                        #--> 
<!--#                  Scolaire: BTS SIO 2ième Année                  #--> 
<!--###################################################################--> 