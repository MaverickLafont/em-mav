<?php 
         if(!empty($_POST['bouton_date_debut'])) {
            $date_debut = $_POST['date_debut'];
           } else {
           $date_debut= date("Y-m-d"); }
  
            setlocale(LC_TIME, 'fr_FR', 'french', 'fre', 'fra');
  
            $auj = $date_debut;
            $t_auj = strtotime($auj);
            $p_auj = date('N', $t_auj);
            if($p_auj == 1){
              $deb = $t_auj;
              $fin = strtotime($auj.' + 6 day');
            }
            else if($p_auj == 7){
              $deb = strtotime($auj.' - 6 day');
              $fin = $t_auj;
            }
            else{
              $deb = strtotime($auj.' - '.(6-(7-$p_auj)).' day');
              $fin = strtotime($auj.' + '.(7-$p_auj).' day');
            }
            $i = 1;
            while($deb <= $fin){
              $jour[$i] = strftime('%d %B %Y', $deb).'<br />';
              $finjoursemaine[$i] = strftime('%Y-%m-%d', $deb).'<br />';
              $deb += 86400;
              $i++;
            }
  
            $map = array_map(null, $finjoursemaine);
            $join = join(',', $map);
            list($finjoursemaine1, $finjoursemaine2, $finjoursemaine3, $finjoursemaine4, $finjoursemaine5, $finjoursemaine6, $finjoursemaine7) = explode(",", $join);
            $septiemejour = $finjoursemaine7;
            $clear = strip_tags($septiemejour);
            $clear = html_entity_decode($clear);
            $clear = urldecode($clear);
            $clear = preg_replace('/[^A-Za-z0-9]/', ' ', $clear);
            $clear = preg_replace('/ +/', ' ', $clear);
            $clear = trim($clear);
            $test = preg_replace('/\s+/', '-', $clear);
            $date = new DateTime($test);
            $result = $date->format('Y-m-d');?>
?>