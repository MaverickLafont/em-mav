<?php session_start('cegelec');?>
<!doctype html>
<html>
  <head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="../../css/employe/mainpage.css"> 	
    <link rel="stylesheet" media="handheld" type="text/css" title="mobile" href="../css/mobile.css" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">
<?php include('../connexion.php'); ?>
<title>Pointage Cegelec</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">
  </head>

  <body>
  <?php 
          $Session_login = !empty($_SESSION['username'])?$_SESSION['username']:NULL;

          //on met la requête dans une variable ($sql)
            $sql = "SELECT * FROM employe WHERE username = '$Session_login' ";
  
            // on execute la requete :
            $resultat = mysqli_query ($cx, $sql) or die('Erreur SQL !<br>'.$sql.'<br>'.mysql_error());
            // retourne un tableau qui contient la première ligne de $resultat
            $data = mysqli_fetch_array($resultat);
            mysqli_free_result ($resultat);
            $date_debut = $_GET['date'];
            $semaine = $_GET['semaine'];
            $matricule = $data['matricule'];

?>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark" >
    <?php echo "<a class='navbar-brand' href='mainpsa.php?date=$date_debut'>Retour</a>" ;?>
    <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="navbar-collapse collapse" id="navbarColor01" style="">
      <ul class="navbar-nav mr-auto">
      </ul>
    </div>
  </nav>
    
  <?php 
        
          setlocale(LC_TIME, 'fr_FR', 'french', 'fre', 'fra');

          $auj = $date_debut;
          $t_auj = strtotime($auj);
          $p_auj = date('N', $t_auj);
          if($p_auj == 1){
            $deb = $t_auj;
            $fin = strtotime($auj.' + 6 day');
          }
          else if($p_auj == 7){
            $deb = strtotime($auj.' - 6 day');
            $fin = $t_auj;
          }
          else{
            $deb = strtotime($auj.' - '.(6-(7-$p_auj)).' day');
            $fin = strtotime($auj.' + '.(7-$p_auj).' day');
          }
          $i = 1;
          while($deb <= $fin){
            $jour[$i] = strftime('%d %B %Y', $deb).'<br />';
            $finjoursemaine[$i] = strftime('%Y-%m-%d', $deb).'<br />';
            $deb += 86400;
            $i++;
          }

          $map = array_map(null, $finjoursemaine);
          $join = join(',', $map);
          list($finjoursemaine1, $finjoursemaine2, $finjoursemaine3, $finjoursemaine4, $finjoursemaine5, $finjoursemaine6, $finjoursemaine7) = explode(",", $join);
          $premierjour= $finjoursemaine1;$deuxiemejour=$finjoursemaine2;$troisiemejour=$finjoursemaine3;$quatriemejour=$finjoursemaine4;$cinquiemejour=$finjoursemaine5;$sixiemejour = $finjoursemaine6;$septiemejour = $finjoursemaine7;
          $clear = strip_tags($premierjour);
          $clear = html_entity_decode($clear);
          $clear = urldecode($clear);
          $clear = preg_replace('/[^A-Za-z0-9]/', ' ', $clear);
          $clear = preg_replace('/ +/', ' ', $clear);
          $clear = trim($clear);
          $test = preg_replace('/\s+/', '-', $clear);
          $date = new DateTime($test);
          $result = $date->format('Y-m-d');

          $clear1 = strip_tags($deuxiemejour);
          $clear1 = html_entity_decode($clear1);
          $clear1 = urldecode($clear1);
          $clear1 = preg_replace('/[^A-Za-z0-9]/', ' ', $clear1);
          $clear1 = preg_replace('/ +/', ' ', $clear1);
          $clear1 = trim($clear1);
          $test1 = preg_replace('/\s+/', '-', $clear1);
          $date1 = new DateTime($test1);
          $result1 = $date1->format('Y-m-d');

          $clear2 = strip_tags($troisiemejour);
          $clear2 = html_entity_decode($clear2);
          $clear2 = urldecode($clear2);
          $clear2 = preg_replace('/[^A-Za-z0-9]/', ' ', $clear2);
          $clear2 = preg_replace('/ +/', ' ', $clear2);
          $clear2 = trim($clear2);
          $test2 = preg_replace('/\s+/', '-', $clear2);
          $date2 = new DateTime($test2);
          $result2 = $date2->format('Y-m-d');

          $clear3 = strip_tags($quatriemejour);
          $clear3 = html_entity_decode($clear3);
          $clear3 = urldecode($clear3);
          $clear3 = preg_replace('/[^A-Za-z0-9]/', ' ', $clear3);
          $clear3 = preg_replace('/ +/', ' ', $clear3);
          $clear3 = trim($clear3);
          $test3 = preg_replace('/\s+/', '-', $clear3);
          $date3 = new DateTime($test3);
          $result3 = $date3->format('Y-m-d');

          $clear4 = strip_tags($cinquiemejour);
          $clear4 = html_entity_decode($clear4);
          $clear4 = urldecode($clear4);
          $clear4 = preg_replace('/[^A-Za-z0-9]/', ' ', $clear4);
          $clear4 = preg_replace('/ +/', ' ', $clear4);
          $clear4 = trim($clear4);
          $test4 = preg_replace('/\s+/', '-', $clear4);
          $date4 = new DateTime($test4);
          $result4 = $date4->format('Y-m-d');

          $clear5 = strip_tags($sixiemejour);
          $clear5 = html_entity_decode($clear5);
          $clear5 = urldecode($clear5);
          $clear5 = preg_replace('/[^A-Za-z0-9]/', ' ', $clear5);
          $clear5 = preg_replace('/ +/', ' ', $clear5);
          $clear5 = trim($clear5);
          $test5 = preg_replace('/\s+/', '-', $clear5);
          $date5 = new DateTime($test5);
          $result5 = $date5->format('Y-m-d');

          $clear6 = strip_tags($septiemejour);
          $clear6 = html_entity_decode($clear6);
          $clear6 = urldecode($clear6);
          $clear6 = preg_replace('/[^A-Za-z0-9]/', ' ', $clear6);
          $clear6 = preg_replace('/ +/', ' ', $clear6);
          $clear6 = trim($clear6);
          $test6 = preg_replace('/\s+/', '-', $clear6);
          $date6 = new DateTime($test6);
          $result6 = $date6->format('Y-m-d');

        $rq_lundi="select * from pointage_affaire where employe_matricule_affaire='$matricule' AND S='$semaine' AND date_affaire='$result' ;";
        $rs_lundi=mysqli_query($cx,$rq_lundi) or die("Error: ".mysqli_error($cx));
        if ($rq_lundi){
            $data_lundi=mysqli_fetch_array($rs_lundi);
        }
        else {
            echo "Erreur de la requete";
}
if(!empty($data_lundi['absencej'])){
    if($data_lundi['absencej'] == "CP" Or $data_lundi['absencej'] == "JF"){
      $totallundi = 7.8;
    }
  } else {
    $totallundi = $data_lundi['heure_affaire1']+$data_lundi['heure_affaire2']+$data_lundi['heure_affaire3']+$data_lundi['heure_affaire4']+$data_lundi['heure_affaire5']+$data_lundi['heure_affaire6']+$data_lundi['heure_affaire7']+$data_lundi['delegation']+$data_lundi['visite_medicale']+$data_lundi['formation'];
  }
  if($data_lundi['absencej'] == "M" Or $data_lundi['absencej'] == "AT" Or $data_lundi['absencej'] == "ANA"){
    $totallundi = 0;
  }
  ############################################## MARDI
  $rq_mardi="select * from pointage_affaire where employe_matricule_affaire='$matricule' AND S='$semaine' AND date_affaire='$result1' ;";
  $rs_mardi=mysqli_query($cx,$rq_mardi) or die("Error: ".mysqli_error($cx));
  if ($rq_mardi){
      $data_mardi=mysqli_fetch_array($rs_mardi);
  }
  else {
      echo "Erreur de la requete";
}
if(!empty($data_mardi['absencej'])){
if($data_mardi['absencej'] == "CP" Or $data_mardi['absencej'] == "JF"){
$totalmardi = 7.8;
}
} else {
$totalmardi = $data_mardi['heure_affaire1']+$data_mardi['heure_affaire2']+$data_mardi['heure_affaire3']+$data_mardi['heure_affaire4']+$data_mardi['heure_affaire5']+$data_mardi['heure_affaire6']+$data_mardi['heure_affaire7']+$data_mardi['delegation']+$data_mardi['visite_medicale']+$data_mardi['formation'];
}
if($data_mardi['absencej'] == "M" Or $data_mardi['absencej'] == "AT" Or $data_mardi['absencej'] == "ANA"){
  $totalmardi = 0;
}
############################################### mercredi
  $rq_mercredi="select * from pointage_affaire where employe_matricule_affaire='$matricule' AND S='$semaine' AND date_affaire='$result2' ;";
  $rs_mercredi=mysqli_query($cx,$rq_mercredi) or die("Error: ".mysqli_error($cx));
  if ($rq_mercredi){
      $data_mercredi=mysqli_fetch_array($rs_mercredi);
  }
  else {
      echo "Erreur de la requete";
}
if(!empty($data_mercredi['absencej'])){
if($data_mercredi['absencej'] == "CP" Or $data_mercredi['absencej'] == "JF"){
$totalmercredi = 7.8;
}
} else {
$totalmercredi = $data_mercredi['heure_affaire1']+$data_mercredi['heure_affaire2']+$data_mercredi['heure_affaire3']+$data_mercredi['heure_affaire4']+$data_mercredi['heure_affaire5']+$data_mercredi['heure_affaire6']+$data_mercredi['heure_affaire7']+$data_mercredi['delegation']+$data_mercredi['visite_medicale']+$data_mercredi['formation'];
}
if($data_mercredi['absencej'] == "M" Or $data_mercredi['absencej'] == "AT" Or $data_mercredi['absencej'] == "ANA"){
  $totalmercredi = 0;
}
############################################### jeudi
$rq_jeudi="select * from pointage_affaire where employe_matricule_affaire='$matricule' AND S='$semaine' AND date_affaire='$result3' ;";
$rs_jeudi=mysqli_query($cx,$rq_jeudi) or die("Error: ".mysqli_error($cx));
if ($rq_jeudi){
    $data_jeudi=mysqli_fetch_array($rs_jeudi);
}
else {
    echo "Erreur de la requete";
}
if(!empty($data_jeudi['absencej'])){
if($data_jeudi['absencej'] == "CP" Or $data_jeudi['absencej'] == "JF"){
$totaljeudi = 7.8;
}
} else {
$totaljeudi = $data_jeudi['heure_affaire1']+$data_jeudi['heure_affaire2']+$data_jeudi['heure_affaire3']+$data_jeudi['heure_affaire4']+$data_jeudi['heure_affaire5']+$data_jeudi['heure_affaire6']+$data_jeudi['heure_affaire7']+$data_jeudi['delegation']+$data_jeudi['visite_medicale']+$data_jeudi['formation'];
}
if($data_jeudi['absencej'] == "M" Or $data_jeudi['absencej'] == "AT" Or $data_jeudi['absencej'] == "ANA"){
  $totaljeudi = 0;
}
############################################### vendredi
$rq_vendredi="select * from pointage_affaire where employe_matricule_affaire='$matricule' AND S='$semaine' AND date_affaire='$result4' ;";
$rs_vendredi=mysqli_query($cx,$rq_vendredi) or die("Error: ".mysqli_error($cx));
if ($rq_vendredi){
    $data_vendredi=mysqli_fetch_array($rs_vendredi);
}
else {
    echo "Erreur de la requete";
}
if(!empty($data_vendredi['absencej'])){
if($data_vendredi['absencej'] == "CP" Or $data_vendredi['absencej'] == "JF"){
$totalvendredi = 7.8;
}
} else {
$totalvendredi = $data_vendredi['heure_affaire1']+$data_vendredi['heure_affaire2']+$data_vendredi['heure_affaire3']+$data_vendredi['heure_affaire4']+$data_vendredi['heure_affaire5']+$data_vendredi['heure_affaire6']+$data_vendredi['heure_affaire7']+$data_vendredi['delegation']+$data_vendredi['visite_medicale']+$data_vendredi['formation'];
}
if($data_vendredi['absencej'] == "M" Or $data_vendredi['absencej'] == "AT" Or $data_vendredi['absencej'] == "ANA"){
  $totalvendredi = 0;
}
############################################### samedi
$rq_samedi="select * from pointage_affaire where employe_matricule_affaire='$matricule' AND S='$semaine' AND date_affaire='$result5' ;";
$rs_samedi=mysqli_query($cx,$rq_samedi) or die("Error: ".mysqli_error($cx));
if ($rq_samedi){
    $data_samedi=mysqli_fetch_array($rs_samedi);
}
else {
    echo "Erreur de la requete";
}
if(!empty($data_samedi['absencej'])){
  if($data_samedi['absencej'] == "CP" Or $data_samedi['absencej'] == "JF"){
  $totalsamedi = 7.8;
  }
  } else {
  $totalsamedi = $data_samedi['heure_affaire1']+$data_samedi['heure_affaire2']+$data_samedi['heure_affaire3']+$data_samedi['heure_affaire4']+$data_samedi['heure_affaire5']+$data_samedi['heure_affaire6']+$data_samedi['heure_affaire7']+$data_samedi['delegation']+$data_samedi['visite_medicale']+$data_samedi['formation'];
  }
  if($data_samedi['absencej'] == "M" Or $data_samedi['absencej'] == "AT" Or $data_samedi['absencej'] == "ANA"){
    $totalsamedi = 0;
  }

############################################### dimanche
$rq_dimanche="select * from pointage_affaire where employe_matricule_affaire='$matricule' AND S='$semaine' AND date_affaire='$result6' ;";
$rs_dimanche=mysqli_query($cx,$rq_dimanche) or die("Error: ".mysqli_error($cx));
if ($rq_dimanche){
    $data_dimanche=mysqli_fetch_array($rs_dimanche);
}
else {
    echo "Erreur de la requete";
}
if(!empty($data_dimanche['absencej'])){
if($data_dimanche['absencej'] == "CP" Or $data_dimanche['absencej'] == "JF"){
$totaldimanche = 7.8;
}
} else {
$totaldimanche = $data_dimanche['heure_affaire1']+$data_dimanche['heure_affaire2']+$data_dimanche['heure_affaire3']+$data_dimanche['heure_affaire4']+$data_dimanche['heure_affaire5']+$data_dimanche['heure_affaire6']+$data_dimanche['heure_affaire7']+$data_dimanche['delegation']+$data_dimanche['visite_medicale']+$data_dimanche['formation'];
}
if($data_dimanche['absencej'] == "M" Or $data_dimanche['absencej'] == "AT" Or $data_dimanche['absencej'] == "ANA"){
  $totaldimanche = 0;
}
?>

  <table class="table table-striped table-bordered">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Dates</th>
      <th scope="col">Nuit</th>
      <th scope="col">Divers</th>
      <th scope="col">Chef d'équipe</th>
      <th scope="col">Hauteur M</th>
      <th scope="col">Four</th>
      <th scope="col">Chaleur</th>
      <th scope="col">Insalubrité</th>
      <th scope="col">Temps Voyage</th>
      <th scope="col">Chauffeur</th>
      <th scope="col">Panier</th>
      <th scope="col">Déplacement</th>
      <th scope="col">Total <br> Heures Travaillées</th>
      <th scope="col">N°Affaire + Heures</th>
      <th scope="col">N°Affaire + Heures</th>
      <th scope="col">N°Affaire + Heures</th>
      <th scope="col">N°Affaire + Heures</th>
      <th scope="col">N°Affaire + Heures</th>
      <th scope="col">N°Affaire + Heures</th>
      <th scope="col">N°Affaire + Heures</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Lundi <?php echo ($jour[1]);?></th>
      <td><?php echo $data_lundi['prime_nuit'];?></td>
      <td><?php echo $data_lundi['prime_divers'];?></td>
      <td><?php echo $data_lundi['prime_chef_equipe'];?></td>
      <td><?php echo $data_lundi['prime_hauteurM'];?></td>
      <td><?php echo $data_lundi['prime_four'];?></td>
      <td><?php echo $data_lundi['prime_chaleur'];?></td>
      <td><?php echo $data_lundi['prime_insalubrite'];?></td>
      <td><?php echo $data_lundi['prime_temps_voyage'];?></td>
      <td><?php echo $data_lundi['prime_chauffeur'];?></td>
      <td><?php echo $data_lundi['prime_panier'];?></td>
      <td><?php echo $data_lundi['prime_deplacement'];?></td>
      <td><?php echo $totallundi; ?></td>
      <td><?php $numero_affaire1 = 'N°'.$data_lundi['numero_affaire1'].' - '.$data_lundi['heure_affaire1'].'H'; if($numero_affaire1 == "N°0 - 0.0H") {$numero_affaire1="Aucun"; echo $numero_affaire1;} else { echo $numero_affaire1;} ?></td>
      <td><?php $numero_affaire2 = 'N°'.$data_lundi['numero_affaire2'].' - '.$data_lundi['heure_affaire2'].'H'; if($numero_affaire2 == "N°0 - 0.0H") {$numero_affaire2="Aucun"; echo $numero_affaire2;} else { echo $numero_affaire2;} ?></td>
      <td><?php $numero_affaire3 = 'N°'.$data_lundi['numero_affaire3'].' - '.$data_lundi['heure_affaire3'].'H'; if($numero_affaire3 == "N°0 - 0.0H") {$numero_affaire3="Aucun"; echo $numero_affaire3;} else { echo $numero_affaire3;} ?></td>
      <td><?php if(!empty($data_lundi['absencej'])){$numero_affaire4 = $data_lundi['absencej'];} else {$numero_affaire4='N°'.$data_lundi['numero_affaire4'].' - '.$data_lundi['heure_affaire4'].'H';} if($numero_affaire4 == "N°0 - 0.0H") {$numero_affaire4="Aucun";} echo $numero_affaire4; ?></td>
      <td><?php if($data_lundi['delegation'] == 0){$numero_affaire5 = 'N°'.$data_lundi['numero_affaire5'].' - '.$data_lundi['heure_affaire5'].'H';}else {$numero_affaire5=$data_lundi['delegation'];} if($numero_affaire5 == "N°0 - 0.0H") {$numero_affaire5="Aucun";} echo $numero_affaire5; ?></td>
      <td><?php if($data_lundi['visite_medicale'] == 0){$numero_affaire6 = 'N°'.$data_lundi['numero_affaire6'].' - '.$data_lundi['heure_affaire6'].'H';}else {$numero_affaire6=$data_lundi['visite_medicale'];} if($numero_affaire6 == "N°0 - 0.0H") {$numero_affaire6="Aucun";} echo $numero_affaire6; ?></td>
      <td><?php if($data_lundi['formation'] == 0){$numero_affaire7 = 'N°'.$data_lundi['numero_affaire7'].' - '.$data_lundi['heure_affaire7'].'H';}else {$numero_affaire7=$data_lundi['formation'];} if($numero_affaire7 == "N°0 - 0.0H") {$numero_affaire7="Aucun";} echo $numero_affaire7; ?></td>
    </tr>
    <tr>
      <th scope="row">Mardi <?php echo ($jour[2]);?></th>
      <td><?php echo $data_mardi['prime_nuit'];?></td>
      <td><?php echo $data_mardi['prime_divers'];?></td>
      <td><?php echo $data_mardi['prime_chef_equipe'];?></td>
      <td><?php echo $data_mardi['prime_hauteurM'];?></td>
      <td><?php echo $data_mardi['prime_four'];?></td>
      <td><?php echo $data_mardi['prime_chaleur'];?></td>
      <td><?php echo $data_mardi['prime_insalubrite'];?></td>
      <td><?php echo $data_mardi['prime_temps_voyage'];?></td>
      <td><?php echo $data_mardi['prime_chauffeur'];?></td>
      <td><?php echo $data_mardi['prime_panier'];?></td>
      <td><?php echo $data_mardi['prime_deplacement'];?></td>
      <td><?php echo $totalmardi; ?></td>
      <td><?php $numero_affaire1 = 'N°'.$data_mardi['numero_affaire1'].' - '.$data_mardi['heure_affaire1'].'H'; if($numero_affaire1 == "N°0 - 0.0H") {$numero_affaire1="Aucun"; echo $numero_affaire1;} else { echo $numero_affaire1;} ?></td>
      <td><?php $numero_affaire2 = 'N°'.$data_mardi['numero_affaire2'].' - '.$data_mardi['heure_affaire2'].'H'; if($numero_affaire2 == "N°0 - 0.0H") {$numero_affaire2="Aucun"; echo $numero_affaire2;} else { echo $numero_affaire2;} ?></td>
      <td><?php $numero_affaire3 = 'N°'.$data_mardi['numero_affaire3'].' - '.$data_mardi['heure_affaire3'].'H'; if($numero_affaire3 == "N°0 - 0.0H") {$numero_affaire3="Aucun"; echo $numero_affaire3;} else { echo $numero_affaire3;} ?></td>
      <td><?php if(!empty($data_mardi['absencej'])){$numero_affaire4 = $data_mardi['absencej'];} else {$numero_affaire4='N°'.$data_mardi['numero_affaire4'].' - '.$data_mardi['heure_affaire4'].'H';} if($numero_affaire4 == "N°0 - 0.0H") {$numero_affaire4="Aucun";} echo $numero_affaire4; ?></td>
      <td><?php if($data_mardi['delegation'] == 0){$numero_affaire5 = 'N°'.$data_mardi['numero_affaire5'].' - '.$data_mardi['heure_affaire5'].'H';}else {$numero_affaire5=$data_mardi['delegation'];} if($numero_affaire5 == "N°0 - 0.0H") {$numero_affaire5="Aucun";} echo $numero_affaire5; ?></td>
      <td><?php if($data_mardi['visite_medicale'] == 0){$numero_affaire6 = 'N°'.$data_mardi['numero_affaire6'].' - '.$data_mardi['heure_affaire6'].'H';}else {$numero_affaire6=$data_mardi['visite_medicale'];} if($numero_affaire6 == "N°0 - 0.0H") {$numero_affaire6="Aucun";} echo $numero_affaire6; ?></td>
      <td><?php if($data_mardi['formation'] == 0){$numero_affaire7 = 'N°'.$data_mardi['numero_affaire7'].' - '.$data_mardi['heure_affaire7'].'H';}else {$numero_affaire7=$data_mardi['formation'];} if($numero_affaire7 == "N°0 - 0.0H") {$numero_affaire7="Aucun";} echo $numero_affaire7; ?></td>
    </tr>
    <tr>
      <th scope="row">Mercredi <?php echo ($jour[3]);?></th>
      <td><?php echo $data_mercredi['prime_nuit'];?></td>
      <td><?php echo $data_mercredi['prime_divers'];?></td>
      <td><?php echo $data_mercredi['prime_chef_equipe'];?></td>
      <td><?php echo $data_mercredi['prime_hauteurM'];?></td>
      <td><?php echo $data_mercredi['prime_four'];?></td>
      <td><?php echo $data_mercredi['prime_chaleur'];?></td>
      <td><?php echo $data_mercredi['prime_insalubrite'];?></td>
      <td><?php echo $data_mercredi['prime_temps_voyage'];?></td>
      <td><?php echo $data_mercredi['prime_chauffeur'];?></td>
      <td><?php echo $data_mercredi['prime_panier'];?></td>
      <td><?php echo $data_mercredi['prime_deplacement'];?></td>
      <td><?php echo $totalmercredi; ?></td>
      <td><?php $numero_affaire1 = 'N°'.$data_mercredi['numero_affaire1'].' - '.$data_mercredi['heure_affaire1'].'H'; if($numero_affaire1 == "N°0 - 0.0H") {$numero_affaire1="Aucun"; echo $numero_affaire1;} else { echo $numero_affaire1;} ?></td>
      <td><?php $numero_affaire2 = 'N°'.$data_mercredi['numero_affaire2'].' - '.$data_mercredi['heure_affaire2'].'H'; if($numero_affaire2 == "N°0 - 0.0H") {$numero_affaire2="Aucun"; echo $numero_affaire2;} else { echo $numero_affaire2;} ?></td>
      <td><?php $numero_affaire3 = 'N°'.$data_mercredi['numero_affaire3'].' - '.$data_mercredi['heure_affaire3'].'H'; if($numero_affaire3 == "N°0 - 0.0H") {$numero_affaire3="Aucun"; echo $numero_affaire3;} else { echo $numero_affaire3;} ?></td>
      <td><?php if(!empty($data_mercredi['absencej'])){$numero_affaire4 = $data_mercredi['absencej'];} else {$numero_affaire4='N°'.$data_mercredi['numero_affaire4'].' - '.$data_mercredi['heure_affaire4'].'H';} if($numero_affaire4 == "N°0 - 0.0H") {$numero_affaire4="Aucun";} echo $numero_affaire4; ?></td>
      <td><?php if($data_mercredi['delegation'] == 0){$numero_affaire5 = 'N°'.$data_mercredi['numero_affaire5'].' - '.$data_mercredi['heure_affaire5'].'H';}else {$numero_affaire5=$data_mercredi['delegation'];} if($numero_affaire5 == "N°0 - 0.0H") {$numero_affaire5="Aucun";} echo $numero_affaire5; ?></td>
      <td><?php if($data_mercredi['visite_medicale'] == 0){$numero_affaire6 = 'N°'.$data_mercredi['numero_affaire6'].' - '.$data_mercredi['heure_affaire6'].'H';}else {$numero_affaire6=$data_mercredi['visite_medicale'];} if($numero_affaire6 == "N°0 - 0.0H") {$numero_affaire6="Aucun";} echo $numero_affaire6; ?></td>
      <td><?php if($data_mercredi['formation'] == 0){$numero_affaire7 = 'N°'.$data_mercredi['numero_affaire7'].' - '.$data_mercredi['heure_affaire7'].'H';}else {$numero_affaire7=$data_mercredi['formation'];} if($numero_affaire7 == "N°0 - 0.0H") {$numero_affaire7="Aucun";} echo $numero_affaire7; ?></td>
    </tr>
    <tr>
      <th scope="row">Jeudi <?php echo ($jour[4]);?></th>
      <td><?php echo $data_jeudi['prime_nuit'];?></td>
      <td><?php echo $data_jeudi['prime_divers'];?></td>
      <td><?php echo $data_jeudi['prime_chef_equipe'];?></td>
      <td><?php echo $data_jeudi['prime_hauteurM'];?></td>
      <td><?php echo $data_jeudi['prime_four'];?></td>
      <td><?php echo $data_jeudi['prime_chaleur'];?></td>
      <td><?php echo $data_jeudi['prime_insalubrite'];?></td>
      <td><?php echo $data_jeudi['prime_temps_voyage'];?></td>
      <td><?php echo $data_jeudi['prime_chauffeur'];?></td>
      <td><?php echo $data_jeudi['prime_panier'];?></td>
      <td><?php echo $data_jeudi['prime_deplacement'];?></td>
      <td><?php echo $totaljeudi; ?></td>
      <td><?php $numero_affaire1 = 'N°'.$data_jeudi['numero_affaire1'].' - '.$data_jeudi['heure_affaire1'].'H'; if($numero_affaire1 == "N°0 - 0.0H") {$numero_affaire1="Aucun"; echo $numero_affaire1;} else { echo $numero_affaire1;} ?></td>
      <td><?php $numero_affaire2 = 'N°'.$data_jeudi['numero_affaire2'].' - '.$data_jeudi['heure_affaire2'].'H'; if($numero_affaire2 == "N°0 - 0.0H") {$numero_affaire2="Aucun"; echo $numero_affaire2;} else { echo $numero_affaire2;} ?></td>
      <td><?php $numero_affaire3 = 'N°'.$data_jeudi['numero_affaire3'].' - '.$data_jeudi['heure_affaire3'].'H'; if($numero_affaire3 == "N°0 - 0.0H") {$numero_affaire3="Aucun"; echo $numero_affaire3;} else { echo $numero_affaire3;} ?></td>
      <td><?php if(!empty($data_jeudi['absencej'])){$numero_affaire4 = $data_jeudi['absencej'];} else {$numero_affaire4='N°'.$data_jeudi['numero_affaire4'].' - '.$data_jeudi['heure_affaire4'].'H';} if($numero_affaire4 == "N°0 - 0.0H") {$numero_affaire4="Aucun";} echo $numero_affaire4; ?></td>
      <td><?php if($data_jeudi['delegation'] == 0){$numero_affaire5 = 'N°'.$data_jeudi['numero_affaire5'].' - '.$data_jeudi['heure_affaire5'].'H';}else {$numero_affaire5=$data_jeudi['delegation'];} if($numero_affaire5 == "N°0 - 0.0H") {$numero_affaire5="Aucun";} echo $numero_affaire5; ?></td>
      <td><?php if($data_jeudi['visite_medicale'] == 0){$numero_affaire6 = 'N°'.$data_jeudi['numero_affaire6'].' - '.$data_jeudi['heure_affaire6'].'H';}else {$numero_affaire6=$data_jeudi['visite_medicale'];} if($numero_affaire6 == "N°0 - 0.0H") {$numero_affaire6="Aucun";} echo $numero_affaire6; ?></td>
      <td><?php if($data_jeudi['formation'] == 0){$numero_affaire7 = 'N°'.$data_jeudi['numero_affaire7'].' - '.$data_jeudi['heure_affaire7'].'H';}else {$numero_affaire7=$data_jeudi['formation'];} if($numero_affaire7 == "N°0 - 0.0H") {$numero_affaire7="Aucun";} echo $numero_affaire7; ?></td>
    </tr>
    <tr>
      <th scope="row">Vendredi <?php echo ($jour[5]);?></th>
      <td><?php echo $data_vendredi['prime_nuit'];?></td>
      <td><?php echo $data_vendredi['prime_divers'];?></td>
      <td><?php echo $data_vendredi['prime_chef_equipe'];?></td>
      <td><?php echo $data_vendredi['prime_hauteurM'];?></td>
      <td><?php echo $data_vendredi['prime_four'];?></td>
      <td><?php echo $data_vendredi['prime_chaleur'];?></td>
      <td><?php echo $data_vendredi['prime_insalubrite'];?></td>
      <td><?php echo $data_vendredi['prime_temps_voyage'];?></td>
      <td><?php echo $data_vendredi['prime_chauffeur'];?></td>
      <td><?php echo $data_vendredi['prime_panier'];?></td>
      <td><?php echo $data_vendredi['prime_deplacement'];?></td>
      <td><?php echo $totalvendredi; ?></td>
      <td><?php $numero_affaire1 = 'N°'.$data_vendredi['numero_affaire1'].' - '.$data_vendredi['heure_affaire1'].'H'; if($numero_affaire1 == "N°0 - 0.0H") {$numero_affaire1="Aucun"; echo $numero_affaire1;} else { echo $numero_affaire1;} ?></td>
      <td><?php $numero_affaire2 = 'N°'.$data_vendredi['numero_affaire2'].' - '.$data_vendredi['heure_affaire2'].'H'; if($numero_affaire2 == "N°0 - 0.0H") {$numero_affaire2="Aucun"; echo $numero_affaire2;} else { echo $numero_affaire2;} ?></td>
      <td><?php $numero_affaire3 = 'N°'.$data_vendredi['numero_affaire3'].' - '.$data_vendredi['heure_affaire3'].'H'; if($numero_affaire3 == "N°0 - 0.0H") {$numero_affaire3="Aucun"; echo $numero_affaire3;} else { echo $numero_affaire3;} ?></td>
      <td><?php if(!empty($data_vendredi['absencej'])){$numero_affaire4 = $data_vendredi['absencej'];} else {$numero_affaire4='N°'.$data_vendredi['numero_affaire4'].' - '.$data_vendredi['heure_affaire4'].'H';} if($numero_affaire4 == "N°0 - 0.0H") {$numero_affaire4="Aucun";} echo $numero_affaire4; ?></td>
      <td><?php if($data_vendredi['delegation'] == 0){$numero_affaire5 = 'N°'.$data_vendredi['numero_affaire5'].' - '.$data_vendredi['heure_affaire5'].'H';}else {$numero_affaire5=$data_vendredi['delegation'];} if($numero_affaire5 == "N°0 - 0.0H") {$numero_affaire5="Aucun";} echo $numero_affaire5; ?></td>
      <td><?php if($data_vendredi['visite_medicale'] == 0){$numero_affaire6 = 'N°'.$data_vendredi['numero_affaire6'].' - '.$data_vendredi['heure_affaire6'].'H';}else {$numero_affaire6=$data_vendredi['visite_medicale'];} if($numero_affaire6 == "N°0 - 0.0H") {$numero_affaire6="Aucun";} echo $numero_affaire6; ?></td>
      <td><?php if($data_vendredi['formation'] == 0){$numero_affaire7 = 'N°'.$data_vendredi['numero_affaire7'].' - '.$data_vendredi['heure_affaire7'].'H';}else {$numero_affaire7=$data_vendredi['formation'];} if($numero_affaire7 == "N°0 - 0.0H") {$numero_affaire7="Aucun";} echo $numero_affaire7; ?></td>
    </tr>
    <tr>
      <th scope="row">Samedi <?php echo ($jour[6]);?></th>
      <td><?php echo $data_samedi['prime_nuit'];?></td>
      <td><?php echo $data_samedi['prime_divers'];?></td>
      <td><?php echo $data_samedi['prime_chef_equipe'];?></td>
      <td><?php echo $data_samedi['prime_hauteurM'];?></td>
      <td><?php echo $data_samedi['prime_four'];?></td>
      <td><?php echo $data_samedi['prime_chaleur'];?></td>
      <td><?php echo $data_samedi['prime_insalubrite'];?></td>
      <td><?php echo $data_samedi['prime_temps_voyage'];?></td>
      <td><?php echo $data_samedi['prime_chauffeur'];?></td>
      <td><?php echo $data_samedi['prime_panier'];?></td>
      <td><?php echo $data_samedi['prime_deplacement'];?></td>
      <td><?php echo $totalsamedi; ?></td>
      <td><?php $numero_affaire1 = 'N°'.$data_samedi['numero_affaire1'].' - '.$data_samedi['heure_affaire1'].'H'; if($numero_affaire1 == "N° - H") {$numero_affaire1="Aucun"; echo $numero_affaire1;} else { echo $numero_affaire1;} ?></td>
      <td><?php $numero_affaire2 = 'N°'.$data_samedi['numero_affaire2'].' - '.$data_samedi['heure_affaire2'].'H'; if($numero_affaire2 == "N° - H") {$numero_affaire2="Aucun"; echo $numero_affaire2;} else { echo $numero_affaire2;} ?></td>
      <td><?php $numero_affaire3 = 'N°'.$data_samedi['numero_affaire3'].' - '.$data_samedi['heure_affaire3'].'H'; if($numero_affaire3 == "N° - H") {$numero_affaire3="Aucun"; echo $numero_affaire3;} else { echo $numero_affaire3;} ?></td>
      <td><?php if(!empty($data_samedi['absencej'])){$numero_affaire4 = $data_samedi['absencej'];} else {$numero_affaire4='N°'.$data_samedi['numero_affaire4'].' - '.$data_samedi['heure_affaire4'].'H';} if($numero_affaire4 == "N° - H") {$numero_affaire4="Aucun";} echo $numero_affaire4; ?></td>
      <td><?php if($data_samedi['delegation'] == 0){$numero_affaire5 = 'N°'.$data_samedi['numero_affaire5'].' - '.$data_samedi['heure_affaire5'].'H';}else {$numero_affaire5=$data_samedi['delegation'];} if($numero_affaire5 == "N° - H") {$numero_affaire5="Aucun";} echo $numero_affaire5; ?></td>
      <td><?php if($data_samedi['visite_medicale'] == 0){$numero_affaire6 = 'N°'.$data_samedi['numero_affaire6'].' - '.$data_samedi['heure_affaire6'].'H';}else {$numero_affaire6=$data_samedi['visite_medicale'];} if($numero_affaire6 == "N° - H") {$numero_affaire6="Aucun";} echo $numero_affaire6; ?></td>
      <td><?php if($data_samedi['formation'] == 0){$numero_affaire7 = 'N°'.$data_samedi['numero_affaire7'].' - '.$data_samedi['heure_affaire7'].'H';}else {$numero_affaire7=$data_samedi['formation'];} if($numero_affaire7 == "N° - H") {$numero_affaire7="Aucun";} echo $numero_affaire7; ?></td>
    </tr>
    <tr>
      <th scope="row">Dimanche <?php echo ($jour[7]);?></th>
      <td><?php echo $data_dimanche['prime_nuit'];?></td>
      <td><?php echo $data_dimanche['prime_divers'];?></td>
      <td><?php echo $data_dimanche['prime_chef_equipe'];?></td>
      <td><?php echo $data_dimanche['prime_hauteurM'];?></td>
      <td><?php echo $data_dimanche['prime_four'];?></td>
      <td><?php echo $data_dimanche['prime_chaleur'];?></td>
      <td><?php echo $data_dimanche['prime_insalubrite'];?></td>
      <td><?php echo $data_dimanche['prime_temps_voyage'];?></td>
      <td><?php echo $data_dimanche['prime_chauffeur'];?></td>
      <td><?php echo $data_dimanche['prime_panier'];?></td>
      <td><?php echo $data_dimanche['prime_deplacement'];?></td>
      <td><?php echo $totaldimanche; ?></td>
      <td><?php $numero_affaire1 = 'N°'.$data_dimanche['numero_affaire1'].' - '.$data_dimanche['heure_affaire1'].'H'; if($numero_affaire1 == "N° - H") {$numero_affaire1="Aucun"; echo $numero_affaire1;} else { echo $numero_affaire1;} ?></td>
      <td><?php $numero_affaire2 = 'N°'.$data_dimanche['numero_affaire2'].' - '.$data_dimanche['heure_affaire2'].'H'; if($numero_affaire2 == "N° - H") {$numero_affaire2="Aucun"; echo $numero_affaire2;} else { echo $numero_affaire2;} ?></td>
      <td><?php $numero_affaire3 = 'N°'.$data_dimanche['numero_affaire3'].' - '.$data_dimanche['heure_affaire3'].'H'; if($numero_affaire3 == "N° - H") {$numero_affaire3="Aucun"; echo $numero_affaire3;} else { echo $numero_affaire3;} ?></td>
      <td><?php if(!empty($data_dimanche['absencej'])){$numero_affaire4 = $data_dimanche['absencej'];} else {$numero_affaire4='N°'.$data_dimanche['numero_affaire4'].' - '.$data_dimanche['heure_affaire4'].'H';} if($numero_affaire4 == "N° - H") {$numero_affaire4="Aucun";} echo $numero_affaire4; ?></td>
      <td><?php if($data_dimanche['delegation'] == 0){$numero_affaire5 = 'N°'.$data_dimanche['numero_affaire5'].' - '.$data_dimanche['heure_affaire5'].'H';}else {$numero_affaire5=$data_dimanche['delegation'];} if($numero_affaire5 == "N° - H") {$numero_affaire5="Aucun";} echo $numero_affaire5; ?></td>
      <td><?php if($data_dimanche['visite_medicale'] == 0){$numero_affaire6 = 'N°'.$data_dimanche['numero_affaire6'].' - '.$data_dimanche['heure_affaire6'].'H';}else {$numero_affaire6=$data_dimanche['visite_medicale'];} if($numero_affaire6 == "N° - H") {$numero_affaire6="Aucun";} echo $numero_affaire6; ?></td>
      <td><?php if($data_dimanche['formation'] == 0){$numero_affaire7 = 'N°'.$data_dimanche['numero_affaire7'].' - '.$data_dimanche['heure_affaire7'].'H';}else {$numero_affaire7=$data_dimanche['formation'];} if($numero_affaire7 == "N° - H") {$numero_affaire7="Aucun";} echo $numero_affaire7; ?></td>
    </tr>
    <tr>
    <?php $totalsemaine = $totallundi + $totalmardi + $totalmercredi + $totaljeudi + $totalvendredi + $totalsamedi + $totaldimanche; 
    $totalnuit = $data_lundi['prime_nuit'] + $data_mardi['prime_nuit'] + $data_mercredi['prime_nuit'] + $data_jeudi['prime_nuit'] +  $data_vendredi['prime_nuit'] +  $data_samedi['prime_nuit'] + $data_dimanche['prime_nuit'];
    $totaldivers = $data_lundi['prime_divers'] + $data_mardi['prime_divers'] + $data_mercredi['prime_divers'] + $data_jeudi['prime_divers'] +  $data_vendredi['prime_divers'] +  $data_samedi['prime_divers'] + $data_dimanche['prime_divers'];
    $totalchefequipe = $data_lundi['prime_chef_equipe'] + $data_mardi['prime_chef_equipe'] + $data_mercredi['prime_chef_equipe'] + $data_jeudi['prime_chef_equipe'] +  $data_vendredi['prime_chef_equipe'] +  $data_samedi['prime_chef_equipe'] + $data_dimanche['prime_chef_equipe'];
    $totalhauteurM= $data_lundi['prime_hauteurM'] + $data_mardi['prime_hauteurM'] + $data_mercredi['prime_hauteurM'] + $data_jeudi['prime_hauteurM'] +  $data_vendredi['prime_hauteurM'] +  $data_samedi['prime_hauteurM'] + $data_dimanche['prime_hauteurM'];
    $totalfour = $data_lundi['prime_four'] + $data_mardi['prime_four'] + $data_mercredi['prime_four'] + $data_jeudi['prime_four'] +  $data_vendredi['prime_four'] +  $data_samedi['prime_four'] + $data_dimanche['prime_four'];
    $totalchaleur = $data_lundi['prime_chaleur'] + $data_mardi['prime_chaleur'] + $data_mercredi['prime_chaleur'] + $data_jeudi['prime_chaleur'] +  $data_vendredi['prime_chaleur'] +  $data_samedi['prime_chaleur'] + $data_dimanche['prime_chaleur'];
    $totalinsalubrite = $data_lundi['prime_insalubrite'] + $data_mardi['prime_insalubrite'] + $data_mercredi['prime_insalubrite'] + $data_jeudi['prime_insalubrite'] +  $data_vendredi['prime_insalubrite'] +  $data_samedi['prime_insalubrite'] + $data_dimanche['prime_insalubrite'];
    $totaltempsvoyage = $data_lundi['prime_temps_voyage'] + $data_mardi['prime_temps_voyage'] + $data_mercredi['prime_temps_voyage'] + $data_jeudi['prime_temps_voyage'] +  $data_vendredi['prime_temps_voyage'] +  $data_samedi['prime_temps_voyage'] + $data_dimanche['prime_temps_voyage'];
    $totalchauffeur = $data_lundi['prime_chauffeur'] + $data_mardi['prime_chauffeur'] + $data_mercredi['prime_chauffeur'] + $data_jeudi['prime_chauffeur'] +  $data_vendredi['prime_chauffeur'] +  $data_samedi['prime_chauffeur'] + $data_dimanche['prime_chauffeur'];
    $totalpanier = $data_lundi['prime_panier'] + $data_mardi['prime_panier'] + $data_mercredi['prime_panier'] + $data_jeudi['prime_panier'] +  $data_vendredi['prime_panier'] +  $data_samedi['prime_panier'] + $data_dimanche['prime_panier'];
    $totaldeplacement = $data_lundi['prime_deplacement'] + $data_mardi['prime_deplacement'] + $data_mercredi['prime_deplacement'] + $data_jeudi['prime_deplacement'] +  $data_vendredi['prime_deplacement'] +  $data_samedi['prime_deplacement'] + $data_dimanche['prime_deplacement'];
  
    
    ?>
      <th scope="row">Totaux</th>
      <td><?php echo $totalnuit; ?></td>
      <td><?php echo $totaldivers; ?></td>
      <td><?php echo $totalchefequipe; ?></td>
      <td><?php echo $totalhauteurM; ?></td>
      <td><?php echo $totalfour; ?></td>
      <td><?php echo $totalchaleur; ?></td>
      <td><?php echo $totalinsalubrite; ?></td>
      <td><?php echo $totaltempsvoyage; ?></td>
      <td><?php echo $totalchauffeur; ?></td>
      <td><?php echo $totalpanier; ?></td>
      <td><?php echo $totaldeplacement; ?></td>
      <td><?php echo $totalsemaine;?></td>

    </tr>
    <tr>
    <?php 
    if($totalsemaine > 39)
    {$surplus = $totalsemaine - 39;} 
    else{$surplus = 0;} 
    if($totalsemaine < 39)
    {$manque = $totalsemaine - 39;}
    else{$manque = 0;}
    $vingtcinq = 0;
    if($totalsemaine>44){$vingtcinq = $totalsemaine - 44;}
    if($vingtcinq >= 3){$test = $vingtcinq;}
    $cinquante = 0;
    if($totalsemaine>47){$cinquante = $totalsemaine - 47;}
    $test = $vingtcinq - $cinquante;
    $compteurplus = 0;
    if($totalsemaine>39){$compteurplus = $totalsemaine - 39;}
    if($compteurplus >= 5){$incremente = $compteurplus;}
    $incremente = $compteurplus - $vingtcinq;



    ?>
      <td colspan="2"><?php if(!empty($surplus)){echo $surplus;}else{echo $manque;} ?></td>
    </tr>
    <tr>
      <th>Compteur +</th>
      <td><?php echo $incremente;?></td>
    </tr>
    <th>Compteur - </th>
    <td><?php echo $manque;?></td>
    </tr>
    <th>A payer 25%</th>
    <td><?php echo $test; ?></td> 
    </tr>
    <th>A Payer 50%</th>
    <td><?php if(isset($cinquante)){echo $cinquante;}?></td>
    </tr>
  </tbody>
</table>


      <!-- Bootstrap core JavaScript
      ================================================== -->
      <!-- Placed at the end of the document so the pages load faster -->
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </body>
  </html>
  
  
<!--###################################################################--> 
<!--#                  Projet: Application de pointage                #-->  
<!--#                  Entreprise: Cegelec                            #-->  
<!--#                  Auteurs: Maverick Lafont & Emrik Lecomte       #--> 
<!--#                  Position: Job d'été MIJ                        #--> 
<!--#                  Scolaire: BTS SIO 2ième Année                  #--> 
<!--###################################################################--> 