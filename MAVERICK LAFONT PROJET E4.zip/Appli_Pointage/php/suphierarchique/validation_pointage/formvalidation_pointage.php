<?php
session_start('cegelec');
include "../../connexion.php";
$Session_login = !empty($_SESSION['username'])?$_SESSION['username']:NULL;

//on met la requête dans une variable ($sql)
  $sql = "SELECT * FROM employe WHERE username = '$Session_login' ";

  // on execute la requete :
  $resultat = mysqli_query ($cx, $sql) or die('Erreur SQL !<br>'.$sql.'<br>'.mysql_error());
  // retourne un tableau qui contient la première ligne de $resultat
  $data = mysqli_fetch_array($resultat);

  if(count($data)>0){ 
    $matricule=$data["matricule"];
  }

$date_debut = $_GET['date'];

$rq="select * from pointage_affaire where date_affaire='$date_debut' AND employe_matricule_affaire='$matricule';";
$rs=mysqli_query($cx,$rq) or die("Error: ".mysqli_error($cx));
if ($rq){
    $l=mysqli_fetch_array($rs);
}
else {
    echo "Erreur de la requete";
}
?>
<html>
  <head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="pointage_lundi.css"> 	
    <link rel="stylesheet" media="handheld" type="text/css" title="mobile" href="../css/mobile.css" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">
<title>Afficher / modifier</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">
  </head>

  <body>
  <nav class="site-header  navbar navbar-dark bg-secondary">
          <div class="container d-flex flex-column flex-md-row justify-content-between">
            <input type="button" class="btn btn btn-outline-light"  style="margin-left:25%; width:50%;" value="Retour" onclick="javascript:location.href='../../employe/mainpage.php?date=<?php echo $date_debut;?>'" >     
          </div>
        </nav>
        <?php
         
echo "<form method='POST' action='modifaffairelundi.php?date=$date_debut'>";
   #div de début de la carte affaire
   echo "<div class='row'>";
   echo "<div class='col-sm-6'>";
     echo "<div class='card bg-light mb-3'>";
     echo "<div class='card-header' style='text-align:center;'><h1>Affaires</h1></div>";
       echo "<div class='card-body'>";
#AFFAIRE 1
#NUMERO AFFAIRE 1
$req1="select * from affaire;";
$res1=mysqli_query($cx,$req1);

if ($l['numero_affaire1'] == 0) {$reponseaucun1 = "Aucune affaire enregistrée";} 
 if (!empty($l['numero_affaire1'])) {
  $reponseaucun1= $l['numero_affaire1'];
 }
if(isset($res1))
{
  echo "<span class='badge badge-dark' style='margin-left:42.8%;  width: 120px;'>N°1</span>";
  echo  "<div class='form-group'>";
  echo "<label for='exampleFormControlSelect1'></label>";
  echo "<select style='text-align: center;' name='numero_affaire1' class='custom-select' id='selectaffairelundi'>";
  
  $ligne=mysqli_fetch_array($res1);
  echo "<option value ='".$l['numero_affaire1']."'> ".$reponseaucun1."  </option>";
while($ligne!=false)
{

  echo "<option value ='".$ligne['num_affaire']."'> ".$ligne['num_affaire']." & ".$ligne['designation']." </option>";
  $ligne=mysqli_fetch_array($res1);
}
echo "</select><br/>";
}
  echo "</div>";

#HEURE AFFAIRE 1  
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend'>";
    echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
    echo "</div>"; 
  echo "<input type='number'  step='0.5'  name='heure_affaire1' value='$l[heure_affaire1]'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
echo "</div>";     

echo "<hr class='my-4'>";
######################################################################################################################################################################
#AFFAIRE 2
#NUMERO AFFAIRE 2
$req2="select * from affaire;";
$res2=mysqli_query($cx,$req2);

if ($l['numero_affaire2'] == 0) {$reponseaucun2 = "Aucune affaire enregistrée";} 
 if (!empty($l['numero_affaire2'])) {
  $reponseaucun2= $l['numero_affaire2'];
 }

if(isset($res2))
{
  echo "<span class='badge badge-dark' style='margin-left:42.8%;  width: 120px;'>N°2</span>";
  echo  "<div class='form-group'>";
  echo "<label for='exampleFormControlSelect1'></label>";
  echo "<select style='text-align: center;' name='numero_affaire2' class='custom-select' id='selectaffairelundi'>";
  
  $ligne=mysqli_fetch_array($res2);
  echo "<option value ='".$l['numero_affaire2']."'> ".$reponseaucun2." </option>";
while($ligne!=false)
{

  echo "<option value ='".$ligne['num_affaire']."'> ".$ligne['num_affaire']." & ".$ligne['designation']." </option>";
  $ligne=mysqli_fetch_array($res2);
}
echo "</select><br/>";
}
  echo "</div>";

#HEURE AFFAIRE 2 
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend'>";
    echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
    echo "</div>"; 
  echo "<input type='number'  step='0.5'  name='heure_affaire2' value='$l[heure_affaire2]' style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
echo "</div>";     

echo "<hr class='my-4'>";
######################################################################################################################################################################

#AFFAIRE 3
#NUMERO AFFAIRE 3
$req3="select * from affaire;";
$res3=mysqli_query($cx,$req3);

if ($l['numero_affaire3'] == 0) {$reponseaucun3 = "Aucune affaire enregistrée";} 
 if (!empty($l['numero_affaire3'])) {
  $reponseaucun3= $l['numero_affaire3'];
 }

if(isset($res3))
{
  echo "<span class='badge badge-dark' style='margin-left:42.8%;  width: 120px;'>N°3</span>";
  echo  "<div class='form-group'>";
  echo "<label for='exampleFormControlSelect1'></label>";
  echo "<select style='text-align: center;' name='numero_affaire3' class='custom-select' id='selectaffairelundi'>";
  
  $ligne=mysqli_fetch_array($res3);
  echo "<option value ='".$l['numero_affaire3']."'> ".$reponseaucun3." </option>";
while($ligne!=false)
{

  echo "<option value ='".$ligne['num_affaire']."'> ".$ligne['num_affaire']." & ".$ligne['designation']." </option>";
  $ligne=mysqli_fetch_array($res3);
}
echo "</select><br/>";
}
  echo "</div>";

#HEURE AFFAIRE 3
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend'>";
    echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
    echo "</div>"; 
  echo "<input type='number'  step='0.5'  name='heure_affaire3' value='$l[heure_affaire3]'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
echo "</div>";     

echo "<hr class='my-4'>";
######################################################################################################################################################################

#AFFAIRE 4
#NUMERO AFFAIRE 4
$req4="select * from affaire;";
$res4=mysqli_query($cx,$req4);

if ($l['numero_affaire4'] == 0) {$reponseaucun4 = "Aucune affaire enregistrée";} 
 if (!empty($l['numero_affaire4'])) {
  $reponseaucun4= $l['numero_affaire4'];
 }

if(isset($res4))
{
  echo "<span class='badge badge-dark' style='margin-left:42.8%;  width: 120px;'>N°4</span>";
  echo  "<div class='form-group'>";
  echo "<label for='exampleFormControlSelect1'></label>";
  echo "<select style='text-align: center;' name='numero_affaire4' class='custom-select' id='selectaffairelundi'>";
  
  $ligne=mysqli_fetch_array($res4);
  echo "<option value ='".$l['numero_affaire4']."'> ".$reponseaucun4." </option>";
while($ligne!=false)
{

  echo "<option value ='".$ligne['num_affaire']."'> ".$ligne['num_affaire']." & ".$ligne['designation']." </option>";
  $ligne=mysqli_fetch_array($res4);
}
echo "</select><br/>";
}
  echo "</div>";

#HEURE AFFAIRE 4
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend'>";
    echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
    echo "</div>"; 
  echo "<input type='number'  step='0.5'  name='heure_affaire4' value='$l[heure_affaire4]'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
echo "</div>";     

echo "<hr class='my-4'>";
######################################################################################################################################################################

#AFFAIRE 5
#NUMERO AFFAIRE 5
$req5="select * from affaire;";
$res5=mysqli_query($cx,$req5);

if ($l['numero_affaire5'] == 0) {$reponseaucun5 = "Aucune affaire enregistrée";} 
 if (!empty($l['numero_affaire5'])) {
  $reponseaucun5= $l['numero_affaire5'];
 }

if(isset($res5))
{
  echo "<span class='badge badge-dark' style='margin-left:42.8%;  width: 120px;'>N°5</span>";
  echo  "<div class='form-group'>";
  echo "<label for='exampleFormControlSelect1'></label>";
  echo "<select style='text-align: center;' name='numero_affaire5' class='custom-select' id='selectaffairelundi'>";
  
  $ligne=mysqli_fetch_array($res5);
  echo "<option value ='".$l['numero_affaire5']."'> ".$reponseaucun5." </option>";
while($ligne!=false)
{

  echo "<option value ='".$ligne['num_affaire']."'> ".$ligne['num_affaire']." & ".$ligne['designation']." </option>";
  $ligne=mysqli_fetch_array($res5);
}
echo "</select><br/>";
}
  echo "</div>";

#HEURE AFFAIRE 5
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend'>";
    echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
    echo "</div>"; 
  echo "<input type='number'  step='0.5'  name='heure_affaire5' value='$l[heure_affaire5]'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
echo "</div>";     

echo "<hr class='my-4'>";
######################################################################################################################################################################

#AFFAIRE 6
#NUMERO AFFAIRE 6
$req6="select * from affaire;";
$res6=mysqli_query($cx,$req6);

if ($l['numero_affaire6'] == 0) {$reponseaucun6 = "Aucune affaire enregistrée";} 
 if (!empty($l['numero_affaire6'])) {
  $reponseaucun5= $l['numero_affaire6'];
 }

if(isset($res6))
{
  echo "<span class='badge badge-dark' style='margin-left:42.8%;  width: 120px;'>N°6</span>";
  echo  "<div class='form-group'>";
  echo "<label for='exampleFormControlSelect1'></label>";
  echo "<select style='text-align: center;' name='numero_affaire6' class='custom-select' id='selectaffairelundi'>";
  
  $ligne=mysqli_fetch_array($res6);
  echo "<option value ='".$l['numero_affaire6']."'> ".$reponseaucun6." </option>";
while($ligne!=false)
{

  echo "<option value ='".$ligne['num_affaire']."'> ".$ligne['num_affaire']." & ".$ligne['designation']." </option>";
  $ligne=mysqli_fetch_array($res6);
}
echo "</select><br/>";
}
  echo "</div>";

#HEURE AFFAIRE 6
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend'>";
    echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
    echo "</div>"; 
  echo "<input type='number'  step='0.5'  name='heure_affaire6' value='$l[heure_affaire6]' style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
echo "</div>";     

echo "<hr class='my-4'>";
######################################################################################################################################################################

#AFFAIRE 7
#NUMERO AFFAIRE 7
$req7="select * from affaire;";
$res7=mysqli_query($cx,$req7);

if ($l['numero_affaire7'] == 0) {$reponseaucun7 = "Aucune affaire enregistrée";} 
 if (!empty($l['numero_affaire7'])) {
  $reponseaucun5= $l['numero_affaire7'];
 }

if(isset($res7))
{
  echo "<span class='badge badge-dark' style='margin-left:42.8%;  width: 120px;'>N°7</span>";
  echo  "<div class='form-group'>";
  echo "<label for='exampleFormControlSelect1'></label>";
  echo "<select style='text-align: center;' name='numero_affaire7' class='custom-select' id='selectaffairelundi'>";
  
  $ligne=mysqli_fetch_array($res7);
  echo "<option value ='".$l['numero_affaire7']."'> ".$reponseaucun7." </option>";
while($ligne!=false)
{

  echo "<option value ='".$ligne['num_affaire']."'> ".$ligne['num_affaire']." & ".$ligne['designation']." </option>";
  $ligne=mysqli_fetch_array($res7);
}
echo "</select><br/>";
}
  echo "</div>";

#HEURE AFFAIRE 7
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend' >";
    echo "<span class='input-group-text' style='width: 125px; text-align: center; margin-bottom: 41.2px;'>Heures</span>";
    echo "</div>"; 
  echo "<input type='number'  step='0.5'  name='heure_affaire7' value='$l[heure_affaire7]'  style='text-indent: 41.5%; margin-bottom: 41.2px;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
echo "</div>";     

######################################################################################################################################################################

#div de fin de la carte affaire
echo "</div>";
echo "</div>";
echo "</div>";

######################################################################################################################################################################
#div de début de la carte prime
echo "<div class='col-sm-6'>";
echo "<div class='card bg-light mb-3'>";
echo "<div class='card-header' style='text-align:center;'><h1>Primes</h1></div>";
  echo "<div class='card-body'>";

#PRIME NUIT
  echo "<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>NUIT</span>";    
  echo "<div class='input-group mb-3'>";
    echo "<div class='input-group-prepend'>";
      echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
      echo "</div>"; 
    echo "<input type='number'  step='0.5'  name='prime_nuit'  value='$l[prime_nuit]'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
  echo "</div>";     
  
  echo "<hr class='my-4'>";


#PRIME DIVERS
  echo "<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>DIVERS</span>";    
  echo "<div class='input-group mb-3'>";
    echo "<div class='input-group-prepend'>";
      echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
      echo "</div>"; 
    echo "<input type='number'  step='0.5'  name='prime_divers'  value='$l[prime_divers]'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
  echo "</div>";     
  
  echo "<hr class='my-4'>";

 #PRIME CHEF DEQUIPE
  echo "<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>CHEF D'EQUIPE</span>";    
  echo "<div class='input-group mb-3'>";
    echo "<div class='input-group-prepend'>";
      echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
      echo "</div>"; 
    echo "<input type='number'  step='0.5'  name='prime_chef_equipe'  value='$l[prime_chef_equipe]'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
  echo "</div>";     
  
  echo "<hr class='my-4'>";

  #PRIME HAUTEUR M
  echo "<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>HAUTEUR M</span>";    
  echo "<div class='input-group mb-3'>";
    echo "<div class='input-group-prepend'>";
      echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
      echo "</div>"; 
    echo "<input type='number'  step='0.5'  name='prime_hauteurM'  value='$l[prime_hauteurM]'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
  echo "</div>";     
  
  echo "<hr class='my-4'>";

  # PRIME FOUR
  echo "<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>FOUR</span>";    
  echo "<div class='input-group mb-3'>";
    echo "<div class='input-group-prepend'>";
      echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
      echo "</div>"; 
    echo "<input type='number'  step='0.5'  name='prime_four'  value='$l[prime_four]'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
  echo "</div>";     
  
  echo "<hr class='my-4'>";

#PRIME CHALEUR
echo "<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>CHALEUR</span>";    
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend'>";
    echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
    echo "</div>"; 
  echo "<input type='number'  step='0.5'  name='prime_chaleur'  value='$l[prime_chaleur]'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
echo "</div>";     

echo "<hr class='my-4'>";


#PRIME INSALUBRITE
echo "<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>INSALUBRITE</span>";    
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend'>";
    echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
    echo "</div>"; 
  echo "<input type='number'  step='0.5'  name='prime_insalubrite'  value='$l[prime_insalubrite]' style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
echo "</div>";     

echo "<hr class='my-4'>";

#PRIME TEMPS VOYAGE£
echo "<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>TEMPS VOYAGE</span>";    
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend'>";
    echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Franc CFP</span>";
    echo "</div>"; 
  echo "<input type='number'  step='0.5'  name='prime_temps_voyage'  value='$l[prime_temps_voyage]'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
echo "</div>";     

echo "<hr class='my-4'>";

#PRIME CHAUFFEUR
echo "<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>CHAUFFEUR</span>";    
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend'>";
    echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Franc CFP</span>";
    echo "</div>"; 
  echo "<input type='number'  step='0.5'  name='prime_chauffeur'  value='$l[prime_chauffeur]'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
echo "</div>";     

echo "<hr class='my-4'>";

#PRIME DEPLACEMENT
echo "<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>DEPLACEMENT</span>";    
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend'>";
    echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Franc CFP</span>";
    echo "</div>"; 
  echo "<input type='number'  step='0.5'  name='prime_deplacement'  value='$l[prime_deplacement]'  style='text-indent: 41.5%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
echo "</div>";     

echo "<hr class='my-4'>";

if($l['prime_panier'] == 1) {
  $autre = 0;
  $reponse = "OUI";
  $autre2 = 1;
  $reponse2 = "NON";
} if($l['prime_panier'] == 0) {
  $autre = 1;
  $reponse = "NON";
  $autre2 = 0;
  $reponse2 = "OUI";
}
#PRIME PANIER
echo "<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>PANIER</span>";    
echo "<div class='input-group mb-3'>";
  echo "<div class='input-group-prepend'>";
  echo "<span class='input-group-text' style='width: 125px; text-align: center;'>OUI/NON</span>";  
  echo "</div>";
  echo "<select  style='text-indent: 18%;' name='prime_panier' class='custom-select' id='inputGroupSelect01' >";
    echo "<option  value='$autre'>$reponse</option>";
    echo "<option value='$autre2'>$reponse2</option>";
  echo "</select>";
echo "</div>";
#div de fin de la carte prime
echo "</div>";
echo "</div>";
echo "</div>";
echo "</div>";
?>


 <!-- debut carte autres pointage-->


<!-- carte Absence à la journée -->
<div class="card text-center" style="margin-bottom: -18.5px;" >
  <div class="card-header">
   <h4> Autres </h4>
  </div>
  <div class="card-body">
  


  <div class="row">
  <div class="col-sm-6">
    <div class="card">
    <div class="card-header">Absence à la journée</div>
      <div class="card-body">
      
       <!-- radio boutons -->

      <?php 
      if (isset($l['absencej'])) {
        if (empty($l['absencej'])) {
          $checkedaucun = "checked";
        }
        if ($l['absencej'] == "M") {
          $checkedmaladie = "checked";
        }
        if ($l['absencej'] == "AT") {
          $checkedat = "checked";
        }
        if ($l['absencej'] == "ANA") {
          $checkedana = "checked";
        }
        if ($l['absencej'] == "JF") {
          $checkedjf = "checked";
        }
        if ($l['absencej'] == "CP") {
          $checkedcp = "checked";
        }
    } else {
      $checkedaucun = "checked";
    }
    if (isset($l['delegation'])) {
      $valdeleguation = $l['delegation'];
} else {

  $valdeleguation = "";
}
if (isset($l['visite_medicale'])) {
  $valvm = $l['visite_medicale'];
} else {

$valvm = "";
}
if (isset($l['formation'])) {
  $valformation = $l['formation'];
} else {

  $valformation = "";
}
      ?>

       <div class="card" >
  <ul class="list-group list-group-flush">
    <li class="list-group-item">

       <div class="form-check">
       <input class="form-check-input" type="radio" name="absencej" id="exampleRadios0"  value="" <?php if(isset($checkedaucun)){ echo $checkedaucun;} ?> >
       <label class="form-check-label" style="padding-right:20%; padding-left:20%; margin-left:-5%;" for="exampleRadios0" >
         Aucune
       </label>
     </div>
    </li>
  
<li class="list-group-item">
       <div class="form-check">
       <input class="form-check-input" type="radio" name="absencej" id="exampleRadios1" value="M" <?php if(isset($checkedmaladie)){ echo $checkedmaladie;} ?>>
       <label class="form-check-label" style="padding-right:20%; padding-left:20%; margin-left:-5%;" for="exampleRadios1">
         Maladie
       </label>
     </div>
  </li>

     <li class="list-group-item">
     <div class="form-check">
       <input class="form-check-input" type="radio" name="absencej" id="exampleRadios2" value="AT" <?php if(isset($checkedat)){ echo $checkedat;} ?>>
       <label class="form-check-label" style="padding-right:20%; padding-left:20%; margin-left:-5%;" for="exampleRadios2">
         Accident de travail
       </label>
     </div>
  </li>

  <li class="list-group-item">
     <div class="form-check">
       <input class="form-check-input" type="radio" name="absencej" id="exampleRadios3" value="ANA" <?php if(isset($checkedana)){ echo $checkedana;} ?>>
       <label class="form-check-label" style="padding-right:18%; padding-left:18%; margin-left:-5%;" for="exampleRadios3">
         Absence non autorisée
       </label>
     </div>
     </li>

     <li class="list-group-item">
     <div class="form-check">
       <input class="form-check-input" type="radio" name="absencej" id="exampleRadios4" value="JF" <?php if(isset($checkedjf)){ echo $checkedjf;} ?>>
       <label class="form-check-label" style="padding-right:20%; padding-left:20%; margin-left:-5%; " for="exampleRadios4">
         Jour férié
       </label>
     </div>
     </li>

     <li class="list-group-item">
     <div class="form-check">
       <input class="form-check-input" type="radio"  name="absencej" id="exampleRadios5" value="CP" <?php if(isset($checkedcp)){ echo $checkedcp;} ?>>
       <label class="form-check-label" style="padding-right:19%; padding-left:19%; margin-left:-5%; " for="exampleRadios5">
         Congé payé
       </label>
     </div>
     </li>
     </ul>
</div>

<!-- div fin carte absence journée -->
      </div>
    </div>
  </div>


<!-- carte Absence à l'heure -->
  <div class="col-sm-6">
    <div class="card">
    <div class="card-header">Absence à l'heure</div>
      <div class="card-body">
 

      <span class='badge badge-dark' style='  width: 120px;'>DELEGATION</span>    
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" style="width: 125px; text-align: center;">Heures</span>
  </div>
  <input type="number"  step="0.5"  name="delegation"  <?php echo "value='$l[delegation]'"?>  style='text-indent: 42%;' class="form-control" aria-label="Amount (to the nearest dollar)">
</div>      

<hr class='my-4'>
<span class='badge badge-dark' style='  width: 120px;'>VISITE MEDICALE</span>    
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" style="width: 125px; text-align: center;">Heures</span>
  </div>
  <input type="number"  step="0.5"  name="visite_medicale" <?php echo "value='$l[visite_medicale]'"?>  style='text-indent: 42%;' class="form-control" aria-label="Amount (to the nearest dollar)">
</div>      
<hr class='my-4'>
<span class='badge badge-dark' style='  width: 120px;'>FORMATION</span>    
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" style="width: 125px; text-align: center; margin-bottom:12.5px;">Heures</span>
  </div>
  <input type="number"  step="0.5"  name="formation" <?php echo "value='$l[formation]'"?> style='text-indent: 42%; margin-bottom:12.5px;' class="form-control" aria-label="Amount (to the nearest dollar)">
</div>      




       <!-- div fin de carte absence heure -->
      </div>
    </div>
  </div>
</div>

 
  </div>
  <div class="card-footer text-muted">
  <button type="submit" name='corriger' value='corriger' class="btn btn-danger" style="width:25%; margin-left:-0%;">corriger</button>
    <button type="submit" name='valider' value='valider' class="btn btn-success" style="width:25%; ">valider</button>


<!-- div fin de carte autres -->
  </div>
</div>


</form>
   <!-- Bootstrap core JavaScript
      ================================================== -->
      <!-- Placed at the end of the document so the pages load faster -->
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </body>
  </html>
  



    
<!--###################################################################--> 
<!--#                  Projet: Application de pointage                #-->  
<!--#                  Entreprise: Cegelec                            #-->  
<!--#                  Auteurs: Maverick Lafont & Emrik Lecomte       #--> 
<!--#                  Position: Job d'été MIJ                        #--> 
<!--#                  Scolaire: BTS SIO 2ième Année                  #--> 
<!--###################################################################--> 