<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>Dashboard Template for Bootstrap</title>

    <!-- Bootstrap core CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="../../css/gestion/gestionemp.css"> 	
    <!-- Custom styles for this template -->
 
  </head>

  <body>
      


    <header>
      <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
                <input type="button" class="btn btn btn-outline-light"  value="Gestion" onclick="javascript:location.href='../../index.php'" > 
                <input type="button" class="btn btn btn-outline-light"  value="Pointages" onclick="javascript:location.href='../suphierarchique/mainpsa.php'" > 
            <input type="button" class="btn btn btn-outline-light"  value="Déconnexion" onclick="javascript:location.href='../../index.php'" > 
      </nav>
    </header>

    <div class="container-fluid">
      <div class="row">
        <nav class="col-sm-3 col-md-2 d-none d-sm-block bg-light sidebar">
          <ul class="nav nav-pills flex-column">
            <li class="nav-item">
              <a class="nav-link active" href="#">Jean Sérien <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">patrick la trick</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">pierre paul jack</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">pierre qui roule</a>
            </li>
          </ul>
        </nav>

        <main role="main" class="col-sm-9 ml-sm-auto col-md-10 pt-3">
          <h1>pointage employé</h1>

          <div class="labelemp">
          <section class="row text-center placeholders">
            <div class="col-6 col-sm-3 placeholder">
              <img src="../../images/femmeprofile.png" width="200" height="200" class="img-fluid rounded-circle" alt="Generic placeholder thumbnail">
              <h4>Jean Sérien</h4>
              <div class="text-muted">Matricule: 2022</div>
              <div class="text-muted">Service: Actemium</div>
            </div>
          </section>
          </div>

          <h2>Pointage</h2>
          <div class="table table-bordered"> 
                <table class="table table-striped" id="qte">
                <thead class="thead-dark" id="form_qte"> 
                <tr>
                  <th>Jours</th>
                  <th>Total quotidien</th>
                  <th>N° d'affaire & Heures</th>
                  <th>Primes & Heures</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Lundi</td>
                  <td></td>
                  <td></td>
                  <td></td>

                </tr>
                <tr>
                  <td>Mardi</td>
                  <td></td>
                  <td></td>
                  <td></td>

                </tr>
                <tr>
                  <td>Mercredi</td>
                  <td></td>
                  <td></td>
                  <td></td>

                </tr>
                <tr>
                  <td>Jeudi</td>
                  <td></td>
                  <td></td>
                  <td></td>
 
                </tr>
                <tr>
                  <td>Vendredi</td>
                  <td></td>
                  <td></td>
                  <td></td>

                </tr>
                <tr>
                  <td>Samedi</td>
                  <td></td>
                  <td></td>
                  <td></td>

                </tr>
                <tr>
                  <td>Dimanche</td>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>

                <tr>
                  <td>Total</td>
                  <td></td>
                  
                </tr>
               
              </tbody>
            </table>
          </div>
        </main>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="../../../../assets/js/vendor/popper.min.js"></script>
    <script src="../../../../dist/js/bootstrap.min.js"></script>
  </body>
</html>
