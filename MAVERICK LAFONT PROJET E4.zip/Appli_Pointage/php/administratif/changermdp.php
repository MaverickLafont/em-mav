<?php
session_start('cegelec');
include "../connexion.php";
$Session_login = !empty($_SESSION['username'])?$_SESSION['username']:NULL;

if (isset($_POST['ancienmdp']) && isset($_POST['nouveaumdp']) && isset($_POST['confirmermdp']))
{
$ancienmdp=$_POST['ancienmdp'];
$nouveaumdp=$_POST['nouveaumdp'];
$confirmermdp=$_POST['confirmermdp'];
}


$sql = "SELECT * FROM employe WHERE username = '$Session_login' ";

// on execute la requete :
$resultat = mysqli_query ($cx, $sql) or die('Erreur SQL !<br>'.$sql.'<br>'.mysql_error());
// retourne un tableau qui contient la première ligne de $resultat
$data = mysqli_fetch_array($resultat);
mysqli_free_result ($resultat);

if ($ancienmdp == $data['pass_md5']){
    if ($nouveaumdp == $confirmermdp){
        $req=" UPDATE employe SET pass_md5='$confirmermdp' where username='$Session_login';" ;
        $rs=mysqli_query($cx,$req);
    }
    if ($nouveaumdp != $confirmermdp) {
        header('location: compte.php?mdp=2');
    }
}
if  ($ancienmdp != $data['pass_md5']){
    header('location: compte.php?mdp=0');
}
if($rs){
    header('location: compte.php?mdp=1');
} else {
    header('location: compte.php?mdp=0');
}

