<html>
  <head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="pointage_lundi.css"> 	
    <link rel="stylesheet" media="handheld" type="text/css" title="mobile" href="../css/mobile.css" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">
<title>Pointer</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">
  </head>
  <?php 
$date_debut = $_GET['date'];
?>
  <body>
  <nav class="site-header  navbar navbar-dark bg-dark">
          <div class="container d-flex flex-column flex-md-row justify-content-between">
            <input type="button" class="btn btn btn-outline-light"  style="margin-left:25%; width:50%;" value="Retour" onclick="javascript:location.href='../../suphierarchique/mainpsa.php?date=<?php echo $date_debut;?>'" > 

          </div>
        </nav>
        <script type="text/javascript">
<!--
    var timeout = setTimeout(
        function() {
            document.getElementById('pointage_enregistre').style.display = "none";
            clearTimeout(timeout);
            }
        ,2500); // temps en millisecondes
//-->
</script>
<?php 
if(isset($_GET['enregistrer'])) {
  switch ($_GET['enregistrer']) {
    case 0:
    echo "<div class='alert alert-danger' role='alert' id='pointage_enregistre' style='text-align:center;'>";
    echo 'Remplissez au moins une affaire !';
    echo "</div>"; break;
  }
}
$date_debut = $_GET['date'];
echo "<form method='post' action='pointagelundi.php?date=$date_debut'>";

include "../../connexion.php";

#################################################################################################################################    
#requette affaire n1 

$req="SELECT * from affaire inner join employe on affaire.matricule = employe.matricule;";
$res=mysqli_query($cx,$req);
if(!$res)
	{echo "la requete n'a pas pu etre executee";}
	else
	{

    #card affaires
    echo "<div class='row'>";
  echo "<div class='col-sm-6'>";
    echo "<div class='card bg-light mb-3'>";
    echo "<div class='card-header' style='text-align:center;'><h1>Affaires</h1></div>"; #div
      echo "<div class='card-body'>";

      echo "<span class='badge badge-dark' style='margin-left:43%;  width: 120px;'>N°1</span>";
      echo  "<div class='form-group'>";
      echo "<label for='exampleFormControlSelect1'></label>";
      echo "<select style='text-align: center;'  name='affairelundi'  class='custom-select' id='selectaffairelundi'>";
      echo "<option value='0'>Selectionner une affaire</option>";
      $ligne=mysqli_fetch_array($res);
	while($ligne!=false)
		{
      
      echo "<option value ='".$ligne['num_affaire']."' > ".$ligne['num_affaire']." & ".$ligne['designation']." & ".$ligne['nom']."  ".$ligne['prenom']."</option>";
      $ligne=mysqli_fetch_array($res);
    }
	echo "</select><br/>";
    }
      echo "</div>";

      echo "<div class='input-group mb-3'>";
      echo "<div class='input-group-prepend' >";
        echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
        echo "</div>"; 
      echo "<input type='number'  step='0.5'  name='heuresaffairelundi' style='text-indent: 42%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
    echo "</div>"; 
                          
      echo "<hr class='my-4'>";
      echo "<span class='badge badge-dark'style='margin-left:43%;  width: 120px;'>N°2</span>";

#################################################################################################################################     
#requette affaire n2

      $req2="SELECT * from affaire inner join employe on affaire.matricule = employe.matricule;";
$res2=mysqli_query($cx,$req2);
if(!$res2)
	{echo "la requete n'a pas pu etre executee";}
	else
	{
  
      echo  "<div class='form-group'>";
      echo "<label for='exampleFormControlSelect1'></label>";
      echo "<select style='text-align: center;' name='affairelundi2' class='custom-select' id='selectaffairelundi'>";
      echo "<option value='0'>Selectionner une affaire</option>";
     
      $ligne2=mysqli_fetch_array($res2);
	while($ligne2!=false)
		{
      echo "<option value ='".$ligne2['num_affaire']."'> ".$ligne2['num_affaire']." & ".$ligne2['designation']." </option>";
      $ligne2=mysqli_fetch_array($res2);
    }
	echo "</select><br/>";
    }
      echo "</div>";

      echo "<div class='input-group mb-3'>";
      echo "<div class='input-group-prepend' >";
        echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
        echo "</div>"; 
      echo "<input type='number'  step='0.5'  name='heuresaffairelundi2' style='text-indent: 42%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
    echo "</div>"; 

      echo "<hr class='my-4'>";
      echo "<span class='badge badge-dark'style='margin-left:43%;  width: 120px;'>N°3</span>";

#################################################################################################################################    
#requette affaire n3

      $req3="select * from affaire;";
      $res3=mysqli_query($cx,$req3);
      if(!$res3)
        {echo "la requete n'a pas pu etre executee";}
        else
        {
        
            echo  "<div class='form-group'>";
            echo "<label for='exampleFormControlSelect1'></label>";
            echo "<select style='text-align: center;' name='affairelundi3' class='custom-select' id='selectaffairelundi'>";
            echo "<option value='0'>Selectionner une affaire</option>";
            $ligne3=mysqli_fetch_array($res3);
        while($ligne3!=false)
          {
            echo "<option value ='".$ligne3['num_affaire']."'> ".$ligne3['num_affaire']." & ".$ligne3['designation']." </option>";
            $ligne3=mysqli_fetch_array($res3);
          }
        echo "</select><br/>";
          }
            echo "</div>";

            echo "<div class='input-group mb-3'>";
            echo "<div class='input-group-prepend' >";
              echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
              echo "</div>"; 
            echo "<input type='number'  step='0.5'  name='heuresaffairelundi3' style='text-indent: 42%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
          echo "</div>"; 

            echo "<hr class='my-4'>";
            echo "<span class='badge badge-dark' style='margin-left:43%;  width: 120px;'>N°4</span>";

#################################################################################################################################    
#requette affaire n4

            $req4="select * from affaire;";
            $res4=mysqli_query($cx,$req4);
            if(!$res4)
              {echo "la requete n'a pas pu etre executee";}
              else
              {
              
                  echo  "<div class='form-group'>";
                  echo "<label for='exampleFormControlSelect1'></label>";
                  echo "<select style='text-align: center;' name='affairelundi4' class='custom-select' id='selectaffairelundi'>";
                  echo "<option value='0'>Selectionner une affaire</option>";
                  $ligne4=mysqli_fetch_array($res4);
              while($ligne4!=false)
                {
                  echo "<option value ='".$ligne4['num_affaire']."'> ".$ligne4['num_affaire']." & ".$ligne4['designation']." </option>";
                  $ligne4=mysqli_fetch_array($res4);
                }
              echo "</select><br/>";
                }
                  echo "</div>";

                  echo "<div class='input-group mb-3'>";
                  echo "<div class='input-group-prepend' >";
                    echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
                    echo "</div>"; 
                  echo "<input type='number'  step='0.5'  name='heuresaffairelundi4' style='text-indent: 42%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
                echo "</div>"; 
                                      
                  echo "<hr class='my-4'>";
                  echo "<span class='badge badge-dark' style='margin-left:43%;  width: 120px;'>N°5</span>";

#################################################################################################################################       
#requette affaire n5

                  $req5="select * from affaire;";
                  $res5=mysqli_query($cx,$req5);
                  if(!$res5)
                    {echo "la requete n'a pas pu etre executee";}
                    else
                    {
                    
                        echo  "<div class='form-group'>";
                        echo "<label for='exampleFormControlSelect1'></label>";
                        echo "<select style='text-align: center;' name='affairelundi5' class='custom-select' id='selectaffairelundi'>";
                        echo "<option value='0'>Selectionner une affaire</option>";
                        $ligne5=mysqli_fetch_array($res5);
                    while($ligne5!=false)
                      {
                        echo "<option value ='".$ligne5['num_affaire']."'> ".$ligne5['num_affaire']." & ".$ligne5['designation']." </option>";
                        $ligne5=mysqli_fetch_array($res5);
                      }
                    echo "</select><br/>";
                      }
                        echo "</div>";

                   echo "<div class='input-group mb-3'>";
                  echo "<div class='input-group-prepend' >";
                    echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
                    echo "</div>"; 
                  echo "<input type='number'  step='0.5'  name='heuresaffairelundi5' style='text-indent: 42%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
                echo "</div>"; 
                                             
                  echo "<hr class='my-4'>";
                  echo "<span class='badge badge-dark' style='margin-left:43%;  width: 120px;'>N°6</span>";
#################################################################################################################################       
#requette affaire n6

                  $req6="select * from affaire;";
                  $res6=mysqli_query($cx,$req6);
                  if(!$res6)
                    {echo "la requete n'a pas pu etre executee";}
                    else
                    {
                    
                        echo  "<div class='form-group'>";
                        echo "<label for='exampleFormControlSelect1'></label>";
                        echo "<select style='text-align: center;' name='affairelundi6' class='custom-select' id='selectaffairelundi'>";
                        echo "<option value='0'>Selectionner une affaire</option>";
                        $ligne6=mysqli_fetch_array($res6);
                    while($ligne6!=false)
                      {
                        echo "<option value ='".$ligne6['num_affaire']."'> ".$ligne6['num_affaire']." & ".$ligne6['designation']." </option>";
                        $ligne6=mysqli_fetch_array($res6);
                      }
                    echo "</select><br/>";
                      }
                        echo "</div>";

                        echo "<div class='input-group mb-3'>";
                        echo "<div class='input-group-prepend' >";
                          echo "<span class='input-group-text' style='width: 125px; text-align: center;'>Heures</span>";
                          echo "</div>"; 
                        echo "<input type='number'  step='0.5'  name='heuresaffairelundi6' style='text-indent: 42%;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
                      echo "</div>";                          

                        echo "<hr class='my-4'>";
                        echo "<span class='badge badge-dark' style='margin-left:43%;  width: 120px;'>N°7</span>";
#################################################################################################################################       
#requette affaire n7

$req7="select * from affaire;";
$res7=mysqli_query($cx,$req7);
if(!$res7)
  {echo "la requete n'a pas pu etre executee";}
  else
  {
  
      echo  "<div class='form-group'>";
      echo "<label for='exampleFormControlSelect1'></label>";
      echo "<select style='text-align: center;' name='affairelundi7' class='custom-select' id='selectaffairelundi'>";
      echo "<option value='0'>Selectionner une affaire</option>";
      $ligne7=mysqli_fetch_array($res7);
  while($ligne7!=false)
    {
      echo "<option value ='".$ligne7['num_affaire']."'> ".$ligne7['num_affaire']." & ".$ligne7['designation']." </option>";
      $ligne7=mysqli_fetch_array($res7);
    }
  echo "</select><br/>";
    }
      echo "</div>";

      echo "<div class='input-group mb-3'>";
      echo "<div class='input-group-prepend' >";
        echo "<span class='input-group-text' style=' text-align: center; margin-bottom: 55px;'>Heures</span>";
        echo "</div>"; 
      echo "<input type='number'  step='0.5'  name='heuresaffairelundi7' style='text-indent: 42%; margin-bottom: 55px;' class='form-control' aria-label='Amount (to the nearest dollar)'>";
    echo "</div>";     

      
#################################################################################################################################      
         
#fin de la div card affaire
echo "</div>";
echo "</div>";
echo "</div>";                           
 ?>     
  <!-- card prime -->
  <div class="col-sm-6" >
    <div class="card bg-light mb-3" >
    <div class="card-header" style="text-align:center;"><h1>Primes</h1></div>
      <div class="card-body" >
         
<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>NUIT</span>    
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" style="width: 125px; text-align: center;">Heures</span>
  </div>
  <input type="number"  step="0.5"  name="heuresnuitlundi"  id="selectheureslundi"  style='text-indent: 42%;' class="form-control" aria-label="Amount (to the nearest dollar)">
</div>      

<hr class="my-4">
<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>DIVERS</span>

<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" style="width: 125px; text-align: center;">Heures</span>
  </div>
  <input type="number"  step="0.5"  name="heuresdiverslundi"  id="selectheureslundi"  style='text-indent: 42%;' class="form-control" aria-label="Amount (to the nearest dollar)">
</div>           

<hr class="my-4">
<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>CHEF D'EQUIPE</span>
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" style="width: 125px; text-align: center;">Heures</span>
  </div>
  <input type="number"  step="0.5"  name="heureschefequipelundi"  id="selectheureslundi"  style='text-indent: 42%;' class="form-control" aria-label="Amount (to the nearest dollar)">
</div>                      

<hr class="my-4">
<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>HAUTEUR M</span>
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" style="width: 125px; text-align: center;">Heures</span>
  </div>
  <input type="number"  step="0.5"  name="heureshauteurmlundi"  id="selectheureslundi"  style='text-indent: 42%;' class="form-control" aria-label="Amount (to the nearest dollar)">
</div>                 

<hr class="my-4">
<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>FOUR</span>
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" style="width: 125px; text-align: center;">Heures</span>
  </div>
  <input type="number"  step="0.5"  name="heuresfourlundi"  id="selectheureslundi"  style='text-indent: 42%;' class="form-control" aria-label="Amount (to the nearest dollar)">
</div>                 

<hr class="my-4">
<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>CHALEUR</span>
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" style="width: 125px; text-align: center;">Heures</span>
  </div>
  <input type="number"  step="0.5"  name="heureschaleurlundi"  id="selectheureslundi"  style='text-indent: 42%;' class="form-control" aria-label="Amount (to the nearest dollar)">
</div>

<hr class="my-4">
<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>INSALUBRITE</span>
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" style="width: 125px; text-align: center;">Heures</span>
  </div>
  <input type="number"  step="0.5"  name="heuresinsalubritelundi"  id="selectheureslundi"  style='text-indent: 42%;' class="form-control" aria-label="Amount (to the nearest dollar)">
</div>

<hr class="my-4">
<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>TEMPS VOYAGES</span>
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" style="width: 125px; text-align: center;">Franc CFP</span>
  </div>
  <input type="number"  name="montanttempsvoyagelundi"  id="selectmontantlundi" style='text-indent: 42%;' class="form-control" aria-label="Amount (to the nearest dollar)">
</div>                         

<hr class="my-4">
<span class='badge badge-dark' style='margin-left:43.5%;  width: 120px;'>CHAUFFEUR</span>
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" style="width: 125px; text-align: center;">Franc CFP</span>
  </div>
  <input type="number"  name="montantchauffeurlundi"  id="selectmontantlundi"  style='text-indent: 42%;' class="form-control" aria-label="Amount (to the nearest dollar)">
</div>

<hr class="my-4">
<span class='badge badge-dark' style='margin-left:43.5%; width: 120px;'>DEPLACEMENT</span>
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" style="width: 125px; text-align: center;">Franc CFP</span>
  </div>
  <input type="number"  name="montantdeplacementlundi"  id="selectmontantlundi"  style='text-indent: 42%;' class="form-control" aria-label="Amount (to the nearest dollar)">
</div>
   
<hr class="my-4">
<span class='badge badge-dark' style='margin-left:43.5%; width: 120px;'>PANIER</span>
<div class="input-group mb-3">
  <div class="input-group-prepend">
  <span class="input-group-text" style="width: 125px; text-align: center; margin-bottom: 12.5px;">OUI/NON</span>
  </div>
  <select  style='text-indent: 18.1%;' name="primepanier" class="custom-select" id="inputGroupSelect01" >
    <option  value="1">OUI</option>
    <option value="0">NON</option>
  </select>
</div>


<!-- div de fin de cartes -->
</div>
</div>
</div>
</div>


<!-- carte Absence à la journée -->
<div class="card text-center" style="margin-bottom: -18.5px;" >
  <div class="card-header">
   <h4> Autres </h4>
  </div>
  <div class="card-body">
  


  <div class="row">
  <div class="col-sm-6">
    <div class="card">
    <div class="card-header">Absence à la journée</div>
      <div class="card-body">
      

       <!-- radio boutons -->

       <div class="card" >
  <ul class="list-group list-group-flush">
    <li class="list-group-item">

       <div class="form-check">
       <input class="form-check-input" type="radio" name="absencej" id="exampleRadios0"  value="" checked>
       <label class="form-check-label" style="padding-right:20%; padding-left:20%; margin-left:-5%;" for="exampleRadios0" >
         Aucune
       </label>
     </div>
    </li>
  
<li class="list-group-item">
       <div class="form-check">
       <input class="form-check-input" type="radio" name="absencej" id="exampleRadios1" value="M" >
       <label class="form-check-label" style="padding-right:20%; padding-left:20%; margin-left:-5%;" for="exampleRadios1">
         Maladie
       </label>
     </div>
  </li>

     <li class="list-group-item">
     <div class="form-check">
       <input class="form-check-input" type="radio" style="  " name="absencej" id="exampleRadios2" value="AT">
       <label class="form-check-label" style="padding-right:20%; padding-left:20%; margin-left:-5%;" for="exampleRadios2">
         Accident de travail
       </label>
     </div>
  </li>

  <li class="list-group-item">
     <div class="form-check">
       <input class="form-check-input" type="radio" style="  "  name="absencej" id="exampleRadios3" value="ANA" >
       <label class="form-check-label" style="padding-right:18%; padding-left:18%; margin-left:-5%;" for="exampleRadios3">
         Absence non autorisée
       </label>
     </div>
     </li>

     <li class="list-group-item">
     <div class="form-check">
       <input class="form-check-input" type="radio" name="absencej" id="exampleRadios4" value="JF" >
       <label class="form-check-label" style="padding-right:20%; padding-left:20%; margin-left:-5%; " for="exampleRadios4">
         Jour férié
       </label>
     </div>
     </li>

     <li class="list-group-item">
     <div class="form-check">
       <input class="form-check-input" type="radio"  name="absencej" id="exampleRadios5" value="CP" >
       <label class="form-check-label" style="padding-right:19%; padding-left:19%; margin-left:-5%; " for="exampleRadios5">
         Congé payé
       </label>
     </div>
     </li>
     </ul>
</div>

<!-- div fin carte absence journée -->
      </div>
    </div>
  </div>


<!-- carte Absence à l'heure -->
  <div class="col-sm-6">
    <div class="card">
    <div class="card-header">Absence à l'heure</div>
      <div class="card-body">
 

      <span class='badge badge-dark' style='  width: 120px;'>DELEGATION</span>    
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" style="width: 125px; text-align: center;">Heures</span>
  </div>
  <input type="number"  step="0.5"  name="delegation"    style='text-indent: 42%;' class="form-control" aria-label="Amount (to the nearest dollar)">
</div>      

<hr class='my-4'>
<span class='badge badge-dark' style='  width: 120px;'>VISITE MEDICALE</span>    
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" style="width: 125px; text-align: center;">Heures</span>
  </div>
  <input type="number"  step="0.5"  name="visite_medicale"   style='text-indent: 42%;' class="form-control" aria-label="Amount (to the nearest dollar)">
</div>      
<hr class='my-4'>
<span class='badge badge-dark' style='  width: 120px;'>FORMATION</span>    
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" style="width: 125px; text-align: center; margin-bottom:12.5px;">Heures</span>
  </div>
  <input type="number"  step="0.5"  name="formation" style='text-indent: 42%; margin-bottom:12.5px;' class="form-control" aria-label="Amount (to the nearest dollar)">
</div>      




       <!-- div fin de carte absence heure -->
      </div>
    </div>
  </div>
</div>

 
  </div>
  <div class="card-footer text-muted">
  <button type="submit" name='enregistrer' value='ENREGISTRER' class="btn btn-danger" style="margin-left: 1%; width:29%;">Enregistrer</button>

<!-- div fin de carte autres -->
  </div>
</div>

</form>
        
      <!-- Bootstrap core JavaScript
      ================================================== -->
      <!-- Placed at the end of the document so the pages load faster -->
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </body>
  </html>
  


<!--###################################################################--> 
<!--#                  Projet: Application de pointage                #-->  
<!--#                  Entreprise: Cegelec                            #-->  
<!--#                  Auteurs: Maverick Lafont & Emrik Lecomte       #--> 
<!--#                  Position: Job d'été MIJ                        #--> 
<!--#                  Scolaire: BTS SIO 2ième Année                  #--> 
<!--###################################################################--> 