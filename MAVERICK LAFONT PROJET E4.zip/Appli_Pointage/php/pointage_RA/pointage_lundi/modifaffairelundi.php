<?php
session_start('cegelec');
include "../../connexion.php";
$Session_login = !empty($_SESSION['username'])?$_SESSION['username']:NULL;

//on met la requête dans une variable ($sql)
  $sql = "SELECT * FROM employe WHERE username = '$Session_login' ";

  // on execute la requete :
  $resultat = mysqli_query ($cx, $sql) or die('Erreur SQL !<br>'.$sql.'<br>'.mysql_error());
  // retourne un tableau qui contient la première ligne de $resultat
  $data = mysqli_fetch_array($resultat);
  $date_debut = $_GET['date'];

  if(count($data)>0){ 
  $matricule=$data["matricule"];
}

$numero_affaire1=$_POST['numero_affaire1'];
$heure_affaire1=$_POST['heure_affaire1'];
$numero_affaire2=$_POST['numero_affaire2'];
$heure_affaire2=$_POST['heure_affaire2'];
$numero_affaire3=$_POST['numero_affaire3'];
$heure_affaire3=$_POST['heure_affaire3'];
$numero_affaire4=$_POST['numero_affaire4'];
$heure_affaire4=$_POST['heure_affaire4'];
$numero_affaire5=$_POST['numero_affaire5'];
$heure_affaire5=$_POST['heure_affaire5'];
$numero_affaire6=$_POST['numero_affaire6'];
$heure_affaire6=$_POST['heure_affaire6'];
$numero_affaire7=$_POST['numero_affaire7'];
$heure_affaire7=$_POST['heure_affaire7'];


$prime_nuit=$_POST['prime_nuit'];
$prime_divers=$_POST['prime_divers'];
$prime_chef_equipe=$_POST['prime_chef_equipe'];
$prime_hauteurM=$_POST['prime_hauteurM'];
$prime_four=$_POST['prime_four'];
$prime_chaleur=$_POST['prime_chaleur'];
$prime_insalubrite=$_POST['prime_insalubrite'];
$prime_temps_voyage=$_POST['prime_temps_voyage'];
$prime_chauffeur=$_POST['prime_chauffeur'];
$prime_deplacement=$_POST['prime_deplacement'];
$prime_panier=$_POST['prime_panier'];


$absencej=$_POST['absencej'];
$delegation=$_POST['delegation'];
$visite_medicale=$_POST['visite_medicale'];
$formation=$_POST['formation'];


$rq="update pointage_affaire set
numero_affaire1='$numero_affaire1',
heure_affaire1='$heure_affaire1',
numero_affaire2='$numero_affaire2',
heure_affaire2='$heure_affaire2',
numero_affaire3='$numero_affaire3',
heure_affaire3='$heure_affaire3',
numero_affaire4='$numero_affaire4',
heure_affaire4='$heure_affaire4',
numero_affaire5='$numero_affaire5',
heure_affaire5='$heure_affaire5',
numero_affaire6='$numero_affaire6',
heure_affaire6='$heure_affaire6',
numero_affaire7='$numero_affaire7',
heure_affaire7='$heure_affaire7',


prime_nuit='$prime_nuit',
prime_divers='$prime_divers',
prime_chef_equipe='$prime_chef_equipe',
prime_hauteurM='$prime_hauteurM',
prime_four='$prime_four',
prime_chaleur='$prime_chaleur',
prime_insalubrite='$prime_insalubrite',
prime_temps_voyage='$prime_temps_voyage',
prime_chauffeur='$prime_chauffeur',
prime_deplacement='$prime_deplacement',
prime_panier='$prime_panier',
absencej='$absencej',
delegation='$delegation',
visite_medicale='$visite_medicale',
formation='$formation' where date_affaire='$date_debut' AND employe_matricule_affaire='$matricule';";
$rs=mysqli_query($cx,$rq);
if(!$rs)
{
  header('location: ../../suphierarchique/mainpsa.php?modifier=0&date='.$date_debut);
}
	else
    {
      header('location: ../../suphierarchique/mainpsa.php?modifier=1&date='.$date_debut);
    }

?>