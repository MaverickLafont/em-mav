<?php 
include("../connexion.php");
$matricule = $_GET['matricule'];
$semaine = $_GET['semaine'];
$date_debut = $_GET['date'];
$requet_notification="update pointage_affaire set
validation_RA='1' WHERE S='$semaine' AND employe_matricule_affaire='$matricule' AND validation_RA='0';";
$rs=mysqli_query($cx,$requet_notification);
if(!$rs)
{
  header('location: mainadmin.php?validation=0&date='.$date_debut.'&semaine='.$semaine .'&matricule='.$matricule);
}
	else
    {
      header('location: mainadmin.php?validation=1&date='.$date_debut.'&semaine='.$semaine .'&matricule='.$matricule);
    }
  ?>