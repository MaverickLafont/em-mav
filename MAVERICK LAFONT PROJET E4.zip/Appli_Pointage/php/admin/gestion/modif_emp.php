<?php
include('../../connexion.php');
    $nommodif = $_POST['nommodif'];
    $prenommodif = $_POST['prenommodif'];
    $matriculemodif = $_POST['matriculemodif'];
    $servicemodif = $_POST['servicemodif'];
    $usernamemodif = $_POST['usernamemodif'];
    $positionmodif = $_POST['positionmodif'];
    $passwordmodif = $_POST['passwordmodif'];
    $ramodif = $_POST['ramodif'];
    $matricule_a_modifier = $_GET['matricule'];

    if(isset($_POST['btn_modifier']))
    if($positionmodif == '0') {
      $ramod = 0;
      $adminmod = 0;
      $adparcmod = 0;
    }
    elseif($positionmodif == 'ra') {
      $ramod = 1;
      $adminmod = 0;
      $adparcmod = 0;
    }
    elseif($positionmodif == 'ap') {
      $ramod = 0;
      $adminmod = 0;
      $adparcmod = 1;
    }
    elseif($positionmodif == 'ce') {
      $ramod = 0;
      $adminmod = 1;
      $adparcmod = 0;
    }
    
    $reqmodif="update employe set
    nom='$nommodif',
    prenom='$prenommodif',
    matricule='$matriculemodif',
    service='$servicemodif',
    username='$usernamemodif',
    pass_md5='$passwordmodif',
    RA='$ramod',
    ADMIN='$adminmod',
    ADPARC='$adparcmod',
    ra_employe='$ramodif' where matricule = ".$matricule_a_modifier." ;";
    $resmodif=mysqli_query($cx,$reqmodif);

    if($resmodif){
        header('location: gestion_emp.php?modification=oui');
    } else{
        header('location: gestion_emp.php?modification=non');
    }
    ?>