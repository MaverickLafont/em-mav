<?php
    include('../../connexion.php');
    $nom = $_POST['nom'];
  $prenom = $_POST['prenom'];
  $matricule = $_POST['matricule'];
  $service = $_POST['service'];

  $username = $_POST['username'];
  $password = $_POST['password'];
  $position = $_POST['position'];
  $ra = $_POST['ajouterra'];

  if($position == '0') {
    $ramod = 0;
    $adminmod = 0;
    $adparcmod = 0;
  }
  elseif($position == 'ra') {
    $ramod = 1;
    $adminmod = 0;
    $adparcmod = 0;
  }
  elseif($position == 'ap') {
    $ramod = 0;
    $adminmod = 0;
    $adparcmod = 1;
  }
  elseif($position == 'ce') {
    $ramod = 0;
    $adminmod = 1;
    $adparcmod = 0;
  }
  
  $reqajout="insert into employe (nom,prenom,matricule,service,username,pass_md5,RA,ADMIN,ADPARC,ra_employe)
  VALUES ('$nom',
  '$prenom',
  '$matricule',
  '$service',
  '$username',
  '$password',
  '$ramod',
  '$adminmod',
  '$adparcmod',
  '$ra')";
  $resajout=mysqli_query($cx,$reqajout);

  if($resajout){
    header('location: gestion_emp.php?ajout=oui');
  } else {
    header('location: gestion_emp.php?ajout=non');
  }

  ?>