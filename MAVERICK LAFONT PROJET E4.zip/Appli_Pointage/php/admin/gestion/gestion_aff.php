<?php 
  session_start('cegelec');
  $erreur=false;
if(isset($_SESSION['username'])){
    if($_SESSION['username'] != true){
        $erreur=true;
    }
}else{$erreur=true;}
if($erreur){
    header('Location: ../../index.php');
}
unset($erreur);
?>
<?php include('../../connexion.php'); ?>
<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="../../css/admin/mainadmin.css"> 	
    <link rel="stylesheet" media="handheld" type="text/css" title="mobile" href="../css/mobile.css" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../images/pointage.ico">


<title>Rapport d'activité hebdomadaire</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">
  
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">
.bs-example{
margin: 20px;
}
</style>
  
  
  </head>

  <body>
      

  <?php 
          $Session_login = !empty($_SESSION['username'])?$_SESSION['username']:NULL;

          //on met la requête dans une variable ($sql)
            $sql = "SELECT * FROM employe WHERE username = '$Session_login' ";
  
            // on execute la requete :
            $resultat = mysqli_query ($cx, $sql) or die('Erreur SQL !<br>'.$sql.'<br>'.mysql_error());
            // retourne un tableau qui contient la première ligne de $resultat
            $data = mysqli_fetch_array($resultat);
            mysqli_free_result ($resultat); 


            $requet_archive = "SELECT COUNT(DISTINCT S, employe_matricule_affaire) FROM pointage_affaire WHERE validation_RA='1' AND notif='1';";
            $requet_resultat_archive = mysqli_query ($cx, $requet_archive) or die('Erreur SQL !<br>'.$requet_archive.'<br>'.mysql_error());
            $data_archive = mysqli_fetch_array($requet_resultat_archive);
            mysqli_free_result ($requet_resultat_archive);
            if($data_archive['COUNT(DISTINCT S, employe_matricule_affaire)'] == 0) {
              $archive = 0;
            } else {
              $archive = $data_archive['COUNT(DISTINCT S, employe_matricule_affaire)'];
            }

?>

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark" >
  <div class="navbar-collapse collapse" id="navbarColor01" style="">
    <ul class="navbar-nav mr-auto">
    <li class="nav-item">
        <a class="nav-link" href="../mainadmin.php">Accueil</a>
      </li>
    <li class="nav-item">
    <a class="nav-link" href="gestion_emp.php">Gestion employé</a>
    </li>
    <li class="nav-item active">
    <a class="nav-link" href="#">Gestion affaire</a>
    </li>
      <li class="nav-item">
        <a class="nav-link" href="../archive/archive_emp_admin.php">Archive<span class="badge badge-danger"><?php echo $archive;?></span></a></a>
      </li>
    <li class="nav-item">
        <a class="nav-link" href="javascript:location.href='../../logout.php'">deconnexion<span class="sr-only">(current)</span></a>
      </li>
    </ul>
  </div>
</nav>



<script type="text/javascript">
<!--
    var timeout = setTimeout(
        function() {
            document.getElementById('pointage_enregistre').style.display = "none";
            clearTimeout(timeout);
            }
        ,5000); // temps en millisecondes
//-->
</script>


<div class="card text-center">
  <div class="card-header">
   Gestion Affaires
  </div>
  <div class="card-body">


  <form method="post" action="importaff.php" enctype="multipart/form-data">
<div class="card text-center">
  <div class="card-header">
    Importer base d'affaire
  </div>
  <div class="card-body">
 <br>
<h4><span class="badge badge-danger">Uniquement les fichier .CSV</span></h4>
<br>
<div class="card" style="width:30%; margin-left:35%;">
  <div class="card-body">
  <input type="file" style="margin-left:25%;" name="importaff" class="form-control-file" id="exampleFormControlFile1" >
  </div>
</div>

 
 <br>
<!-- Progress bar HTML -->
<div class="progress-bar progress-bar-striped progress-bar-animated bg-dark"></div>

<?php 
if(isset($_GET['erreur'])) {
    switch ($_GET['erreur']) {
      case 1:
      echo "<div class='alert alert-danger' role='alert' id='pointage_enregistre' style='text-align:center;'>";
      echo 'Aucun fichier sélectionné';
      echo "</div>"; break;
      
    }
  }
?>
<?php 
  if(isset($_GET['nombre'])) {
      $nombre_requet = $_GET['nombre'];
    }

if(isset($_GET['good'])) {
    switch ($_GET['good']) {
      case 1:
      echo "<div class='alert alert-success' role='alert' id='pointage_enregistre' style='text-align:center;'>";
      echo $nombre_requet.' Affaire ont été importée dans la base de donnée ';
      echo "</div>"; break;
      
    }
  }

?>


  </div>
  <div class="card-footer text-muted">
  <p> <?php $fichier_nom ?> </p>
    <input type="submit" class="btn btn-outline-dark" name="bouton_date_debut" onclick="makeProgress()" value="Importer" />
  </div>
</div>



<!-- jQuery Script -->
<script type="text/javascript">
var i = 0;
function makeProgress(){
if(i < 100){
i = i + 1;
$(".progress-bar").css("width", i + "%").text(i + " %");
}
// Wait for sometime before running this script again
setTimeout("makeProgress()", 40);
}

</script>



</form>













      
      <!-- Bootstrap core JavaScript
      ================================================== -->
      <!-- Placed at the end of the document so the pages load faster -->
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </body>
  </html>
  
  
  <!-- Projet réalisé par Maverick Lafont et Emrik Lecomte --> 