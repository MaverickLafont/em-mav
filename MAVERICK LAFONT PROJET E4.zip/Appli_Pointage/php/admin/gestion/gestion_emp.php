<?php 
  session_start('cegelec');
  $erreur=false;
if(isset($_SESSION['username'])){
    if($_SESSION['username'] != true){
        $erreur=true;
    }
}else{$erreur=true;}
if($erreur){
    header('Location: ../../../index.php');
}
unset($erreur);
?>


<?php include('../../connexion.php'); ?>
<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="../../css/admin/mainadmin.css"> 	
    <link rel="stylesheet" media="handheld" type="text/css" title="mobile" href="../css/mobile.css" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../images/pointage.ico">


<title>Rapport d'activité hebdomadaire</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">
    <script type="text/javascript">
<!--
    var timeout = setTimeout(
        function() {
            document.getElementById('pointage_enregistre').style.display = "none";
            clearTimeout(timeout);
            }
        ,2500); // temps en millisecondes
//-->
</script>
  </head>

  <body>
  <?php 
          $Session_login = !empty($_SESSION['username'])?$_SESSION['username']:NULL;

          //on met la requête dans une variable ($sql)
            $sql = "SELECT * FROM employe WHERE username = '$Session_login' ";
  
            // on execute la requete :
            $resultat = mysqli_query ($cx, $sql) or die('Erreur SQL !<br>'.$sql.'<br>'.mysql_error());
            // retourne un tableau qui contient la première ligne de $resultat
            $data = mysqli_fetch_array($resultat);
            mysqli_free_result ($resultat); 


            $requet_archive = "SELECT COUNT(DISTINCT S, employe_matricule_affaire) FROM pointage_affaire WHERE validation_RA='1' AND notif='1';";
            $requet_resultat_archive = mysqli_query ($cx, $requet_archive) or die('Erreur SQL !<br>'.$requet_archive.'<br>'.mysql_error());
            $data_archive = mysqli_fetch_array($requet_resultat_archive);
            mysqli_free_result ($requet_resultat_archive);
            if($data_archive['COUNT(DISTINCT S, employe_matricule_affaire)'] == 0) {
              $archive = 0;
            } else {
              $archive = $data_archive['COUNT(DISTINCT S, employe_matricule_affaire)'];
            }

?>

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark" >
  <div class="navbar-collapse collapse" id="navbarColor01" style="">
    <ul class="navbar-nav mr-auto">
    <li class="nav-item">
        <a class="nav-link" href="../mainadmin.php">Accueil</a>
      </li>
    <li class="nav-item active">
    <a class="nav-link" href="#">Gestion employé</a>
    </li>
    <li class="nav-item">
    <a class="nav-link" href="gestion_aff.php">Gestion affaire</a>
    </li>
      <li class="nav-item">
        <a class="nav-link" href="../archive/archive_emp_admin.php">Archive<span class="badge badge-danger"><?php echo $archive;?></span></a></a>
      </li>
    <li class="nav-item">
        <a class="nav-link" href="javascript:location.href='../../logout.php'">deconnexion<span class="sr-only">(current)</span></a>
      </li>
    </ul>
  </div>
</nav>



<div class="card text-center">
  <div class="card-header">
   Gestion Employés
  </div>
  <div class="card-body">
   


<form method='post' action=''>

 <?php 
$req="select * from employe order by nom;";
$res=mysqli_query($cx,$req);
if(!$res)
	{echo "la requete n'a pas pu etre executee";}
	else{
echo '<select class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref" name="selectemp" style="text-align:center;">';
echo '<option value="1">Ajouter un nouvel employé</option>';
$ligne=mysqli_fetch_array($res);
while($ligne!=false)
  {
    
echo "<option value ='".$ligne['matricule']."' > ".$ligne['nom']."  ".$ligne['prenom']."</option>";
      $ligne=mysqli_fetch_array($res);
    }
echo '</select>';
  }
echo '</div>';
echo '<div class="card-footer text-muted">';
echo '<input type="submit" class="btn btn-outline-dark" name="btngestionemp" value="VALIDER" />';
echo '</div>';
echo '</div>';
echo '</form>';

if (!isset($_POST['btngestionemp'])){
  $selectemp = 1;
}

if (!empty($_POST['btngestionemp'])){
  $selectemp = $_POST['selectemp'];
}
if($selectemp == 1){

echo '<form method="post" action="ajouter_emp.php"> <!-- debut du form ajouter -->';
echo '<div class="card text-center">';
echo '<div class="card-body">';
echo '';
echo '<div class="row">';
echo '<div class="col-sm-6">';
echo '<div class="card">';
echo '<div class="card-body">';
echo '<div class="input-group mb-3">';
echo '<div class="input-group-prepend">';
echo '<span class="input-group-text" id="basic-addon1" style="width:150px;">Nom</span>';
echo '</div>';
echo '<input type="text" style="text-align:center;" class="form-control" name="nom" value="" placeholder="nom" aria-label="" aria-describedby="basic-addon1">';
echo '</div>';
echo '<div class="input-group mb-3">';
echo '<div class="input-group-prepend">';
echo '<span class="input-group-text" id="basic-addon1" style="width:150px;">Prenom</span>';
echo '</div>';
echo '<input type="text" style="text-align:center;" class="form-control" name="prenom" value="" placeholder="prenom" aria-label="" aria-describedby="basic-addon1">';
echo '</div>';
echo '<div class="input-group mb-3">';
echo '<div class="input-group-prepend">';
echo '<span class="input-group-text" id="basic-addon1" style="width:150px;">Matricule</span>';
echo '</div>';
echo '<input type="text" style="text-align:center;" class="form-control" name="matricule" value="" placeholder="matricule" aria-label="" aria-describedby="basic-addon1">';
echo '</div>';
echo '<div class="input-group mb-3">';
echo '<div class="input-group-prepend">';
echo '<span class="input-group-text" id="basic-addon1" style="width:150px;">Service</span>';
echo '</div>';
echo '<select class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref" style="text-align:center;" name="service">';
echo '<option selected>Axians</option>';
echo '<option value="1">citeos</option>';
echo '<option value="2">actemium</option>';
echo '<option value="3">cegelec</option>';
echo '</select>';
echo '</div>';
echo '</div>';
echo '</div>';
echo '</div>';
echo '<div class="col-sm-6">';
echo '<div class="card">';
echo '<div class="card-body">';
echo '';
echo '<div class="input-group mb-3">';
echo '<div class="input-group-prepend">';
echo "<span class='input-group-text' id='basic-addon1' style='width:150px;'>Nom d'utilisateur</span>";
echo '</div>';
echo '<input type="text" class="form-control" style="text-align:center;" name="username" value="" placeholder="nom.prenom" aria-label="" aria-describedby="basic-addon1">';
echo '</div>';
echo '<div class="input-group mb-3">';
echo '<div class="input-group-prepend">';
echo '<span class="input-group-text" id="basic-addon1" style="width:150px;">Mot de passe</span>';
echo '</div>';
echo '<input type="text" class="form-control" style="text-align:center;" name="password" value="" placeholder="NomMatricule" aria-label="" aria-describedby="basic-addon1">';
echo '</div>';
echo '<div class="input-group mb-3">';
echo '<div class="input-group-prepend">';
echo '<span class="input-group-text" id="basic-addon1" style="width:150px;">Position</span>';
echo '</div>';
echo '<select class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref" style="text-align:center;" name="position">';
echo '<option value="ra">responsable affaire</option>';
echo '<option value="0" selected>employé</option>';
echo '<option value="ap">Adparc</option>';
echo "<option value='ce'>chef d'entreprise</option>";
echo '</select>';
echo '</div>';
echo '<div class="input-group mb-3">';
echo '<div class="input-group-prepend">';
echo "<span class='input-group-text' id='basic-addon1' style='width:170px;'>Responsable d'affaire</span>";
echo '</div>';
$req_ra="select * from employe where RA='1' order by nom;";
$res_ra=mysqli_query($cx,$req_ra);
if(!$res_ra)
	{echo "la requete n'a pas pu etre executee";}
	else{
echo '<select class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref" name="ajouterra" style="text-align:center;">';
echo '<option value="1">Attribuer un responsable d\'affaire</option>';
$ligne_ra=mysqli_fetch_array($res_ra);
while($ligne_ra!=false)
  {
    
echo "<option value ='".$ligne_ra['matricule']."' >".$ligne_ra['matricule']." - ".$ligne_ra['nom']."  ".$ligne_ra['prenom']."</option>";
      $ligne_ra=mysqli_fetch_array($res_rares);
    }
echo '</select>';
  }
echo '</div>';

echo '</div>';
echo '</div>';
echo '</div>';
echo '</div>';
echo '</div>';
echo '<div class="card-footer text-muted">';
echo '<input type="submit" class="btn btn-outline-dark" name="btn_ajouter" value="Ajouter" />';
echo '</div>';
echo '</div>';
echo '</form> <!-- fin du form ajouter -->';

} else {

  $requet = "SELECT * FROM employe WHERE matricule = '$_POST[selectemp]';";
  $requet_resultat = mysqli_query ($cx, $requet) or die('Erreur SQL !<br>'.$requet.'<br>'.mysql_error());
  $matricule_a_modifier = $_POST['selectemp'];
    // si on a au moins une news, on l'affiche
    while ($data_1 = mysqli_fetch_array($requet_resultat)) {
  echo "<form method='post' action='modif_emp.php?matricule=$matricule_a_modifier'>";
  echo '<div class="card text-center">';
  echo '<div class="card-body">';
  echo '<div class="row">';
  echo '<div class="col-sm-6">';
  echo '<div class="card">';
  echo '<div class="card-body">';
  echo '<div class="input-group mb-3">';
  echo '<div class="input-group-prepend">';
  echo '<span class="input-group-text" id="basic-addon1" style="width:150px;">Nom</span>';
  echo '</div>';
  echo '<input type="text" style="text-align:center;" class="form-control" name="nommodif" value="'.$data_1['nom'].'" placeholder=" '.$data_1['nom'].'  " aria-label="" aria-describedby="basic-addon1">';
  echo '</div>';
  echo '<div class="input-group mb-3">';
  echo '<div class="input-group-prepend">';
  echo '<span class="input-group-text" id="basic-addon1" style="width:150px;">Prenom</span>';
  echo '</div>';
  echo '<input type="text" style="text-align:center;" class="form-control" name="prenommodif" value="'.$data_1['prenom'].'" placeholder=" '.$data_1['prenom'].' " aria-label="" aria-describedby="basic-addon1">';
  echo '</div>';
  echo '<div class="input-group mb-3">';
  echo '<div class="input-group-prepend">';
  echo '<span class="input-group-text" id="basic-addon1" style="width:150px;">Matricule</span>';
  echo '</div>';
  echo '<input type="text" style="text-align:center;" class="form-control" name="matriculemodif" value="'.$data_1['matricule'].'" placeholder=" '.$data_1['matricule'].' " aria-label="" aria-describedby="basic-addon1">';
  echo '</div>';

  if($data_1['RA'] == 1){
    $position = "Responsable d'affaire";
    $positionvalue = 'ra';
}
if($data_1['ADMIN'] == 1){
   $position = "Chef d'entreprise";
   $positionvalue = 'ce';
}
if($data_1['ADPARC'] == 1){
   $position = "Administratif&Parc";
   $positionvalue = 'ap';
}
if($data_1['RA'] == 0 and $data_1['ADMIN'] == 0 and $data_1['ADPARC'] == 0){
   $position = "Employé";
   $positionvalue = '0';
}


  $req2="select DISTINCT service from employe;";
  $res2=mysqli_query($cx,$req2) or die('Erreur SQL !<br>'.$req2.'<br>'.mysql_error());;
  $ligne_service=mysqli_fetch_array($res2);

  if(isset($res2))
  {

  echo '<div class="input-group mb-3">';
  echo '<div class="input-group-prepend">';
  echo '<span class="input-group-text" id="basic-addon1" style="width:150px;">Service</span>';
  echo '</div>';
  echo '<select name="servicemodif" class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref" style="text-align:center;">';
  echo "<option value ='".$data_1['service']."'> ".$data_1['service']." </option>";
while($ligne_service!=false)
{

  echo "<option value ='".$ligne_service['service']."'> ".$ligne_service['service']."  </option>";
  $ligne_service=mysqli_fetch_array($res2);
}
echo "</select><br/>";
}
  echo '</div>';
  echo '</div>';
  echo '</div>';
  echo '</div>';
  
  echo '<div class="col-sm-6">';
  echo '<div class="card">';
  echo '<div class="card-body">';

  echo '<div class="input-group mb-3">';
  echo '<div class="input-group-prepend">';
  echo "<span class='input-group-text' id='basic-addon1' style='width:150px;'>Nom d'utilisateur</span>";
  echo '</div>';
  echo '<input type="text" class="form-control" style="text-align:center;" name="usernamemodif" value="'.$data_1['username'].'" placeholder=" '.$data_1['username'].' " aria-label="" aria-describedby="basic-addon1">';
  echo '</div>';
  echo '<div class="input-group mb-3">';
  echo '<div class="input-group-prepend">';
  echo '<span class="input-group-text" id="basic-addon1" style="width:150px;">Mot de passe</span>';
  echo '</div>';
  echo '<input type="text" class="form-control" style="text-align:center;" name="passwordmodif" value="'.$data_1['pass_md5'].'" placeholder="nouveau mot de passe" aria-label="" aria-describedby="basic-addon1">';
  echo '</div>';
  echo '<div class="input-group mb-3">';
  echo '<div class="input-group-prepend">';
  echo '<span class="input-group-text" id="basic-addon1" style="width:150px;">Position</span>';
  echo '</div>';
  echo '<select name="positionmodif" class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref" style="text-align:center;">';
  echo '<option value="'.$positionvalue.'">'.$position.'</option>';
  echo '<option value="0">Employé</option>';
  echo "<option value='ra'>Responsable d'affaire</option>";
  echo '<option value="ap">Administratif&Parc</option>';
  echo "<option value='ce'>Chef d'entreprise</option>";
  echo '</select>';
  echo '</div>';
  

  echo '<div class="input-group mb-3">';
  echo '<div class="input-group-prepend">';

  $reqra="select * from employe where RA = '1' and service='$data_1[service]';";
  $reqraemp=mysqli_query($cx,$reqra) or die('Erreur SQL !<br>'.$reqra.'<br>'.mysql_error());
  $lignera=mysqli_fetch_array($reqraemp);

  echo "<span class='input-group-text' id='basic-addon1' style='width:170px;'>Responsable d'affaire</span>";
  echo '</div>';

  if($reqraemp)
  {

  echo '<select name="ramodif" class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref" style="text-align:center;">';
  echo "<option value ='".$data_1['ra_employe']."'> ".$data_1['ra_employe']." </option>";
while($lignera!=false)
{
  echo "<option value ='".$lignera['matricule']."'> ".$lignera['nom']." ".$lignera['prenom']." </option>";
  $lignera=mysqli_fetch_array($reqraemp);
}
echo "</select><br/>";
}
  echo '</div>';

  echo '</div>';
  echo '</div>';
  echo '</div>';
  echo '</div>';
  echo '</div>';
}
  echo '<div class="card-footer text-muted">';
  echo '<input type="submit" class="btn btn-outline-dark" name="btn_modifier" value="Modifier" />';
  echo "<a href='supp_emp.php?matricule=$matricule_a_modifier'>";?>
  <input type="button" value="Supprimer" class="btn btn-danger" onclick="return(confirm('Voulez vous vraiment supprimer cet employé ?'))"/></a>
  <?php
  echo '</div>';
  echo '</div>';
  echo '</form>';
}
?>      
      <!-- Bootstrap core JavaScript
      ================================================== -->
      <!-- Placed at the end of the document so the pages load faster -->
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </body>
  </html>
  
  
  <!-- Projet réalisé par Maverick Lafont et Emrik Lecomte --> 