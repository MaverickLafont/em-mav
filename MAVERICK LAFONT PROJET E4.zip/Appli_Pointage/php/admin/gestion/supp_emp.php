<?php
include('../../connexion.php');

$matricule = $_GET['matricule'];
$req_supp = "DELETE FROM employe WHERE matricule='$matricule'";
$res_supp = mysqli_query($cx,$req_supp);
if($res_supp){
    header('location: gestion_emp.php?supprimer=oui');
} else {
    header('location: gestion_emp.php?supprimer=non');
}

?>