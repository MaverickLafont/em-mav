<?php
extract(filter_input_array(INPUT_POST));
$fichier=$_FILES["importaff"]["name"];
	if ($fichier){ //ouverture du fichier temporaire
 $fp = fopen ($_FILES["importaff"]["tmp_name"], "r");}
	else{  header('location:gestion_aff.php?erreur=1') // fichier inconnu   ?>

	<?php exit();}
	// declaration de la variable "cpt" qui permettra de conpter le nombre d'enregistrement realise
 $cpt=0; ?>
 <p align="center">- Importation Reussie -</p>
	<?php // importation
$dbdel = new mysqLi('localhost', 'root', '', 'cegelecbd') ;
$sqldel = ("DELETE FROM affaire;");
$result = $dbdel-> query($sqldel) ;

 while (!feof($fp)){
 $ligne = fgets($fp,4096);
	// on crée un tableau des éléments séparés par des points virgule
 $liste = explode(";",$ligne);
 $table = filter_input(INPUT_POST, 'importaff') ;
	// premier element
 $liste[0] = ( isset($liste[0]) ) ? $liste[0] : Null;
	$liste[1] = ( isset($liste[1]) ) ? $liste[1] : Null;
	$liste[2] = ( isset($liste[2]) ) ? $liste[2] : Null;
	$liste[3] = ( isset($liste[3]) ) ? $liste[3] : Null;

	$liste[4] = ( isset($liste[4]) ) ? $liste[4] : Null;
	$liste[5] = ( isset($liste[5]) ) ? $liste[5] : Null;
	$liste[6] = ( isset($liste[6]) ) ? $liste[6] : Null;

	$liste[7] = ( isset($liste[7]) ) ? $liste[7] : Null;
	$liste[8] = ( isset($liste[8]) ) ? $liste[8] : Null;
	$liste[9] = ( isset($liste[9]) ) ? $liste[9] : Null;

	$liste[10] = ( isset($liste[10]) ) ? $liste[10] : Null;

	
 $champs1=$liste[0];
 $champs2=$liste[1];

 $champs2_2=  str_replace("'","`",$champs2); 

 $champs3=$liste[2];
 $champs4=$liste[3];

 $champs4_2=  str_replace("'","`",$champs4); 

 $champs5=$liste[4];
 $champs6=$liste[5];
 $champs7=$liste[6];
 $champs8=$liste[7];

 $champs9=$liste[8];
 $champs10=$liste[9];
 $champs11=$liste[10];

	if ($champs1!='')
	{
 $cpt++;
	$db = new mysqLi('localhost', 'root', '', 'cegelecbd') ;
	$sql = ("INSERT INTO affaire(affaire_id, num_affaire, designation, num_client, nom, unite_analytique, matricule,
	grp_compta_affaire, date_creation, date_debut, date_fin, position) 
	VALUES('','$champs1','$champs2_2','$champs3','$champs4_2','$champs5','$champs6','$champs7','$champs8','$champs9',
	'$champs10','$champs11');") ;
 $result = $db-> query($sql) ;
 }  }
 header('location:gestion_aff.php?good=1&nombre='.$cpt);
	// fermeture du fichier
 fclose($fp);

 #http://www.supinfo.com/articles/single/1087-importer-fichier-csv-mysql-avec-php5
 #https://openclassrooms.com/courses/upload-de-fichiers-par-formulaire


	?>
	<h2>Nombre d'affaire enregistre dans la base de donnee: </h2><b><?php echo $cpt;?></b>
