<?php
$title = $_POST['title'];
$body = $_POST['body'];
$author = $_POST['author'];
$post = "INSERT INTO post (title, body, author) VALUES ($title,$body,$author)";
$sql = mysqli_query($conn,$post);
?>