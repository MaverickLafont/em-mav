<?php session_start('cegelec');?>
<!doctype html>
<html>
  <head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="../../css/employe/mainpage.css"> 	
    <link rel="stylesheet" media="handheld" type="text/css" title="mobile" href="../css/mobile.css" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../images/pointage.ico">
<?php include('../connexion.php'); ?>
<title>Pointage Borabora</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">
  </head>

  <body> 
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark" >
  <div class="navbar-collapse collapse" id="navbarColor01" style="">
    <ul class="navbar-nav mr-auto">
    <li class="nav-item active">
    <a class="nav-link" href="mainpage.php">Pointage</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="compte.php">Compte</a>
      </li>
    <li class="nav-item">
        <a class="nav-link" href="javascript:location.href='../logout.php'">deconnexion<span class="sr-only">(current)</span></a>
      </li>
    </ul>
  </div>
</nav>
 <?php 
          $Session_login = !empty($_SESSION['username'])?$_SESSION['username']:NULL;

        //on met la requête dans une variable ($sql)
          $sql = "SELECT * FROM employe WHERE username = '$Session_login' ";

          // on execute la requete :
          $resultat = mysqli_query ($cx, $sql) or die('Erreur SQL !<br>'.$sql.'<br>'.mysql_error());
          // retourne un tableau qui contient la première ligne de $resultat
          $data = mysqli_fetch_array($resultat);
          mysqli_free_result ($resultat);

        if($data['RA'] == 1) {
          header('Location: ../suphierarchique/mainpsa.php');
        }
        if($data['ADPARC'] == 1) {
          header('Location: ../administratif/mainadparc.php');
        }
        if($data['ADMIN'] == 1) {
          header('Location: ../admin/mainadmin.php');
        }

         if(!empty($_POST['bouton_date_debut'])) {
          $date_debut = $_POST['date_debut'];
          header('Location: mainpage.php?date='.$date_debut);

         } else {
          $date_debut= date("Y-m-d");
         }
         if(isset($_GET['date'])) {
          if(empty($_POST['bouton_date_debut'])) {
            $date_debut = $_GET['date'];
          }
         }

          setlocale(LC_TIME, 'fr_FR', 'french', 'fre', 'fra');

          $auj = $date_debut;
          $t_auj = strtotime($auj);
          $p_auj = date('N', $t_auj);
          if($p_auj == 1){
            $deb = $t_auj;
            $fin = strtotime($auj.' + 6 day');
          }
          else if($p_auj == 7){
            $deb = strtotime($auj.' - 6 day');
            $fin = $t_auj;
          }
          else{
            $deb = strtotime($auj.' - '.(6-(7-$p_auj)).' day');
            $fin = strtotime($auj.' + '.(7-$p_auj).' day');
          }
          $i = 1;
          while($deb <= $fin){
            $jour[$i] = strftime('%d %B %Y', $deb).'<br />';
            $finjoursemaine[$i] = strftime('%Y-%m-%d', $deb).'<br />';
            $deb += 86400;
            $i++;
          }

          $map = array_map(null, $finjoursemaine);
          $join = join(',', $map);
          list($finjoursemaine1, $finjoursemaine2, $finjoursemaine3, $finjoursemaine4, $finjoursemaine5, $finjoursemaine6, $finjoursemaine7) = explode(",", $join);
          $premierjour= $finjoursemaine1;$deuxiemejour=$finjoursemaine2;$troisiemejour=$finjoursemaine3;$quatriemejour=$finjoursemaine4;$cinquiemejour=$finjoursemaine5;$sixiemejour = $finjoursemaine6;$septiemejour = $finjoursemaine7;
          $clear = strip_tags($premierjour);
          $clear = html_entity_decode($clear);
          $clear = urldecode($clear);
          $clear = preg_replace('/[^A-Za-z0-9]/', ' ', $clear);
          $clear = preg_replace('/ +/', ' ', $clear);
          $clear = trim($clear);
          $test = preg_replace('/\s+/', '-', $clear);
          $date = new DateTime($test);
          $result = $date->format('Y-m-d');

          $clear1 = strip_tags($deuxiemejour);
          $clear1 = html_entity_decode($clear1);
          $clear1 = urldecode($clear1);
          $clear1 = preg_replace('/[^A-Za-z0-9]/', ' ', $clear1);
          $clear1 = preg_replace('/ +/', ' ', $clear1);
          $clear1 = trim($clear1);
          $test1 = preg_replace('/\s+/', '-', $clear1);
          $date1 = new DateTime($test1);
          $result1 = $date1->format('Y-m-d');

          $clear2 = strip_tags($troisiemejour);
          $clear2 = html_entity_decode($clear2);
          $clear2 = urldecode($clear2);
          $clear2 = preg_replace('/[^A-Za-z0-9]/', ' ', $clear2);
          $clear2 = preg_replace('/ +/', ' ', $clear2);
          $clear2 = trim($clear2);
          $test2 = preg_replace('/\s+/', '-', $clear2);
          $date2 = new DateTime($test2);
          $result2 = $date2->format('Y-m-d');

          $clear3 = strip_tags($quatriemejour);
          $clear3 = html_entity_decode($clear3);
          $clear3 = urldecode($clear3);
          $clear3 = preg_replace('/[^A-Za-z0-9]/', ' ', $clear3);
          $clear3 = preg_replace('/ +/', ' ', $clear3);
          $clear3 = trim($clear3);
          $test3 = preg_replace('/\s+/', '-', $clear3);
          $date3 = new DateTime($test3);
          $result3 = $date3->format('Y-m-d');

          $clear4 = strip_tags($cinquiemejour);
          $clear4 = html_entity_decode($clear4);
          $clear4 = urldecode($clear4);
          $clear4 = preg_replace('/[^A-Za-z0-9]/', ' ', $clear4);
          $clear4 = preg_replace('/ +/', ' ', $clear4);
          $clear4 = trim($clear4);
          $test4 = preg_replace('/\s+/', '-', $clear4);
          $date4 = new DateTime($test4);
          $result4 = $date4->format('Y-m-d');

          $clear5 = strip_tags($sixiemejour);
          $clear5 = html_entity_decode($clear5);
          $clear5 = urldecode($clear5);
          $clear5 = preg_replace('/[^A-Za-z0-9]/', ' ', $clear5);
          $clear5 = preg_replace('/ +/', ' ', $clear5);
          $clear5 = trim($clear5);
          $test5 = preg_replace('/\s+/', '-', $clear5);
          $date5 = new DateTime($test5);
          $result5 = $date5->format('Y-m-d');

          $clear6 = strip_tags($septiemejour);
          $clear6 = html_entity_decode($clear6);
          $clear6 = urldecode($clear6);
          $clear6 = preg_replace('/[^A-Za-z0-9]/', ' ', $clear6);
          $clear6 = preg_replace('/ +/', ' ', $clear6);
          $clear6 = trim($clear6);
          $test6 = preg_replace('/\s+/', '-', $clear6);
          $date6 = new DateTime($test6);
          $result6 = $date6->format('Y-m-d');

          $req_total_lundi = "SELECT * FROM pointage_affaire WHERE employe_matricule_affaire = '$data[matricule]' AND date_affaire='$result'";
          $res_total_lundi = mysqli_query($cx,$req_total_lundi) or die('Erreur SQL !<br>'.$req_total_lundi.'<br>'.mysql_error());
          if(empty($res_total_lundi)){$data_total_lundi = null;} else {$i = 0; while ($data_total_lundi = mysqli_fetch_array($res_total_lundi)){$tab_heure_lundi[$i] = $data_total_lundi; $i++;}}

          if(!empty($tab_heure_lundi)){$i=0; $totalHeureLundi=0; $countLundi = count($tab_heure_lundi) - 1; while($i <= $countLundi){$totalHeureLundi += $tab_heure_lundi[$i]["heure_affaire"] ; $i++;}} else {$totalHeureLundi = 0;}
          if(isset($tab_heure_lundi[0]['delegation'])){$tab_heure_lundi[0]['delegation'] = $tab_heure_lundi[0]['delegation'];} else{ $tab_heure_lundi[0]['delegation'] = null;}
          if(isset($tab_heure_lundi[0]['visite_medicale'])){$tab_heure_lundi[0]['visite_medicale'] = $tab_heure_lundi[0]['visite_medicale'];} else{ $tab_heure_lundi[0]['visite_medicale'] = null;}
          if(isset($tab_heure_lundi[0]['formation'])){$tab_heure_lundi[0]['formation'] = $tab_heure_lundi[0]['formation'];} else{ $tab_heure_lundi[0]['formation'] = null;}
          $totallundi = $totalHeureLundi + $tab_heure_lundi[0]['delegation'] + $tab_heure_lundi[0]['visite_medicale'] + $tab_heure_lundi[0]['formation'];
          if(!empty($tab_heure_lundi[0]['absencej'])){
            if($tab_heure_lundi[0]['absencej'] == "CP" Or $tab_heure_lundi[0]['absencej'] == "JF"){
              $totallundi = 7.8;
            }}

            $req_total_mardi = "SELECT * FROM pointage_affaire WHERE employe_matricule_affaire = '$data[matricule]' AND date_affaire='$result1' ";
          $res_total_mardi = mysqli_query($cx,$req_total_mardi) or die('Erreur SQL !<br>'.$req_total_mardi.'<br>'.mysql_error());
          if(empty($res_total_mardi)){$data_total_mardi = null;} else {$i = 0; while ($data_total_mardi = mysqli_fetch_array($res_total_mardi)){$tab_heure_mardi[$i] = $data_total_mardi; $i++;}}

          if(!empty($tab_heure_mardi)){$i=0; $totalHeuremardi=0; $countmardi = count($tab_heure_mardi) - 1; while($i <= $countmardi){ $totalHeuremardi += $tab_heure_mardi[$i]["heure_affaire"] ; $i++;}} else {$totalHeuremardi = 0;}
          if(isset($tab_heure_mardi[0]['delegation'])){$tab_heure_mardi[0]['delegation'] = $tab_heure_mardi[0]['delegation'];} else{ $tab_heure_mardi[0]['delegation'] = null;}
          if(isset($tab_heure_mardi[0]['visite_medicale'])){$tab_heure_mardi[0]['visite_medicale'] = $tab_heure_mardi[0]['visite_medicale'];} else{ $tab_heure_mardi[0]['visite_medicale'] = null;}
          if(isset($tab_heure_mardi[0]['formation'])){$tab_heure_mardi[0]['formation'] = $tab_heure_mardi[0]['formation'];} else{ $tab_heure_mardi[0]['formation'] = null;}
          $totalmardi = $totalHeuremardi + $tab_heure_mardi[0]['delegation']+$tab_heure_mardi[0]['visite_medicale']+$tab_heure_mardi[0]['formation'];
          if(!empty($tab_heure_mardi[0]['absencej'])){
            if($tab_heure_mardi[0]['absencej'] == "CP" Or $tab_heure_mardi[0]['absencej'] == "JF"){
              $totalmardi = 7.8;
            }}

            $req_total_mercredi = "SELECT * FROM pointage_affaire WHERE employe_matricule_affaire = '$data[matricule]' AND date_affaire='$result2' ";
          $res_total_mercredi = mysqli_query($cx,$req_total_mercredi) or die('Erreur SQL !<br>'.$req_total_mercredi.'<br>'.mysql_error());
          if(empty($res_total_mercredi)){$data_total_mercredi = null;} else {$i = 0; while ($data_total_mercredi = mysqli_fetch_array($res_total_mercredi)){$tab_heure_mercredi[$i] = $data_total_mercredi; $i++;}}

          if(!empty($tab_heure_mercredi)){$i=0; $totalHeuremercredi=0; $countmercredi = count($tab_heure_mercredi) - 1; while($i <= $countmercredi){ $totalHeuremercredi += $tab_heure_mercredi[$i]["heure_affaire"] ; $i++;}} else {$totalHeuremercredi = 0;}
                    if(isset($tab_heure_mercredi[0]['delegation'])){$tab_heure_mercredi[0]['delegation'] = $tab_heure_mercredi[0]['delegation'];} else{ $tab_heure_mercredi[0]['delegation'] = null;}
          if(isset($tab_heure_mercredi[0]['visite_medicale'])){$tab_heure_mercredi[0]['visite_medicale'] = $tab_heure_mercredi[0]['visite_medicale'];} else{ $tab_heure_mercredi[0]['visite_medicale'] = null;}
          if(isset($tab_heure_mercredi[0]['formation'])){$tab_heure_mercredi[0]['formation'] = $tab_heure_mercredi[0]['formation'];} else{ $tab_heure_mercredi[0]['formation'] = null;}
          $totalmercredi = $totalHeuremercredi + $tab_heure_mercredi[0]['delegation']+$tab_heure_mercredi[0]['visite_medicale']+$tab_heure_mercredi[0]['formation'];
          if(!empty($tab_heure_mercredi[0]['absencej'])){
            if($tab_heure_mercredi[0]['absencej'] == "CP" Or $tab_heure_mercredi[0]['absencej'] == "JF"){
              $totalmercredi = 7.8;
            }}

            $req_total_jeudi = "SELECT * FROM pointage_affaire WHERE employe_matricule_affaire = '$data[matricule]' AND date_affaire='$result3' ";
          $res_total_jeudi = mysqli_query($cx,$req_total_jeudi) or die('Erreur SQL !<br>'.$req_total_jeudi.'<br>'.mysql_error());
          if(empty($res_total_jeudi)){$data_total_jeudi = null;} else {$i = 0; while ($data_total_jeudi = mysqli_fetch_array($res_total_jeudi)){$tab_heure_jeudi[$i] = $data_total_jeudi; $i++;}}

          if(!empty($tab_heure_jeudi)){$i=0; $totalHeurejeudi=0; $countjeudi = count($tab_heure_jeudi) - 1; while($i <= $countjeudi){ $totalHeurejeudi += $tab_heure_jeudi[$i]["heure_affaire"] ; $i++;}} else {$totalHeurejeudi = 0;}
                    if(isset($tab_heure_jeudi[0]['delegation'])){$tab_heure_jeudi[0]['delegation'] = $tab_heure_jeudi[0]['delegation'];} else{ $tab_heure_jeudi[0]['delegation'] = null;}
          if(isset($tab_heure_jeudi[0]['visite_medicale'])){$tab_heure_jeudi[0]['visite_medicale'] = $tab_heure_jeudi[0]['visite_medicale'];} else{ $tab_heure_jeudi[0]['visite_medicale'] = null;}
          if(isset($tab_heure_jeudi[0]['formation'])){$tab_heure_jeudi[0]['formation'] = $tab_heure_jeudi[0]['formation'];} else{ $tab_heure_jeudi[0]['formation'] = null;}
          $totaljeudi = $totalHeurejeudi + $tab_heure_jeudi[0]['delegation']+$tab_heure_jeudi[0]['visite_medicale']+$tab_heure_jeudi[0]['formation'];
          if(!empty($tab_heure_jeudi[0]['absencej'])){
            if($tab_heure_jeudi[0]['absencej'] == "CP" Or $tab_heure_jeudi[0]['absencej'] == "JF"){
              $totaljeudi = 7.8;
            }}

            $req_total_vendredi = "SELECT * FROM pointage_affaire WHERE employe_matricule_affaire = '$data[matricule]' AND date_affaire='$result4' ";
          $res_total_vendredi = mysqli_query($cx,$req_total_vendredi) or die('Erreur SQL !<br>'.$req_total_vendredi.'<br>'.mysql_error());
          if(empty($res_total_vendredi)){$data_total_vendredi = null;} else {$i = 0; while ($data_total_vendredi = mysqli_fetch_array($res_total_vendredi)){$tab_heure_vendredi[$i] = $data_total_vendredi; $i++;}}

          if(!empty($tab_heure_vendredi)){$i=0; $totalHeurevendredi=0; $countvendredi = count($tab_heure_vendredi) - 1; while($i <= $countvendredi){ $totalHeurevendredi += $tab_heure_vendredi[$i]["heure_affaire"] ; $i++;}} else {$totalHeurevendredi = 0;}
                    if(isset($tab_heure_vendredi[0]['delegation'])){$tab_heure_vendredi[0]['delegation'] = $tab_heure_vendredi[0]['delegation'];} else{ $tab_heure_vendredi[0]['delegation'] = null;}
          if(isset($tab_heure_vendredi[0]['visite_medicale'])){$tab_heure_vendredi[0]['visite_medicale'] = $tab_heure_vendredi[0]['visite_medicale'];} else{ $tab_heure_vendredi[0]['visite_medicale'] = null;}
          if(isset($tab_heure_vendredi[0]['formation'])){$tab_heure_vendredi[0]['formation'] = $tab_heure_vendredi[0]['formation'];} else{ $tab_heure_vendredi[0]['formation'] = null;}
          $totalvendredi = $totalHeurevendredi + $data_total_vendredi['delegation']+$tab_heure_vendredi[0]['visite_medicale']+$tab_heure_vendredi[0]['formation'];
          if(!empty($tab_heure_vendredi[0]['absencej'])){
            if($tab_heure_vendredi[0]['absencej'] == "CP" Or $tab_heure_vendredi[0]['absencej'] == "JF"){
              $totalvendredi = 7.8;
            }}

            $req_total_samedi = "SELECT * FROM pointage_affaire WHERE employe_matricule_affaire = '$data[matricule]' AND date_affaire='$result5' ";
          $res_total_samedi = mysqli_query($cx,$req_total_samedi) or die('Erreur SQL !<br>'.$req_total_samedi.'<br>'.mysql_error());
          if(empty($res_total_samedi)){$data_total_samedi = null;} else {$i = 0; while ($data_total_samedi = mysqli_fetch_array($res_total_samedi)){$tab_heure_samedi[$i] = $data_total_samedi; $i++;}}

          if(!empty($tab_heure_samedi)){$i=0; $totalHeuresamedi=0; $countsamedi = count($tab_heure_samedi) - 1; while($i <= $countsamedi){ $totalHeuresamedi += $tab_heure_samedi[$i]["heure_affaire"] ; $i++;}} else {$totalHeuresamedi = 0;}
                    if(isset($tab_heure_samedi[0]['delegation'])){$tab_heure_samedi[0]['delegation'] = $tab_heure_samedi[0]['delegation'];} else{ $tab_heure_samedi[0]['delegation'] = null;}
          if(isset($tab_heure_samedi[0]['visite_medicale'])){$tab_heure_samedi[0]['visite_medicale'] = $tab_heure_samedi[0]['visite_medicale'];} else{ $tab_heure_samedi[0]['visite_medicale'] = null;}
          if(isset($tab_heure_samedi[0]['formation'])){$tab_heure_samedi[0]['formation'] = $tab_heure_samedi[0]['formation'];} else{ $tab_heure_samedi[0]['formation'] = null;}
          $totalsamedi = $totalHeuresamedi + $tab_heure_samedi[0]['delegation']+$tab_heure_samedi[0]['visite_medicale']+$tab_heure_samedi[0]['formation'];
          if(!empty($tab_heure_samedi[0]['absencej'])){
            if($data_total_samedi['absencej'] == "CP" Or $tab_heure_samedi[0]['absencej'] == "JF"){
              $totalsamedi = 7.8;
            }}

            $req_total_dimanche = "SELECT * FROM pointage_affaire WHERE employe_matricule_affaire = '$data[matricule]' AND date_affaire='$result6' ";
          $res_total_dimanche = mysqli_query($cx,$req_total_dimanche) or die('Erreur SQL !<br>'.$req_total_dimanche.'<br>'.mysql_error());
          if(empty($res_total_dimanche)){$data_total_dimanche = null;} else {$i = 0; while ($data_total_dimanche = mysqli_fetch_array($res_total_dimanche)){$tab_heure_dimanche[$i] = $data_total_dimanche; $i++;}}

          if(!empty($tab_heure_dimanche)){$i=0; $totalHeuredimanche=0; $countdimanche = count($tab_heure_dimanche) - 1; while($i <= $countdimanche){ $totalHeuredimanche += $tab_heure_dimanche[$i]["heure_affaire"] ; $i++;}} else {$totalHeuredimanche = 0;}
                    if(isset($tab_heure_dimanche[0]['delegation'])){$tab_heure_dimanche[0]['delegation'] = $tab_heure_dimanche[0]['delegation'];} else{ $tab_heure_dimanche[0]['delegation'] = null;}
          if(isset($tab_heure_dimanche[0]['visite_medicale'])){$tab_heure_dimanche[0]['visite_medicale'] = $tab_heure_dimanche[0]['visite_medicale'];} else{ $tab_heure_dimanche[0]['visite_medicale'] = null;}
          if(isset($tab_heure_dimanche[0]['formation'])){$tab_heure_dimanche[0]['formation'] = $tab_heure_dimanche[0]['formation'];} else{ $tab_heure_dimanche[0]['formation'] = null;}
          $totaldimanche = $totalHeuredimanche + $tab_heure_dimanche[0]['delegation']+$tab_heure_dimanche[0]['visite_medicale']+$tab_heure_dimanche[0]['formation'];
          if(!empty($tab_heure_dimanche[0]['absencej'])){
            if($tab_heure_dimanche[0]['absencej'] == "CP" Or $tab_heure_dimanche[0]['absencej'] == "JF"){
              $totaldimanche = 7.8;
            }}

          $totalsemaine = $totallundi + $totalmardi + $totalmercredi + $totaljeudi + $totalvendredi + $totalsamedi + $totaldimanche;
          ?>


 <div class="tableauid">
  <div class="table ">
    <FORM id="form_qte">
              <table class="table table-striped" id="qte">
                 <thead class="thead-dark" id="form_qte">
                 <?php if(count($data)>0){ 
                  echo'<tr id="Row1">';
                    echo'<th><h5>'.$data['prenom'].' '.$data['nom'].'</h5></th>';
                    echo'<th><h5>Matricule: '.$data["matricule"].'</h5> </th>';
                    echo'<th><h5>Service: '.$data["service"].'</h5></th>';}
                    $prenom = $data['prenom'];
                    $nom = $data['nom'];
                    $matricule = $data['matricule'];

                    ?>
                 
                  </tr>
                  
                </thead>
                <tbody>
             
                  </tbody>
              </table>
      </form>
            </div>
        </div>
        </div>


        <div class="card text-center">
  <div class="card-header">
   <h6> DATE:</h6>
  </div>
  <div class="card-body">
    <div class="date1">
  <div class="form-group row">
    <label for="example-date-input" class="col-0 col-form-label">Du</label>
    <div class="col-10">
      <form method="post" action="">
       <input class="form-control" type="date" name="date_debut" value="<?php echo $date_debut; ?>" id="example-date-input"/>
    </div>
  </div>
</div>

<div class="date2">
  <div class="form-group row">
    <label for="example-date-input" class="col-0 col-form-label">Au</label>
    <div class="col-10">
         <input class="form-control" type="date" name="date_fin" value="<?php echo $result6; ?>" id="example-date-input" readonly>
    </div>
  </div>
    </div>
  </div>
  <div class="selectsem">
  <div class="form-group"><select class="custom-select" disabled="disabled"  > 
      <option>S<?php echo date('W', strtotime($date_debut)); $semaine = date('W', strtotime($date_debut)); ?> </option>
      </select>
  </div>
      <!-- <input class="form-control" type="text" placeholder="S " readonly/> -->
  </div>
</div>
</div>

  <div class="card-footer text-muted">
<div class="boutonok">
<input type='submit' class="btn btn-outline-dark" name="bouton_date_debut" value="VALIDER DATE" />
<?php echo "<a href='visusemaine.php?semaine=$semaine&date=$result'><input type='button' class='btn btn-outline-dark' value='BILAN SEMAINE'/></a>"; ?>
</form>
</div>
  </div>
</div>

<?php
   if(isset($_GET['enregistrer'])) {
    switch ($_GET['enregistrer']) {
      case 1:
      echo "<div class='alert alert-success' role='alert' id='pointage_enregistre' style='text-align:center;'>";
      echo 'Pointage enregistré !';
      echo "</div>"; break;
      case 0:
      echo "<div class='alert alert-danger' role='alert' id='pointage_enregistre' style='text-align:center;'>";
      echo 'Pointage non enregistré, veuillez réessayer !';
      echo "</div>"; break;
    }
  }
  if(isset($_GET['modifier'])) {
    switch ($_GET['modifier']) {
      case 1:
      echo "<div class='alert alert-success' role='alert' id='pointage_enregistre' style='text-align:center;'>";
      echo 'Modification enregistré !';
      echo "</div>"; break;
      case 0:
      echo "<div class='alert alert-danger' role='alert' id='pointage_enregistre' style='text-align:center;'>";
      echo 'Modification non enregistré, veuillez réessayer !';
      echo "</div>"; break;
    }
  }
  if(isset($_GET['notification'])) {
    switch ($_GET['notification']) {
      case 1:
      echo "<div class='alert alert-success' role='alert' id='pointage_enregistre' style='text-align:center;'>";
      echo 'Notification envoyée !';
      echo "</div>"; break;
      case 0:
      echo "<div class='alert alert-danger' role='alert' id='pointage_enregistre' style='text-align:center;'>";
      echo 'Erreur lors de l\'envoie de la notification';
      echo "</div>"; break;
    }
  }
  if(isset($_GET['heure'])) {
    switch ($_GET['heure']) {
      case 0:
      echo "<div class='alert alert-danger' role='alert' id='pointage_enregistre' style='text-align:center;'>";
      echo 'Pointage non enregistré, 10 heures de travail maximum !';
      echo "</div>"; break;
    }
  }

  $rq_semaine="select * from pointage_affaire where employe_matricule_affaire='$matricule' AND S='$semaine' AND notif='1' AND validation_RA='1';";
  $rs_semaine=mysqli_query($cx,$rq_semaine) or die("Error: ".mysqli_error($cx));
  if ($rq_semaine){
      $data_semaine=mysqli_fetch_array($rs_semaine);
  }
  else {
      echo "Erreur de la requete";
  }
  if($data_semaine['validation_RA'] == 1){
    echo "<div class='alert alert-success' role='alert' id='pointage_valide' style='text-align:center;'>";
    echo 'Pointage validé !';
    echo "</div>";
  }
?>
<script type="text/javascript">
<!--
    var timeout = setTimeout(
        function() {
            document.getElementById('pointage_enregistre').style.display = "none";
            clearTimeout(timeout);
            }
        ,2500); // temps en millisecondes
//-->
</script>

<script type="text/javascript">
<!--
    var timeout = setTimeout(
        function() {
            document.getElementById('pointage_enregistre').style.display = "none";
            clearTimeout(timeout);
            }
        ,300000); // temps en millisecondes
//-->
</script>


<div class="tableau">
  <div class="table table-bordered">
    <FORM id="form_qte">
              <table class="table table-striped" id="qte">
                 <thead class="thead-dark" id="form_qte">
                
                  <tr id="Row1">
                    <th><h5>Jours</h5></th>
                    <th><h5>Total Quotidien</h5></th>
                    <th><h5>Affaires & Primes</h5></th>
                 
                  </tr>
                  
                </thead>
                <tbody>
                  <tr id="Row2">
                    <div id="div_qte">
                    <td>Lundi <?php echo ($jour[1]);?></td>
                   <td><?php echo $totallundi;?></td>
                   <td>
                   <?php
                   $requet_bouton_lundi="select * from pointage_affaire where date_affaire='$result' AND employe_matricule_affaire='$data[matricule]';";
                   $resultat_bouton_lundi=mysqli_query($cx,$requet_bouton_lundi) or die("Error: ".mysqli_error($cx));
                   if ($requet_bouton_lundi){
                       $data_bouton_lundi=mysqli_fetch_array($resultat_bouton_lundi);
                   }
                  if ($data_bouton_lundi['heure_affaire'] == 0 and (!empty($data_bouton_lundi['date_affaire']) and (!empty($data_bouton_lundi['absencej']) Or (!empty($data_bouton_lundi['delegation']) and (!empty($data_bouton_lundi['visite_medicale']) and (!empty($data_bouton_lundi['formation']))))))){
                    echo "<a href='../pointage/pointage_lundi/afficheaffairelundi.php?date=$result'>";
                    echo "<input type='button' class='btn btn-outline-dark' value='Afficher / Modifier' />";
                    echo "</a>";
                  }
                  if (!empty($data_bouton_lundi['heure_affaire'] and (!empty($data_bouton_lundi['date_affaire']) and (empty($data_bouton_lundi['absencej']) Or (empty($data_bouton_lundi['delegation']) and (empty($data_bouton_lundi['visite_medicale']) and (empty($data_bouton_lundi['formation'])))))))){
                    echo "<a href='../pointage/pointage_lundi/afficheaffairelundi.php?date=$result'>";
                    echo "<input type='button' class='btn btn-outline-dark' value='Afficher / Modifier' />";
                    echo "</a>";
                  }
                  if ($data_bouton_lundi['heure_affaire'] == 0 and (!empty($data_bouton_lundi['numero_affaire']) and (!empty($data_bouton_lundi['date_affaire'] and (empty($absencej) Or (empty($delegation) Or (empty($visite_medicale) and (empty($formation))))))))) {
                    $requet_supp_affaire_lundi = "DELETE FROM pointage_affaire WHERE date_affaire = '$data_bouton_lundi[date_affaire]' AND validation_RA='0';";
                    $resultat_supp_affaire_lundi = mysqli_query($cx,$requet_supp_affaire_lundi) or die("Error: ".mysqli_error($cx));
                    if ($requet_supp_affaire_lundi){
                      echo "<script type='text/javascript'>";
	                    echo "window.location.reload()";
                      echo "</script>";
                      echo "<a href='../pointage/pointage_lundi/formpointagelundi.php?date=$result'>";
                      echo "<input type='button' class='btn btn-outline-dark' value='Pointer' />";
                      echo "</a>";
                    }
                  }
                  if ($data_bouton_lundi['heure_affaire'] == 0 and (empty($data_bouton_lundi['date_affaire'] and (empty($absencej) Or (empty($delegation) and (empty($visite_medicale) and (empty($formation)))))))) {
                      echo "<a href='../pointage/pointage_lundi/formpointagelundi.php?date=$result'>";
                      echo "<input type='button' class='btn btn-outline-dark' value='Pointer' />";
                      echo "</a>";
                    }
                   ?>
                 </td>
                  </tr>
  
                  <tr>
                    <td>Mardi <?php echo ($jour[2]);?></td>
                   <td><?php echo $totalmardi;?></td>
                   <td>
                   <?php
                   $requet_bouton_mardi="select * from pointage_affaire where date_affaire='$result1' AND employe_matricule_affaire='$data[matricule]';";
                   $resultat_bouton_mardi=mysqli_query($cx,$requet_bouton_mardi) or die("Error: ".mysqli_error($cx));
                   if ($requet_bouton_mardi){
                       $data_bouton_mardi=mysqli_fetch_array($resultat_bouton_mardi);
                   }
                   if ($data_bouton_mardi['heure_affaire'] == 0 and (!empty($data_bouton_mardi['date_affaire']) and (!empty($data_bouton_mardi['absencej']) Or (!empty($data_bouton_mardi['delegation']) and (!empty($data_bouton_mardi['visite_medicale']) and (!empty($data_bouton_mardi['formation']))))))){
                    echo "<a href='../pointage/pointage_lundi/afficheaffairelundi.php?date=$result1'>";
                    echo "<input type='button' class='btn btn-outline-dark' value='Afficher / Modifier' />";
                    echo "</a>";
                  }
                  if (!empty($data_bouton_mardi['heure_affaire'] and (!empty($data_bouton_mardi['date_affaire']) and (empty($data_bouton_mardi['absencej']) Or (empty($data_bouton_mardi['delegation']) and (empty($data_bouton_mardi['visite_medicale']) and (empty($data_bouton_mardi['formation'])))))))){
                    echo "<a href='../pointage/pointage_lundi/afficheaffairelundi.php?date=$result1'>";
                    echo "<input type='button' class='btn btn-outline-dark' value='Afficher / Modifier' />";
                    echo "</a>";
                  }
                  if ($data_bouton_mardi['heure_affaire'] == 0 and (!empty($data_bouton_mardi['numero_affaire']) and (!empty($data_bouton_mardi['date_affaire'] and (empty($absencej) Or (empty($delegation) Or (empty($visite_medicale) and (empty($formation))))))))) {
                    $requet_supp_affaire_mardi = "DELETE FROM pointage_affaire WHERE date_affaire = '$data_bouton_mardi[date_affaire]' AND validation_RA='0';";
                    $result1at_supp_affaire_mardi = mysqli_query($cx,$requet_supp_affaire_mardi) or die("Error: ".mysqli_error($cx));
                    if ($requet_supp_affaire_mardi){
                      echo "<script type='text/javascript'>";
	                    echo "window.location.reload()";
                      echo "</script>";
                      echo "<a href='../pointage/pointage_lundi/formpointagelundi.php?date=$result1'>";
                      echo "<input type='button' class='btn btn-outline-dark' value='Pointer' />";
                      echo "</a>";
                    }
                  }
                  if ($data_bouton_mardi['heure_affaire'] == 0 and (empty($data_bouton_mardi['date_affaire'] and (empty($absencej) Or (empty($delegation) and (empty($visite_medicale) and (empty($formation)))))))) {
                      echo "<a href='../pointage/pointage_lundi/formpointagelundi.php?date=$result1'>";
                      echo "<input type='button' class='btn btn-outline-dark' value='Pointer' />";
                      echo "</a>";
                    }
                   ?>
                  </td>
                  </tr>
                  
                  <tr>
                    <td>Mercredi <?php echo ($jour[3]);?></td>
                    <td><?php echo $totalmercredi;?></td>
                    <td>
                    <?php
                   $requet_bouton_mercredi="select * from pointage_affaire where date_affaire='$result2' AND employe_matricule_affaire='$data[matricule]';";
                   $resultat_bouton_mercredi=mysqli_query($cx,$requet_bouton_mercredi) or die("Error: ".mysqli_error($cx));
                   if ($requet_bouton_mercredi){
                       $data_bouton_mercredi=mysqli_fetch_array($resultat_bouton_mercredi);
                   }
                   if ($data_bouton_mercredi['heure_affaire'] == 0 and (!empty($data_bouton_mercredi['date_affaire']) and (!empty($data_bouton_mercredi['absencej']) Or (!empty($data_bouton_mercredi['delegation']) and (!empty($data_bouton_mercredi['visite_medicale']) and (!empty($data_bouton_mercredi['formation']))))))){
                    echo "<a href='../pointage/pointage_lundi/afficheaffairelundi.php?date=$result2'>";
                    echo "<input type='button' class='btn btn-outline-dark' value='Afficher / Modifier' />";
                    echo "</a>";
                  }
                  if (!empty($data_bouton_mercredi['heure_affaire'] and (!empty($data_bouton_mercredi['date_affaire']) and (empty($data_bouton_mercredi['absencej']) Or (empty($data_bouton_mercredi['delegation']) and (empty($data_bouton_mercredi['visite_medicale']) and (empty($data_bouton_mercredi['formation'])))))))){
                    echo "<a href='../pointage/pointage_lundi/afficheaffairelundi.php?date=$result2'>";
                    echo "<input type='button' class='btn btn-outline-dark' value='Afficher / Modifier' />";
                    echo "</a>";
                  }
                  if ($data_bouton_mercredi['heure_affaire'] == 0 and (!empty($data_bouton_mercredi['numero_affaire']) and (!empty($data_bouton_mercredi['date_affaire'] and (empty($absencej) Or (empty($delegation) Or (empty($visite_medicale) and (empty($formation))))))))) {
                    $requet_supp_affaire_mercredi = "DELETE FROM pointage_affaire WHERE date_affaire = '$data_bouton_mercredi[date_affaire]' AND validation_RA='0';";
                    $resultat_supp_affaire_mercredi = mysqli_query($cx,$requet_supp_affaire_mercredi) or die("Error: ".mysqli_error($cx));
                    if ($requet_supp_affaire_mercredi){
                      echo "<script type='text/javascript'>";
	                    echo "window.location.reload()";
                      echo "</script>";
                      echo "<a href='../pointage/pointage_lundi/formpointagelundi.php?date=$result2'>";
                      echo "<input type='button' class='btn btn-outline-dark' value='Pointer' />";
                      echo "</a>";
                    }
                  }
                  if ($data_bouton_mercredi['heure_affaire'] == 0 and (empty($data_bouton_mercredi['date_affaire'] and (empty($absencej) Or (empty($delegation) and (empty($visite_medicale) and (empty($formation)))))))) {
                      echo "<a href='../pointage/pointage_lundi/formpointagelundi.php?date=$result2'>";
                      echo "<input type='button' class='btn btn-outline-dark' value='Pointer' />";
                      echo "</a>";
                    }
                   ?>
                    </td>
                  </tr>
                  
                  <tr>
                    <td>Jeudi <?php echo ($jour[4]);?></td>
                    <td><?php echo $totaljeudi;?></td>
                    <td>
                    <?php
                   $requet_bouton_jeudi="select * from pointage_affaire where date_affaire='$result3' AND employe_matricule_affaire='$data[matricule]';";
                   $resultat_bouton_jeudi=mysqli_query($cx,$requet_bouton_jeudi) or die("Error: ".mysqli_error($cx));
                   if ($requet_bouton_jeudi){
                       $data_bouton_jeudi=mysqli_fetch_array($resultat_bouton_jeudi);
                   }
                   if ($data_bouton_jeudi['heure_affaire'] == 0 and (!empty($data_bouton_jeudi['date_affaire']) and (!empty($data_bouton_jeudi['absencej']) Or (!empty($data_bouton_jeudi['delegation']) and (!empty($data_bouton_jeudi['visite_medicale']) and (!empty($data_bouton_jeudi['formation']))))))){
                    echo "<a href='../pointage/pointage_lundi/afficheaffairelundi.php?date=$result3'>";
                    echo "<input type='button' class='btn btn-outline-dark' value='Afficher / Modifier' />";
                    echo "</a>";
                  }
                  if (!empty($data_bouton_jeudi['heure_affaire'] and (!empty($data_bouton_jeudi['date_affaire']) and (empty($data_bouton_jeudi['absencej']) Or (empty($data_bouton_jeudi['delegation']) and (empty($data_bouton_jeudi['visite_medicale']) and (empty($data_bouton_jeudi['formation'])))))))){
                    echo "<a href='../pointage/pointage_lundi/afficheaffairelundi.php?date=$result3'>";
                    echo "<input type='button' class='btn btn-outline-dark' value='Afficher / Modifier' />";
                    echo "</a>";
                  }
                  if ($data_bouton_jeudi['heure_affaire'] == 0 and (!empty($data_bouton_jeudi['numero_affaire']) and (!empty($data_bouton_jeudi['date_affaire'] and (empty($absencej) Or (empty($delegation) Or (empty($visite_medicale) and (empty($formation))))))))) {
                    $requet_supp_affaire_jeudi = "DELETE FROM pointage_affaire WHERE date_affaire = '$data_bouton_jeudi[date_affaire]' AND validation_RA='0';";
                    $resultat_supp_affaire_jeudi = mysqli_query($cx,$requet_supp_affaire_jeudi) or die("Error: ".mysqli_error($cx));
                    if ($requet_supp_affaire_jeudi){
                      echo "<script type='text/javascript'>";
	                    echo "window.location.reload()";
                      echo "</script>";
                      echo "<a href='../pointage/pointage_lundi/formpointagelundi.php?date=$result3'>";
                      echo "<input type='button' class='btn btn-outline-dark' value='Pointer' />";
                      echo "</a>";
                    }
                  }
                  if ($data_bouton_jeudi['heure_affaire'] == 0 and (empty($data_bouton_jeudi['date_affaire'] and (empty($absencej) Or (empty($delegation) and (empty($visite_medicale) and (empty($formation)))))))) {
                      echo "<a href='../pointage/pointage_lundi/formpointagelundi.php?date=$result3'>";
                      echo "<input type='button' class='btn btn-outline-dark' value='Pointer' />";
                      echo "</a>";
                    }
                   ?>
                    </td>
                  </tr>

                  <tr>
                    <td>Vendredi <?php echo ($jour[5]);?></td>
                  <td><?php echo $totalvendredi;?></td>
                  <td>                    
                  <?php
                   $requet_bouton_vendredi="select * from pointage_affaire where date_affaire='$result4' AND employe_matricule_affaire='$data[matricule]';";
                   $resultat_bouton_vendredi=mysqli_query($cx,$requet_bouton_vendredi) or die("Error: ".mysqli_error($cx));
                   if ($requet_bouton_vendredi){
                       $data_bouton_vendredi=mysqli_fetch_array($resultat_bouton_vendredi);
                   }
                   if ($data_bouton_vendredi['heure_affaire'] == 0 and (!empty($data_bouton_vendredi['date_affaire']) and (!empty($data_bouton_vendredi['absencej']) Or (!empty($data_bouton_vendredi['delegation']) and (!empty($data_bouton_vendredi['visite_medicale']) and (!empty($data_bouton_vendredi['formation']))))))){
                    echo "<a href='../pointage/pointage_lundi/afficheaffairelundi.php?date=$result4'>";
                    echo "<input type='button' class='btn btn-outline-dark' value='Afficher / Modifier' />";
                    echo "</a>";
                  }
                  if (!empty($data_bouton_vendredi['heure_affaire'] and (!empty($data_bouton_vendredi['date_affaire']) and (empty($data_bouton_vendredi['absencej']) Or (empty($data_bouton_vendredi['delegation']) and (empty($data_bouton_vendredi['visite_medicale']) and (empty($data_bouton_vendredi['formation'])))))))){
                    echo "<a href='../pointage/pointage_lundi/afficheaffairelundi.php?date=$result4'>";
                    echo "<input type='button' class='btn btn-outline-dark' value='Afficher / Modifier' />";
                    echo "</a>";
                  }
                  if ($data_bouton_vendredi['heure_affaire'] == 0 and (!empty($data_bouton_vendredi['numero_affaire']) and (!empty($data_bouton_vendredi['date_affaire'] and (empty($absencej) Or (empty($delegation) Or (empty($visite_medicale) and (empty($formation))))))))) {
                    $requet_supp_affaire_vendredi = "DELETE FROM pointage_affaire WHERE date_affaire = '$data_bouton_vendredi[date_affaire]' AND validation_RA='0';";
                    $resultat_supp_affaire_vendredi = mysqli_query($cx,$requet_supp_affaire_vendredi) or die("Error: ".mysqli_error($cx));
                    if ($requet_supp_affaire_vendredi){
                      echo "<script type='text/javascript'>";
	                    echo "window.location.reload()";
                      echo "</script>";
                      echo "<a href='../pointage/pointage_lundi/formpointagelundi.php?date=$result4'>";
                      echo "<input type='button' class='btn btn-outline-dark' value='Pointer' />";
                      echo "</a>";
                    }
                  }
                  if ($data_bouton_vendredi['heure_affaire'] == 0 and (empty($data_bouton_vendredi['date_affaire'] and (empty($absencej) Or (empty($delegation) and (empty($visite_medicale) and (empty($formation)))))))) {
                      echo "<a href='../pointage/pointage_lundi/formpointagelundi.php?date=$result4'>";
                      echo "<input type='button' class='btn btn-outline-dark' value='Pointer' />";
                      echo "</a>";
                    }
                   ?>
                  </td>
                  </tr>
                  <tr>
                    <td>Samedi <?php echo ($jour[6]);?></td>
                    <td><?php echo $totalsamedi;?></td>     
                    <td>
                    <?php
                   $requet_bouton_samedi="select * from pointage_affaire where date_affaire='$result5' AND employe_matricule_affaire='$data[matricule]';";
                   $resultat_bouton_samedi=mysqli_query($cx,$requet_bouton_samedi) or die("Error: ".mysqli_error($cx));
                   if ($requet_bouton_samedi){
                       $data_bouton_samedi=mysqli_fetch_array($resultat_bouton_samedi);
                   }
                   if ($data_bouton_samedi['heure_affaire'] == 0 and (!empty($data_bouton_samedi['date_affaire']) and (!empty($data_bouton_samedi['absencej']) Or (!empty($data_bouton_samedi['delegation']) and (!empty($data_bouton_samedi['visite_medicale']) and (!empty($data_bouton_samedi['formation']))))))){
                    echo "<a href='../pointage/pointage_lundi/afficheaffairelundi.php?date=$result5'>";
                    echo "<input type='button' class='btn btn-outline-dark' value='Afficher / Modifier' />";
                    echo "</a>";
                  }
                  if (!empty($data_bouton_samedi['heure_affaire'] and (!empty($data_bouton_samedi['date_affaire']) and (empty($data_bouton_samedi['absencej']) Or (empty($data_bouton_samedi['delegation']) and (empty($data_bouton_samedi['visite_medicale']) and (empty($data_bouton_samedi['formation'])))))))){
                    echo "<a href='../pointage/pointage_lundi/afficheaffairelundi.php?date=$result5'>";
                    echo "<input type='button' class='btn btn-outline-dark' value='Afficher / Modifier' />";
                    echo "</a>";
                  }
                  if ($data_bouton_samedi['heure_affaire'] == 0 and (!empty($data_bouton_samedi['numero_affaire']) and (!empty($data_bouton_samedi['date_affaire'] and (empty($absencej) Or (empty($delegation) Or (empty($visite_medicale) and (empty($formation))))))))) {
                    $requet_supp_affaire_samedi = "DELETE FROM pointage_affaire WHERE date_affaire = '$data_bouton_samedi[date_affaire]' AND validation_RA='0';";
                    $resultat_supp_affaire_samedi = mysqli_query($cx,$requet_supp_affaire_samedi) or die("Error: ".mysqli_error($cx));
                    if ($requet_supp_affaire_samedi){
                      echo "<script type='text/javascript'>";
	                    echo "window.location.reload()";
                      echo "</script>";
                      echo "<a href='../pointage/pointage_lundi/formpointagelundi.php?date=$result5'>";
                      echo "<input type='button' class='btn btn-outline-dark' value='Pointer' />";
                      echo "</a>";
                    }
                  }
                  if ($data_bouton_samedi['heure_affaire'] == 0 and (empty($data_bouton_samedi['date_affaire'] and (empty($absencej) Or (empty($delegation) and (empty($visite_medicale) and (empty($formation)))))))) {
                      echo "<a href='../pointage/pointage_lundi/formpointagelundi.php?date=$result5'>";
                      echo "<input type='button' class='btn btn-outline-dark' value='Pointer' />";
                      echo "</a>";
                    }
                   ?>
                    </td>
                  </tr>
                  <tr>
                    <td>Dimanche <?php echo ($jour[7]);?></td>
                    <td><?php echo $totaldimanche;?></td>                
                    <td>
                    <?php
                   $requet_bouton_dimanche="select * from pointage_affaire where date_affaire='$result6' AND employe_matricule_affaire='$data[matricule]';";
                   $resultat_bouton_dimanche=mysqli_query($cx,$requet_bouton_dimanche) or die("Error: ".mysqli_error($cx));
                   if ($requet_bouton_dimanche){
                       $data_bouton_dimanche=mysqli_fetch_array($resultat_bouton_dimanche);
                   }
                   if ($data_bouton_dimanche['heure_affaire'] == 0 and (!empty($data_bouton_dimanche['date_affaire']) and (!empty($data_bouton_dimanche['absencej']) Or (!empty($data_bouton_dimanche['delegation']) and (!empty($data_bouton_dimanche['visite_medicale']) and (!empty($data_bouton_dimanche['formation']))))))){
                    echo "<a href='../pointage/pointage_lundi/afficheaffairelundi.php?date=$result6'>";
                    echo "<input type='button' class='btn btn-outline-dark' value='Afficher / Modifier' />";
                    echo "</a>";
                  }
                  if (!empty($data_bouton_dimanche['heure_affaire'] and (!empty($data_bouton_dimanche['date_affaire']) and (empty($data_bouton_dimanche['absencej']) Or (empty($data_bouton_dimanche['delegation']) and (empty($data_bouton_dimanche['visite_medicale']) and (empty($data_bouton_dimanche['formation'])))))))){
                    echo "<a href='../pointage/pointage_lundi/afficheaffairelundi.php?date=$result6'>";
                    echo "<input type='button' class='btn btn-outline-dark' value='Afficher / Modifier' />";
                    echo "</a>";
                  }
                  if ($data_bouton_dimanche['heure_affaire'] == 0 and (!empty($data_bouton_dimanche['numero_affaire']) and (!empty($data_bouton_dimanche['date_affaire'] and (empty($absencej) Or (empty($delegation) Or (empty($visite_medicale) and (empty($formation))))))))) {
                    $requet_supp_affaire_dimanche = "DELETE FROM pointage_affaire WHERE date_affaire = '$data_bouton_dimanche[date_affaire]' AND validation_RA='0';";
                    $resultat_supp_affaire_dimanche = mysqli_query($cx,$requet_supp_affaire_dimanche) or die("Error: ".mysqli_error($cx));
                    if ($requet_supp_affaire_dimanche){
                      echo "<script type='text/javascript'>";
	                    echo "window.location.reload()";
                      echo "</script>";
                      echo "<a href='../pointage/pointage_lundi/formpointagelundi.php?date=$result6'>";
                      echo "<input type='button' class='btn btn-outline-dark' value='Pointer' />";
                      echo "</a>";
                    }
                  }
                  if ($data_bouton_dimanche['heure_affaire'] == 0 and (empty($data_bouton_dimanche['date_affaire'] and (empty($absencej) Or (empty($delegation) and (empty($visite_medicale) and (empty($formation)))))))) {
                      echo "<a href='../pointage/pointage_lundi/formpointagelundi.php?date=$result6'>";
                      echo "<input type='button' class='btn btn-outline-dark' value='Pointer' />";
                      echo "</a>";
                    }
                   ?>
                    </td>
                  </tr>
                  <tr><td><h5>Total</h5></td><td><?php echo $totalsemaine;?></td></tr>

                </tbody>
              </table>
      </form>
            </div>
        </div>
        </div>
<script> 

</script>
      <!-- Bootstrap core JavaScript
      ================================================== -->
      <!-- Placed at the end of the document so the pages load faster -->
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </body>
  </html>
  
  
<!--###################################################################--> 
<!--#                  Projet: Application de pointage                #-->  
<!--#                  Entreprise: Cegelec                            #-->  
<!--#                  Auteurs: Maverick Lafont & Emrik Lecomte       #--> 
<!--#                  Position: Job d'été MIJ                        #--> 
<!--#                  Scolaire: BTS SIO 2ième Année                  #--> 
<!--###################################################################--> 