<!DOCTYPE html>
<html>
  <meta charset="UTF-8">
  <head>
    <title></title>
    <link rel="stylesheet" href="style.css" />
    <script src="jquery-1.4.2.min.js"></script>
    <script>
    $(document).ready(function(){
        $('.loader').hide();
         
         
        $('#search').keyup(function(){
          $field = $(this);
          $('#result').html('');
           
          if($field.val().length>3)
          {
            $.ajax({
              type: 'POST',
              url: 'search.php',
              data: 'search='+$('#search').val(),
               
              beforeSend:function(){
                $('.loader').stop().fadeIn();
              },
               
              success: function(data){
                $('.loader').fadeOut();
                $('#result').html(data);
              }
            });
          }
        });
      });
    </script>
  </head>
  <body>
    <div id="content">
       
      <form action="search.php" method="post">
         
        <label for="search">Rechercher:</label>
        <input type="text" name="search" id="search" />
         
        <div class="loader"></div>
         
      </form>
       
      <div id="result"></div>
       
    </div>
  </body>
</html>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>