<?php session_start('cegelec');?>
<!doctype html>
<html>
  <head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="../../css/employe/mainpage.css"> 	
    <link rel="stylesheet" media="handheld" type="text/css" title="mobile" href="../css/mobile.css" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../images/pointage.ico">
<?php include('../connexion.php'); ?>
<title>Pointage Borabora</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">
  </head>

  <body> 
     
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark" >
  <div class="navbar-collapse collapse" id="navbarColor01" style="">
    <ul class="navbar-nav mr-auto">
    <li class="nav-item">
    <a class="nav-link" href="mainpage.php">Pointage</a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="compte.php">Compte</a>
      </li>
    <li class="nav-item">
        <a class="nav-link" href="javascript:location.href='../logout.php'">deconnexion<span class="sr-only">(current)</span></a>
      </li>
    </ul>
  </div>
</nav>


  
 <?php 
          $Session_login = !empty($_SESSION['username'])?$_SESSION['username']:NULL;

        //on met la requête dans une variable ($sql)
          $sql = "SELECT * FROM employe WHERE username = '$Session_login' ";

          // on execute la requete :
          $resultat = mysqli_query ($cx, $sql) or die('Erreur SQL !<br>'.$sql.'<br>'.mysql_error());
          // retourne un tableau qui contient la première ligne de $resultat
          $data = mysqli_fetch_array($resultat);
          mysqli_free_result ($resultat);

          if(isset($_GET['mdp'])) {
            switch ($_GET['mdp']) {
              case 1:
              echo "<div class='alert alert-success' role='alert' id='pointage_enregistre' style='text-align:center;'>";
              echo 'Mot de passe changé !';
              echo "</div>"; break;
              case 2:
              echo "<div class='alert alert-danger' role='alert' id='pointage_enregistre' style='text-align:center;'>";
              echo 'Nouveau mot de passe et ancien mot de passe différent, veuillez réessayer !';
              echo "</div>"; break;
              case 0:
              echo "<div class='alert alert-danger' role='alert' id='pointage_enregistre' style='text-align:center;'>";
              echo 'Ancien mot de passe incorrect';
              echo "</div>"; break;
            }
          }
?>



<div class="card text-center" style="margin-top:20px;">
  <div class="card-header">
   Compte
  </div>
  <div class="card-body">
  
  


<div class="row" style="margin-top:20px;">
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
      
      <div class="input-group mb-3">
  <div class="input-group-prepend">

 <?php
 if($data['RA'] == 1){
     $position = "responsable affaire";
 }
 if($data['ADMIN'] == 1){
    $position = "Chef d'entreprise";
}
if($data['ADPARC'] == 1){
    $position = "Administratif & Parc";
}
if($data['RA'] == 0 and $data['ADMIN'] == 0 and $data['ADPARC'] == 0){
    $position = "Employé";
}

 if(count($data)>0){ 

    echo '<span class="input-group-text" id="basic-addon1" style="width:120px;">NOM</span>';
    echo '</div>';
    echo '<input type="text" class="form-control" style="text-align:center;" placeholder="'.$data['nom'].'" aria-label="" aria-describedby="basic-addon1" readonly>';
    echo '</div>';
    echo '<div class="input-group mb-3">';
    echo ' <div class="input-group-prepend">';
    echo '<span class="input-group-text" id="basic-addon1" style="width:120px;">PRENOM</span>';
    echo '</div>';
    echo '<input type="text" class="form-control" style="text-align:center;" placeholder="'.$data['prenom'].'" aria-label="" aria-describedby="basic-addon1" readonly>';
    echo '</div>';
    echo '<div class="input-group mb-3">';
    echo '<div class="input-group-prepend">';
    echo "<span class='input-group-text' id='basic-addon1' style='width:170px;'>NOM D'UTILISATEUR</span>";
    echo '</div>';
    echo '<input type="text" class="form-control" style="text-align:center;" placeholder="'.$data['username'].'" aria-label="" aria-describedby="basic-addon1" readonly>';
    echo '</div>';

    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '<div class="col-sm-6">';
    echo '<div class="card">';
    echo '<div class="card-body">';
       
    echo '<div class="input-group mb-3">';
    echo '<div class="input-group-prepend">';
    echo '<span class="input-group-text" id="basic-addon1" style="width:120px;">SERVICE</span>';
    echo '</div>';
    echo '<input type="text" class="form-control" style="text-align:center;" placeholder="'.$data['service'].'" aria-label="" aria-describedby="basic-addon1" readonly>';
    echo '</div>';
    echo '<div class="input-group mb-3">';
    echo '<div class="input-group-prepend">';
    echo '<span class="input-group-text" id="basic-addon1" style="width:120px;">POSITION</span>';
    echo '</div>';
    echo '<input type="text" class="form-control" style="text-align:center;" placeholder="'.$position.'" aria-label="" aria-describedby="basic-addon1" readonly>';
    echo '</div>';
    echo '<div class="input-group mb-3">';
    echo ' <div class="input-group-prepend">';
    echo '<span class="input-group-text" id="basic-addon1" style="width:120px;">MATRICULE</span>';
    echo '</div>';
    echo '<input type="text" class="form-control" style="text-align:center;" placeholder="'.$data['matricule'].'" aria-label="" aria-describedby="basic-addon1" readonly>';}
    echo '</div>';

    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';




    echo '</div>';
 
    echo '</div>';
?>

<script type="text/javascript">
<!--
    var timeout = setTimeout(
        function() {
            document.getElementById('pointage_enregistre').style.display = "none";
            clearTimeout(timeout);
            }
        ,2500); // temps en millisecondes
//-->
</script>

<form method='post' action='changermdp.php'>
<div class="card text-center" style="margin-top:20px;">
  <div class="card-header">
    Changer Mot De Passe
  </div>
  <div class="card-body">
   
   
  <div class="row" style="margin-top:20px;">
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
       
      <div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" id="basic-addon1">Ancien Mot de passe</span>
  </div>
  <input type="text" class="form-control" name="ancienmdp" placeholder="" aria-label="" aria-describedby="basic-addon1">
</div>

      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
      <div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" id="basic-addon1" style="width:264px;">Nouveau Mot de passe</span>
  </div>
  <input type="text" class="form-control" name="nouveaumdp" placeholder="" aria-label="" aria-describedby="basic-addon1">
</div>
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" id="basic-addon1">Confirmer Nouveau Mot de passe</span>
  </div>
  <input type="text" class="form-control" name="confirmermdp" placeholder="" aria-label="" aria-describedby="basic-addon1">
</div>
      </div>
    </div>
  </div>
</div>

  </div>
  <div class="card-footer text-muted">
  <input type='submit' class="btn btn-outline-dark" style="margin-left:0%;" name="bouton_date_debut" value="VALIDER" />
  </div>
</div>

</form>

        
      <!-- Bootstrap core JavaScript
      ================================================== -->
      <!-- Placed at the end of the document so the pages load faster -->
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </body>
  </html>
  
  
<!--###################################################################--> 
<!--#                  Projet: Application de pointage                #-->  
<!--#                  Entreprise: Cegelec                            #-->  
<!--#                  Auteurs: Maverick Lafont & Emrik Lecomte       #--> 
<!--#                  Position: Job d'été MIJ                        #--> 
<!--#                  Scolaire: BTS SIO 2ième Année                  #--> 
<!--###################################################################--> 