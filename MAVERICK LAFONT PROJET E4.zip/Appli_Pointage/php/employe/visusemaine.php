<?php session_start('cegelec');?>
<!doctype html>
<html>
  <head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="../../css/employe/mainpage.css"> 	
    <link rel="stylesheet" media="handheld" type="text/css" title="mobile" href="../css/mobile.css" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">
<?php include('../connexion.php'); ?>
<title>Pointage Cegelec</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">
  </head>

  <body>
  <?php 
          $Session_login = !empty($_SESSION['username'])?$_SESSION['username']:NULL;

          //on met la requête dans une variable ($sql)
            $sql = "SELECT * FROM employe WHERE username = '$Session_login' ";
  
            // on execute la requete :
            $resultat = mysqli_query ($cx, $sql) or die('Erreur SQL !<br>'.$sql.'<br>'.mysql_error());
            // retourne un tableau qui contient la première ligne de $resultat
            $data = mysqli_fetch_array($resultat);
            mysqli_free_result ($resultat);
            $date_debut = $_GET['date'];
            $semaine = $_GET['semaine'];
            $matricule = $data['matricule'];

?>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark" >
    <a class="navbar-brand" href="mainpage.php">Retour</a>
    <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="navbar-collapse collapse" id="navbarColor01" style="">
      <ul class="navbar-nav mr-auto">
        <?php echo "<a href='notification.php?semaine=$semaine&date=$date_debut&matricule=$matricule'>" ?>
<input type="button" value="Notifier le responsable" class="btn btn-success" onclick="return(confirm('Voulez vous vraiment envoyer une notification au responsable ?'))"/></a>
      </ul>
    </div>
  </nav>
    
  <?php 
        
          setlocale(LC_TIME, 'fr_FR', 'french', 'fre', 'fra');

          $auj = $date_debut;
          $t_auj = strtotime($auj);
          $p_auj = date('N', $t_auj);
          if($p_auj == 1){
            $deb = $t_auj;
            $fin = strtotime($auj.' + 6 day');
          }
          else if($p_auj == 7){
            $deb = strtotime($auj.' - 6 day');
            $fin = $t_auj;
          }
          else{
            $deb = strtotime($auj.' - '.(6-(7-$p_auj)).' day');
            $fin = strtotime($auj.' + '.(7-$p_auj).' day');
          }
          $i = 1;
          while($deb <= $fin){
            $jour[$i] = strftime('%d %B %Y', $deb).'<br />';
            $finjoursemaine[$i] = strftime('%Y-%m-%d', $deb).'<br />';
            $deb += 86400;
            $i++;
          }

          $map = array_map(null, $finjoursemaine);
          $join = join(',', $map);
          list($finjoursemaine1, $finjoursemaine2, $finjoursemaine3, $finjoursemaine4, $finjoursemaine5, $finjoursemaine6, $finjoursemaine7) = explode(",", $join);
          $premierjour= $finjoursemaine1;$deuxiemejour=$finjoursemaine2;$troisiemejour=$finjoursemaine3;$quatriemejour=$finjoursemaine4;$cinquiemejour=$finjoursemaine5;$sixiemejour = $finjoursemaine6;$septiemejour = $finjoursemaine7;
          $clear = strip_tags($premierjour);
          $clear = html_entity_decode($clear);
          $clear = urldecode($clear);
          $clear = preg_replace('/[^A-Za-z0-9]/', ' ', $clear);
          $clear = preg_replace('/ +/', ' ', $clear);
          $clear = trim($clear);
          $test = preg_replace('/\s+/', '-', $clear);
          $date = new DateTime($test);
          $result = $date->format('Y-m-d');

          $clear1 = strip_tags($deuxiemejour);
          $clear1 = html_entity_decode($clear1);
          $clear1 = urldecode($clear1);
          $clear1 = preg_replace('/[^A-Za-z0-9]/', ' ', $clear1);
          $clear1 = preg_replace('/ +/', ' ', $clear1);
          $clear1 = trim($clear1);
          $test1 = preg_replace('/\s+/', '-', $clear1);
          $date1 = new DateTime($test1);
          $result1 = $date1->format('Y-m-d');

          $clear2 = strip_tags($troisiemejour);
          $clear2 = html_entity_decode($clear2);
          $clear2 = urldecode($clear2);
          $clear2 = preg_replace('/[^A-Za-z0-9]/', ' ', $clear2);
          $clear2 = preg_replace('/ +/', ' ', $clear2);
          $clear2 = trim($clear2);
          $test2 = preg_replace('/\s+/', '-', $clear2);
          $date2 = new DateTime($test2);
          $result2 = $date2->format('Y-m-d');

          $clear3 = strip_tags($quatriemejour);
          $clear3 = html_entity_decode($clear3);
          $clear3 = urldecode($clear3);
          $clear3 = preg_replace('/[^A-Za-z0-9]/', ' ', $clear3);
          $clear3 = preg_replace('/ +/', ' ', $clear3);
          $clear3 = trim($clear3);
          $test3 = preg_replace('/\s+/', '-', $clear3);
          $date3 = new DateTime($test3);
          $result3 = $date3->format('Y-m-d');

          $clear4 = strip_tags($cinquiemejour);
          $clear4 = html_entity_decode($clear4);
          $clear4 = urldecode($clear4);
          $clear4 = preg_replace('/[^A-Za-z0-9]/', ' ', $clear4);
          $clear4 = preg_replace('/ +/', ' ', $clear4);
          $clear4 = trim($clear4);
          $test4 = preg_replace('/\s+/', '-', $clear4);
          $date4 = new DateTime($test4);
          $result4 = $date4->format('Y-m-d');

          $clear5 = strip_tags($sixiemejour);
          $clear5 = html_entity_decode($clear5);
          $clear5 = urldecode($clear5);
          $clear5 = preg_replace('/[^A-Za-z0-9]/', ' ', $clear5);
          $clear5 = preg_replace('/ +/', ' ', $clear5);
          $clear5 = trim($clear5);
          $test5 = preg_replace('/\s+/', '-', $clear5);
          $date5 = new DateTime($test5);
          $result5 = $date5->format('Y-m-d');

          $clear6 = strip_tags($septiemejour);
          $clear6 = html_entity_decode($clear6);
          $clear6 = urldecode($clear6);
          $clear6 = preg_replace('/[^A-Za-z0-9]/', ' ', $clear6);
          $clear6 = preg_replace('/ +/', ' ', $clear6);
          $clear6 = trim($clear6);
          $test6 = preg_replace('/\s+/', '-', $clear6);
          $date6 = new DateTime($test6);
          $result6 = $date6->format('Y-m-d');

$rq_lundi="select * from pointage_affaire where employe_matricule_affaire='$matricule' AND S='$semaine' AND date_affaire='$result' ;";
$rs_lundi = mysqli_query($cx,$rq_lundi) or die('Erreur SQL !<br>'.$rq_lundi.'<br>'.mysql_error());
          if(empty($rs_lundi)){$data_lundi = null;} else {$i = 0; while ($data_lundi = mysqli_fetch_array($rs_lundi)){$tab_affaire_lundi[$i] = $data_lundi; $i++;}}
          if(isset($tab_affaire_lundi[0])) {$tab_affaire_lundi[0] = $tab_affaire_lundi[0];} else {$tab_affaire_lundi[0] = null;}
          if(isset($tab_affaire_lundi[1])) {$tab_affaire_lundi[1] = $tab_affaire_lundi[1];} else {$tab_affaire_lundi[1] = null;}
          if(isset($tab_affaire_lundi[2])) {$tab_affaire_lundi[2] = $tab_affaire_lundi[2];} else {$tab_affaire_lundi[2] = null;}
          if(isset($tab_affaire_lundi[3])) {$tab_affaire_lundi[3] = $tab_affaire_lundi[3];} else {$tab_affaire_lundi[3] = null;}
          if(isset($tab_affaire_lundi[4])) {$tab_affaire_lundi[4] = $tab_affaire_lundi[4];} else {$tab_affaire_lundi[4] = null;}
          if(isset($tab_affaire_lundi[5])) {$tab_affaire_lundi[5] = $tab_affaire_lundi[5];} else {$tab_affaire_lundi[5] = null;}
          if(isset($tab_affaire_lundi[6])) {$tab_affaire_lundi[6] = $tab_affaire_lundi[6];} else {$tab_affaire_lundi[6] = null;}


if(!empty($tab_affaire_lundi[0]['absencej'])){
    if($tab_affaire_lundi[0]['absencej'] == "CP" Or $tab_affaire_lundi[0]['absencej'] == "JF"){
      $totallundi = 7.8;
    }
  } else {
    $totallundi = $tab_affaire_lundi[0]["heure_affaire"]+$tab_affaire_lundi[1]["heure_affaire"]+$tab_affaire_lundi[2]["heure_affaire"]+$tab_affaire_lundi[3]["heure_affaire"]+$tab_affaire_lundi[4]["heure_affaire"]+$tab_affaire_lundi[5]["heure_affaire"]+$tab_affaire_lundi[6]["heure_affaire"]+$tab_affaire_lundi[0]['delegation']+$tab_affaire_lundi[0]['visite_medicale']+$tab_affaire_lundi[0]['formation'];
  }
  if($tab_affaire_lundi[0]['absencej'] == "M" Or $tab_affaire_lundi[0]['absencej'] == "AT" Or $tab_affaire_lundi[0]['absencej'] == "ANA"){
    $totallundi = 0;
  }
  
  ############################################## MARDI
$rq_mardi="select * from pointage_affaire where employe_matricule_affaire='$matricule' AND S='$semaine' AND date_affaire='$result1' ;";
$rs_mardi = mysqli_query($cx,$rq_mardi) or die('Erreur SQL !<br>'.$rq_mardi.'<br>'.mysql_error());
          if(empty($rs_mardi)){$data_mardi = null;} else {$i = 0; while ($data_mardi = mysqli_fetch_array($rs_mardi)){$tab_affaire_mardi[$i] = $data_mardi; $i++;}}
          if(isset($tab_affaire_mardi[0])) {$tab_affaire_mardi[0] = $tab_affaire_mardi[0];} else {$tab_affaire_mardi[0] = null;}
          if(isset($tab_affaire_mardi[1])) {$tab_affaire_mardi[1] = $tab_affaire_mardi[1];} else {$tab_affaire_mardi[1] = null;}
          if(isset($tab_affaire_mardi[2])) {$tab_affaire_mardi[2] = $tab_affaire_mardi[2];} else {$tab_affaire_mardi[2] = null;}
          if(isset($tab_affaire_mardi[3])) {$tab_affaire_mardi[3] = $tab_affaire_mardi[3];} else {$tab_affaire_mardi[3] = null;}
          if(isset($tab_affaire_mardi[4])) {$tab_affaire_mardi[4] = $tab_affaire_mardi[4];} else {$tab_affaire_mardi[4] = null;}
          if(isset($tab_affaire_mardi[5])) {$tab_affaire_mardi[5] = $tab_affaire_mardi[5];} else {$tab_affaire_mardi[5] = null;}
          if(isset($tab_affaire_mardi[6])) {$tab_affaire_mardi[6] = $tab_affaire_mardi[6];} else {$tab_affaire_mardi[6] = null;}

if(!empty($tab_affaire_mardi[0]['absencej'])){
if($tab_affaire_mardi[0]['absencej'] == "CP" Or $tab_affaire_mardi[0]['absencej'] == "JF"){
$totalmardi = 7.8;
}
} else {
$totalmardi = $tab_affaire_mardi[0]["heure_affaire"]+$tab_affaire_mardi[1]["heure_affaire"]+$tab_affaire_mardi[2]["heure_affaire"]+$tab_affaire_mardi[3]["heure_affaire"]+$tab_affaire_mardi[4]["heure_affaire"]+$tab_affaire_mardi[5]["heure_affaire"]+$tab_affaire_mardi[6]["heure_affaire"]+$tab_affaire_mardi[0]['delegation']+$tab_affaire_mardi[0]['visite_medicale']+$tab_affaire_mardi[0]['formation'];
}
if($tab_affaire_mardi[0]['absencej'] == "M" Or $tab_affaire_mardi[0]['absencej'] == "AT" Or $tab_affaire_mardi[0]['absencej'] == "ANA"){
  $totalmardi = 0;
}
############################################### mercredi
  $rq_mercredi="select * from pointage_affaire where employe_matricule_affaire='$matricule' AND S='$semaine' AND date_affaire='$result2' ;";
$rs_mercredi = mysqli_query($cx,$rq_mercredi) or die('Erreur SQL !<br>'.$rq_mercredi.'<br>'.mysql_error());
          if(empty($rs_mercredi)){$data_mercredi = null;} else {$i = 0; while ($data_mercredi = mysqli_fetch_array($rs_mercredi)){$tab_affaire_mercredi[$i] = $data_mercredi; $i++;}}
          if(isset($tab_affaire_mercredi[0])) {$tab_affaire_mercredi[0] = $tab_affaire_mercredi[0];} else {$tab_affaire_mercredi[0] = null;}
          if(isset($tab_affaire_mercredi[1])) {$tab_affaire_mercredi[1] = $tab_affaire_mercredi[1];} else {$tab_affaire_mercredi[1] = null;}
          if(isset($tab_affaire_mercredi[2])) {$tab_affaire_mercredi[2] = $tab_affaire_mercredi[2];} else {$tab_affaire_mercredi[2] = null;}
          if(isset($tab_affaire_mercredi[3])) {$tab_affaire_mercredi[3] = $tab_affaire_mercredi[3];} else {$tab_affaire_mercredi[3] = null;}
          if(isset($tab_affaire_mercredi[4])) {$tab_affaire_mercredi[4] = $tab_affaire_mercredi[4];} else {$tab_affaire_mercredi[4] = null;}
          if(isset($tab_affaire_mercredi[5])) {$tab_affaire_mercredi[5] = $tab_affaire_mercredi[5];} else {$tab_affaire_mercredi[5] = null;}
          if(isset($tab_affaire_mercredi[6])) {$tab_affaire_mercredi[6] = $tab_affaire_mercredi[6];} else {$tab_affaire_mercredi[6] = null;}

if(!empty($tab_affaire_mercredi[0]['absencej'])){
if($tab_affaire_mercredi[0]['absencej'] == "CP" Or $tab_affaire_mercredi[0]['absencej'] == "JF"){
$totalmercredi = 7.8;
}
} else {
$totalmercredi = $tab_affaire_mercredi[0]['heure_affaire']+$tab_affaire_mercredi[1]['heure_affaire']+$tab_affaire_mercredi[2]['heure_affaire']+$tab_affaire_mercredi[3]['heure_affaire']+$tab_affaire_mercredi[4]['heure_affaire']+$tab_affaire_mercredi[5]['heure_affaire']+$tab_affaire_mercredi[6]['heure_affaire']+$tab_affaire_mercredi[0]['delegation']+$tab_affaire_mercredi[0]['visite_medicale']+$tab_affaire_mercredi[0]['formation'];
}
if($tab_affaire_mercredi[0]['absencej'] == "M" Or $tab_affaire_mercredi[0]['absencej'] == "AT" Or $tab_affaire_mercredi[0]['absencej'] == "ANA"){
  $totalmercredi = 0;
}
############################################### jeudi
$rq_jeudi="select * from pointage_affaire where employe_matricule_affaire='$matricule' AND S='$semaine' AND date_affaire='$result3' ;";
$rs_jeudi = mysqli_query($cx,$rq_jeudi) or die('Erreur SQL !<br>'.$rq_jeudi.'<br>'.mysql_error());
          if(empty($rs_jeudi)){$data_jeudi = null;} else {$i = 0; while ($data_jeudi = mysqli_fetch_array($rs_jeudi)){$tab_affaire_jeudi[$i] = $data_jeudi; $i++;}}
          if(isset($tab_affaire_jeudi[0])) {$tab_affaire_jeudi[0] = $tab_affaire_jeudi[0];} else {$tab_affaire_jeudi[0] = null;}
          if(isset($tab_affaire_jeudi[1])) {$tab_affaire_jeudi[1] = $tab_affaire_jeudi[1];} else {$tab_affaire_jeudi[1] = null;}
          if(isset($tab_affaire_jeudi[2])) {$tab_affaire_jeudi[2] = $tab_affaire_jeudi[2];} else {$tab_affaire_jeudi[2] = null;}
          if(isset($tab_affaire_jeudi[3])) {$tab_affaire_jeudi[3] = $tab_affaire_jeudi[3];} else {$tab_affaire_jeudi[3] = null;}
          if(isset($tab_affaire_jeudi[4])) {$tab_affaire_jeudi[4] = $tab_affaire_jeudi[4];} else {$tab_affaire_jeudi[4] = null;}
          if(isset($tab_affaire_jeudi[5])) {$tab_affaire_jeudi[5] = $tab_affaire_jeudi[5];} else {$tab_affaire_jeudi[5] = null;}
          if(isset($tab_affaire_jeudi[6])) {$tab_affaire_jeudi[6] = $tab_affaire_jeudi[6];} else {$tab_affaire_jeudi[6] = null;}

if(!empty($tab_affaire_jeudi[0]['absencej'])){
if($tab_affaire_jeudi[0]['absencej'] == "CP" Or $tab_affaire_jeudi[0]['absencej'] == "JF"){
$totaljeudi = 7.8;
}
} else {
$totaljeudi = $tab_affaire_jeudi[0]['heure_affaire']+$tab_affaire_jeudi[1]['heure_affaire']+$tab_affaire_jeudi[2]['heure_affaire']+$tab_affaire_jeudi[3]['heure_affaire']+$tab_affaire_jeudi[4]['heure_affaire']+$tab_affaire_jeudi[5]['heure_affaire']+$tab_affaire_jeudi[6]['heure_affaire']+$tab_affaire_jeudi[0]['delegation']+$tab_affaire_jeudi[0]['visite_medicale']+$tab_affaire_jeudi[0]['formation'];
}
if($tab_affaire_jeudi[0]['absencej'] == "M" Or $tab_affaire_jeudi[0]['absencej'] == "AT" Or $tab_affaire_jeudi[0]['absencej'] == "ANA"){
  $totaljeudi = 0;
}
############################################### vendredi
$rq_vendredi="select * from pointage_affaire where employe_matricule_affaire='$matricule' AND S='$semaine' AND date_affaire='$result4' ;";
$rs_vendredi = mysqli_query($cx,$rq_vendredi) or die('Erreur SQL !<br>'.$rq_vendredi.'<br>'.mysql_error());
          if(empty($rs_vendredi)){$data_vendredi = null;} else {$i = 0; while ($data_vendredi = mysqli_fetch_array($rs_vendredi)){$tab_affaire_vendredi[$i] = $data_vendredi; $i++;}}
          if(isset($tab_affaire_vendredi[0])) {$tab_affaire_vendredi[0] = $tab_affaire_vendredi[0];} else {$tab_affaire_vendredi[0] = null;}
          if(isset($tab_affaire_vendredi[1])) {$tab_affaire_vendredi[1] = $tab_affaire_vendredi[1];} else {$tab_affaire_vendredi[1] = null;}
          if(isset($tab_affaire_vendredi[2])) {$tab_affaire_vendredi[2] = $tab_affaire_vendredi[2];} else {$tab_affaire_vendredi[2] = null;}
          if(isset($tab_affaire_vendredi[3])) {$tab_affaire_vendredi[3] = $tab_affaire_vendredi[3];} else {$tab_affaire_vendredi[3] = null;}
          if(isset($tab_affaire_vendredi[4])) {$tab_affaire_vendredi[4] = $tab_affaire_vendredi[4];} else {$tab_affaire_vendredi[4] = null;}
          if(isset($tab_affaire_vendredi[5])) {$tab_affaire_vendredi[5] = $tab_affaire_vendredi[5];} else {$tab_affaire_vendredi[5] = null;}
          if(isset($tab_affaire_vendredi[6])) {$tab_affaire_vendredi[6] = $tab_affaire_vendredi[6];} else {$tab_affaire_vendredi[6] = null;}

if(!empty($tab_affaire_vendredi[0]['absencej'])){
if($tab_affaire_vendredi[0]['absencej'] == "CP" Or $tab_affaire_vendredi[0]['absencej'] == "JF"){
$totalvendredi = 7.8;
}
} else {
$totalvendredi = $tab_affaire_vendredi[0]['heure_affaire']+$tab_affaire_vendredi[1]['heure_affaire']+$tab_affaire_vendredi[2]['heure_affaire']+$tab_affaire_vendredi[3]['heure_affaire']+$tab_affaire_vendredi[4]['heure_affaire']+$tab_affaire_vendredi[5]['heure_affaire']+$tab_affaire_vendredi[6]['heure_affaire']+$tab_affaire_vendredi[0]['delegation']+$tab_affaire_vendredi[0]['visite_medicale']+$tab_affaire_vendredi[0]['formation'];
}
if($tab_affaire_vendredi[0]['absencej'] == "M" Or $tab_affaire_vendredi[0]['absencej'] == "AT" Or $tab_affaire_vendredi[0]['absencej'] == "ANA"){
  $totalvendredi = 0;
}
############################################### samedi
$rq_samedi="select * from pointage_affaire where employe_matricule_affaire='$matricule' AND S='$semaine' AND date_affaire='$result5' ;";
$rs_samedi = mysqli_query($cx,$rq_samedi) or die('Erreur SQL !<br>'.$rq_samedi.'<br>'.mysql_error());
          if(empty($rs_samedi)){$data_samedi = null;} else {$i = 0; while ($data_samedi = mysqli_fetch_array($rs_samedi)){$tab_affaire_samedi[$i] = $data_samedi; $i++;}}
          if(isset($tab_affaire_samedi[0])) {$tab_affaire_samedi[0] = $tab_affaire_samedi[0];} else {$tab_affaire_samedi[0] = null;}
          if(isset($tab_affaire_samedi[1])) {$tab_affaire_samedi[1] = $tab_affaire_samedi[1];} else {$tab_affaire_samedi[1] = null;}
          if(isset($tab_affaire_samedi[2])) {$tab_affaire_samedi[2] = $tab_affaire_samedi[2];} else {$tab_affaire_samedi[2] = null;}
          if(isset($tab_affaire_samedi[3])) {$tab_affaire_samedi[3] = $tab_affaire_samedi[3];} else {$tab_affaire_samedi[3] = null;}
          if(isset($tab_affaire_samedi[4])) {$tab_affaire_samedi[4] = $tab_affaire_samedi[4];} else {$tab_affaire_samedi[4] = null;}
          if(isset($tab_affaire_samedi[5])) {$tab_affaire_samedi[5] = $tab_affaire_samedi[5];} else {$tab_affaire_samedi[5] = null;}
          if(isset($tab_affaire_samedi[6])) {$tab_affaire_samedi[6] = $tab_affaire_samedi[6];} else {$tab_affaire_samedi[6] = null;}

if(!empty($tab_affaire_samedi[0]['absencej'])){
if($tab_affaire_samedi[0]['absencej'] == "CP" Or $tab_affaire_samedi[0]['absencej'] == "JF"){
$totalsamedi = 7.8;
}
} else {
$totalsamedi = $tab_affaire_samedi[0]['heure_affaire']+$tab_affaire_samedi[1]['heure_affaire']+$tab_affaire_samedi[2]['heure_affaire']+$tab_affaire_samedi[3]['heure_affaire']+$tab_affaire_samedi[4]['heure_affaire']+$tab_affaire_samedi[5]['heure_affaire']+$tab_affaire_samedi[6]['heure_affaire']+$tab_affaire_samedi[0]['delegation']+$tab_affaire_samedi[0]['visite_medicale']+$tab_affaire_samedi[0]['formation'];
}
if($tab_affaire_samedi[0]['absencej'] == "M" Or $tab_affaire_samedi[0]['absencej'] == "AT" Or $tab_affaire_samedi[0]['absencej'] == "ANA"){
  $totalsamedi = 0;
}

############################################### dimanche
$rq_dimanche="select * from pointage_affaire where employe_matricule_affaire='$matricule' AND S='$semaine' AND date_affaire='$result6' ;";
$rs_dimanche = mysqli_query($cx,$rq_dimanche) or die('Erreur SQL !<br>'.$rq_dimanche.'<br>'.mysql_error());
          if(empty($rs_dimanche)){$data_dimanche = null;} else {$i = 0; while ($data_dimanche = mysqli_fetch_array($rs_dimanche)){$tab_affaire_dimanche[$i] = $data_dimanche; $i++;}}
          if(isset($tab_affaire_dimanche[0])) {$tab_affaire_dimanche[0] = $tab_affaire_dimanche[0];} else {$tab_affaire_dimanche[0] = null;}
          if(isset($tab_affaire_dimanche[1])) {$tab_affaire_dimanche[1] = $tab_affaire_dimanche[1];} else {$tab_affaire_dimanche[1] = null;}
          if(isset($tab_affaire_dimanche[2])) {$tab_affaire_dimanche[2] = $tab_affaire_dimanche[2];} else {$tab_affaire_dimanche[2] = null;}
          if(isset($tab_affaire_dimanche[3])) {$tab_affaire_dimanche[3] = $tab_affaire_dimanche[3];} else {$tab_affaire_dimanche[3] = null;}
          if(isset($tab_affaire_dimanche[4])) {$tab_affaire_dimanche[4] = $tab_affaire_dimanche[4];} else {$tab_affaire_dimanche[4] = null;}
          if(isset($tab_affaire_dimanche[5])) {$tab_affaire_dimanche[5] = $tab_affaire_dimanche[5];} else {$tab_affaire_dimanche[5] = null;}
          if(isset($tab_affaire_dimanche[6])) {$tab_affaire_dimanche[6] = $tab_affaire_dimanche[6];} else {$tab_affaire_dimanche[6] = null;}

if(!empty($tab_affaire_dimanche[0]['absencej'])){
if($tab_affaire_dimanche[0]['absencej'] == "CP" Or $tab_affaire_dimanche[0]['absencej'] == "JF"){
$totaldimanche = 7.8;
}
} else {
$totaldimanche = $tab_affaire_dimanche[0]['heure_affaire']+$tab_affaire_dimanche[1]['heure_affaire']+$tab_affaire_dimanche[2]['heure_affaire']+$tab_affaire_dimanche[3]['heure_affaire']+$tab_affaire_dimanche[4]['heure_affaire']+$tab_affaire_dimanche[5]['heure_affaire']+$tab_affaire_dimanche[6]['heure_affaire']+$tab_affaire_dimanche[0]['delegation']+$tab_affaire_dimanche[0]['visite_medicale']+$tab_affaire_dimanche[0]['formation'];
}
if($tab_affaire_dimanche[0]['absencej'] == "M" Or $tab_affaire_dimanche[0]['absencej'] == "AT" Or $tab_affaire_dimanche[0]['absencej'] == "ANA"){
  $totaldimanche = 0;
}
?>

  <table class="table table-striped table-bordered">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Dates</th>
      <th scope="col">Nuit</th>
      <th scope="col">Divers</th>
      <th scope="col">Chef d'équipe</th>
      <th scope="col">Hauteur M</th>
      <th scope="col">Four</th>
      <th scope="col">Chaleur</th>
      <th scope="col">Insalubrité</th>
      <th scope="col">Temps Voyage</th>
      <th scope="col">Chauffeur</th>
      <th scope="col">Panier</th>
      <th scope="col">Déplacement</th>
      <th scope="col">Total <br> Heures Travaillées</th>
      <th scope="col">N°Affaire + Heures</th>
      <th scope="col">N°Affaire + Heures</th>
      <th scope="col">N°Affaire + Heures</th>
      <th scope="col">N°Affaire + Heures</th>
      <th scope="col">N°Affaire + Heures</th>
      <th scope="col">N°Affaire + Heures</th>
      <th scope="col">N°Affaire + Heures</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Lundi <?php echo ($jour[1]);?></th>
      <td><?php echo $tab_affaire_lundi[0]['prime_nuit'];?></td>
      <td><?php echo $tab_affaire_lundi[0]['prime_divers'];?></td>
      <td><?php echo $tab_affaire_lundi[0]['prime_chef_equipe'];?></td>
      <td><?php echo $tab_affaire_lundi[0]['prime_hauteurM'];?></td>
      <td><?php echo $tab_affaire_lundi[0]['prime_four'];?></td>
      <td><?php echo $tab_affaire_lundi[0]['prime_chaleur'];?></td>
      <td><?php echo $tab_affaire_lundi[0]['prime_insalubrite'];?></td>
      <td><?php echo $tab_affaire_lundi[0]['prime_temps_voyage'];?></td>
      <td><?php echo $tab_affaire_lundi[0]['prime_chauffeur'];?></td>
      <td><?php echo $tab_affaire_lundi[0]['prime_panier'];?></td>
      <td><?php echo $tab_affaire_lundi[0]['prime_deplacement'];?></td>
      <td><?php echo $totallundi; ?></td>
      <td><?php $numero_affaire1 = 'N°'.$tab_affaire_lundi[0]['numero_affaire'].' - '.$tab_affaire_lundi[0]['heure_affaire'].'H'; if($numero_affaire1 == "N°0 - 0.0H") {$numero_affaire1="Aucun"; echo $numero_affaire1;} else { echo $numero_affaire1;} ?></td>
      <td><?php $numero_affaire2 = 'N°'.$tab_affaire_lundi[1]['numero_affaire'].' - '.$tab_affaire_lundi[1]['heure_affaire'].'H'; if($numero_affaire2 == "N°0 - 0.0H") {$numero_affaire2="Aucun"; echo $numero_affaire2;} else { echo $numero_affaire2;} ?></td>      
      <td><?php $numero_affaire3 = 'N°'.$tab_affaire_lundi[2]['numero_affaire'].' - '.$tab_affaire_lundi[2]['heure_affaire'].'H'; if($numero_affaire3 == "N°0 - 0.0H") {$numero_affaire3="Aucun"; echo $numero_affaire3;} else { echo $numero_affaire3;} ?></td>
      <td><?php if(!empty($tab_affaire_lundi[0]['absencej'])){$numero_affaire4 = $tab_affaire_lundi[0]['absencej'];} else {$numero_affaire4='N°'.$tab_affaire_lundi[3]['numero_affaire'].' - '.$tab_affaire_lundi[3]['heure_affaire'].'H';} if($numero_affaire4 == "N°0 - 0.0H") {$numero_affaire4="Aucun";} echo $numero_affaire4; ?></td>
      <td><?php if($tab_affaire_lundi[0]['delegation'] == 0){$numero_affaire5 = 'N°'.$tab_affaire_lundi[0]['numero_affaire'].' - '.$tab_affaire_lundi[4]['heure_affaire'].'H';}else {$numero_affaire5=$tab_affaire_lundi[4]['delegation'];} if($numero_affaire5 == "N°0 - 0.0H") {$numero_affaire5="Aucun";} echo $numero_affaire5; ?></td>
      <td><?php if($tab_affaire_lundi[0]['visite_medicale'] == 0){$numero_affaire6 = 'N°'.$tab_affaire_lundi[0]['numero_affaire'].' - '.$tab_affaire_lundi[5]['heure_affaire'].'H';}else {$numero_affaire6=$tab_affaire_lundi[5]['visite_medicale'];} if($numero_affaire6 == "N°0 - 0.0H") {$numero_affaire6="Aucun";} echo $numero_affaire6; ?></td>
      <td><?php if($tab_affaire_lundi[0]['formation'] == 0){$numero_affaire7 = 'N°'.$tab_affaire_lundi[0]['numero_affaire'].' - '.$tab_affaire_lundi[6]['heure_affaire'].'H';}else {$numero_affaire7=$tab_affaire_lundi[6]['formation'];} if($numero_affaire7 == "N°0 - 0.0H") {$numero_affaire7="Aucun";} echo $numero_affaire7; ?></td>
    </tr>
    <tr>
      <th scope="row">Mardi <?php echo ($jour[2]);?></th>
      <td><?php echo $tab_affaire_mardi[0]['prime_nuit'];?></td>
      <td><?php echo $tab_affaire_mardi[0]['prime_divers'];?></td>
      <td><?php echo $tab_affaire_mardi[0]['prime_chef_equipe'];?></td>
      <td><?php echo $tab_affaire_mardi[0]['prime_hauteurM'];?></td>
      <td><?php echo $tab_affaire_mardi[0]['prime_four'];?></td>
      <td><?php echo $tab_affaire_mardi[0]['prime_chaleur'];?></td>
      <td><?php echo $tab_affaire_mardi[0]['prime_insalubrite'];?></td>
      <td><?php echo $tab_affaire_mardi[0]['prime_temps_voyage'];?></td>
      <td><?php echo $tab_affaire_mardi[0]['prime_chauffeur'];?></td>
      <td><?php echo $tab_affaire_mardi[0]['prime_panier'];?></td>
      <td><?php echo $tab_affaire_mardi[0]['prime_deplacement'];?></td>
      <td><?php echo $totalmardi; ?></td>
      <td><?php $numero_affaire1 = 'N°'.$tab_affaire_mardi[0]['numero_affaire'].' - '.$tab_affaire_mardi[0]['heure_affaire'].'H'; if($numero_affaire1 == "N°0 - 0.0H") {$numero_affaire1="Aucun"; echo $numero_affaire1;} else { echo $numero_affaire1;} ?></td>
      <td><?php $numero_affaire2 = 'N°'.$tab_affaire_mardi[1]['numero_affaire'].' - '.$tab_affaire_mardi[1]['heure_affaire'].'H'; if($numero_affaire2 == "N°0 - 0.0H") {$numero_affaire2="Aucun"; echo $numero_affaire2;} else { echo $numero_affaire2;} ?></td>      
      <td><?php $numero_affaire3 = 'N°'.$tab_affaire_mardi[2]['numero_affaire'].' - '.$tab_affaire_mardi[2]['heure_affaire'].'H'; if($numero_affaire3 == "N°0 - 0.0H") {$numero_affaire3="Aucun"; echo $numero_affaire3;} else { echo $numero_affaire3;} ?></td>
      <td><?php if(!empty($tab_affaire_mardi[0]['absencej'])){$numero_affaire4 = $tab_affaire_mardi[0]['absencej'];} else {$numero_affaire4='N°'.$tab_affaire_mardi[3]['numero_affaire'].' - '.$tab_affaire_mardi[3]['heure_affaire'].'H';} if($numero_affaire4 == "N°0 - 0.0H") {$numero_affaire4="Aucun";} echo $numero_affaire4; ?></td>
      <td><?php if($tab_affaire_mardi[0]['delegation'] == 0){$numero_affaire5 = 'N°'.$tab_affaire_mardi[4]['numero_affaire'].' - '.$tab_affaire_mardi[4]['heure_affaire'].'H';}else {$numero_affaire5=$tab_affaire_mardi[0]['delegation'];} if($numero_affaire5 == "N°0 - 0.0H") {$numero_affaire5="Aucun";} echo $numero_affaire5; ?></td>
      <td><?php if($tab_affaire_mardi[0]['visite_medicale'] == 0){$numero_affaire6 = 'N°'.$tab_affaire_mardi[5]['numero_affaire'].' - '.$tab_affaire_mardi[5]['heure_affaire'].'H';}else {$numero_affaire6=$tab_affaire_mardi[0]['visite_medicale'];} if($numero_affaire6 == "N°0 - 0.0H") {$numero_affaire6="Aucun";} echo $numero_affaire6; ?></td>
      <td><?php if($tab_affaire_mardi[0]['formation'] == 0){$numero_affaire7 = 'N°'.$tab_affaire_mardi[6]['numero_affaire'].' - '.$tab_affaire_mardi[6]['heure_affaire'].'H';}else {$numero_affaire7=$tab_affaire_mardi[0]['formation'];} if($numero_affaire7 == "N°0 - 0.0H") {$numero_affaire7="Aucun";} echo $numero_affaire7; ?></td>
    </tr>
    <tr>
      <th scope="row">Mercredi <?php echo ($jour[3]);?></th>
      <td><?php echo $tab_affaire_mercredi[0]['prime_nuit'];?></td>
      <td><?php echo $tab_affaire_mercredi[0]['prime_divers'];?></td>
      <td><?php echo $tab_affaire_mercredi[0]['prime_chef_equipe'];?></td>
      <td><?php echo $tab_affaire_mercredi[0]['prime_hauteurM'];?></td>
      <td><?php echo $tab_affaire_mercredi[0]['prime_four'];?></td>
      <td><?php echo $tab_affaire_mercredi[0]['prime_chaleur'];?></td>
      <td><?php echo $tab_affaire_mercredi[0]['prime_insalubrite'];?></td>
      <td><?php echo $tab_affaire_mercredi[0]['prime_temps_voyage'];?></td>
      <td><?php echo $tab_affaire_mercredi[0]['prime_chauffeur'];?></td>
      <td><?php echo $tab_affaire_mercredi[0]['prime_panier'];?></td>
      <td><?php echo $tab_affaire_mercredi[0]['prime_deplacement'];?></td>
      <td><?php echo $totalmercredi; ?></td>
      <td><?php $numero_affaire1 = 'N°'.$tab_affaire_mercredi[0]['numero_affaire'].' - '.$tab_affaire_mercredi[0]['heure_affaire'].'H'; if($numero_affaire1 == "N°0 - 0.0H") {$numero_affaire1="Aucun"; echo $numero_affaire1;} else { echo $numero_affaire1;} ?></td>
      <td><?php $numero_affaire2 = 'N°'.$tab_affaire_mercredi[1]['numero_affaire'].' - '.$tab_affaire_mercredi[1]['heure_affaire'].'H'; if($numero_affaire2 == "N°0 - 0.0H") {$numero_affaire2="Aucun"; echo $numero_affaire2;} else { echo $numero_affaire2;} ?></td>      
      <td><?php $numero_affaire3 = 'N°'.$tab_affaire_mercredi[2]['numero_affaire'].' - '.$tab_affaire_mercredi[2]['heure_affaire'].'H'; if($numero_affaire3 == "N°0 - 0.0H") {$numero_affaire3="Aucun"; echo $numero_affaire3;} else { echo $numero_affaire3;} ?></td>
      <td><?php if(!empty($tab_affaire_mercredi[0]['absencej'])){$numero_affaire4 = $tab_affaire_mercredi[0]['absencej'];} else {$numero_affaire4='N°'.$tab_affaire_mercredi[3]['numero_affaire'].' - '.$tab_affaire_mercredi[3]['heure_affaire'].'H';} if($numero_affaire4 == "N°0 - 0.0H") {$numero_affaire4="Aucun";} echo $numero_affaire4; ?></td>
      <td><?php if($tab_affaire_mercredi[0]['delegation'] == 0){$numero_affaire5 = 'N°'.$tab_affaire_mercredi[4]['numero_affaire'].' - '.$tab_affaire_mercredi[4]['heure_affaire'].'H';}else {$numero_affaire5=$tab_affaire_mercredi[0]['delegation'];} if($numero_affaire5 == "N°0 - 0.0H") {$numero_affaire5="Aucun";} echo $numero_affaire5; ?></td>
      <td><?php if($tab_affaire_mercredi[0]['visite_medicale'] == 0){$numero_affaire6 = 'N°'.$tab_affaire_mercredi[5]['numero_affaire'].' - '.$tab_affaire_mercredi[5]['heure_affaire'].'H';}else {$numero_affaire6=$tab_affaire_mercredi[0]['visite_medicale'];} if($numero_affaire6 == "N°0 - 0.0H") {$numero_affaire6="Aucun";} echo $numero_affaire6; ?></td>
      <td><?php if($tab_affaire_mercredi[0]['formation'] == 0){$numero_affaire7 = 'N°'.$tab_affaire_mercredi[6]['numero_affaire'].' - '.$tab_affaire_mercredi[6]['heure_affaire'].'H';}else {$numero_affaire7=$tab_affaire_mercredi[0]['formation'];} if($numero_affaire7 == "N°0 - 0.0H") {$numero_affaire7="Aucun";} echo $numero_affaire7; ?></td>
    </tr>
    <tr>
      <th scope="row">Jeudi <?php echo ($jour[4]);?></th>
      <td><?php echo $tab_affaire_jeudi[0]['prime_nuit'];?></td>
      <td><?php echo $tab_affaire_jeudi[0]['prime_divers'];?></td>
      <td><?php echo $tab_affaire_jeudi[0]['prime_chef_equipe'];?></td>
      <td><?php echo $tab_affaire_jeudi[0]['prime_hauteurM'];?></td>
      <td><?php echo $tab_affaire_jeudi[0]['prime_four'];?></td>
      <td><?php echo $tab_affaire_jeudi[0]['prime_chaleur'];?></td>
      <td><?php echo $tab_affaire_jeudi[0]['prime_insalubrite'];?></td>
      <td><?php echo $tab_affaire_jeudi[0]['prime_temps_voyage'];?></td>
      <td><?php echo $tab_affaire_jeudi[0]['prime_chauffeur'];?></td>
      <td><?php echo $tab_affaire_jeudi[0]['prime_panier'];?></td>
      <td><?php echo $tab_affaire_jeudi[0]['prime_deplacement'];?></td>
      <td><?php echo $totaljeudi; ?></td>
      <td><?php $numero_affaire1 = 'N°'.$tab_affaire_jeudi[0]['numero_affaire'].' - '.$tab_affaire_jeudi[0]['heure_affaire'].'H'; if($numero_affaire1 == "N°0 - 0.0H") {$numero_affaire1="Aucun"; echo $numero_affaire1;} else { echo $numero_affaire1;} ?></td>
      <td><?php $numero_affaire2 = 'N°'.$tab_affaire_jeudi[1]['numero_affaire'].' - '.$tab_affaire_jeudi[1]['heure_affaire'].'H'; if($numero_affaire2 == "N°0 - 0.0H") {$numero_affaire2="Aucun"; echo $numero_affaire2;} else { echo $numero_affaire2;} ?></td>      
      <td><?php $numero_affaire3 = 'N°'.$tab_affaire_jeudi[2]['numero_affaire'].' - '.$tab_affaire_jeudi[2]['heure_affaire'].'H'; if($numero_affaire3 == "N°0 - 0.0H") {$numero_affaire3="Aucun"; echo $numero_affaire3;} else { echo $numero_affaire3;} ?></td>
      <td><?php if(!empty($tab_affaire_jeudi[0]['absencej'])){$numero_affaire4 = $tab_affaire_jeudi[0]['absencej'];} else {$numero_affaire4='N°'.$tab_affaire_jeudi[3]['numero_affaire'].' - '.$tab_affaire_jeudi[3]['heure_affaire'].'H';} if($numero_affaire4 == "N°0 - 0.0H") {$numero_affaire4="Aucun";} echo $numero_affaire4; ?></td>
      <td><?php if($tab_affaire_jeudi[0]['delegation'] == 0){$numero_affaire5 = 'N°'.$tab_affaire_jeudi[4]['numero_affaire'].' - '.$tab_affaire_jeudi[4]['heure_affaire'].'H';}else {$numero_affaire5=$tab_affaire_jeudi[0]['delegation'];} if($numero_affaire5 == "N°0 - 0.0H") {$numero_affaire5="Aucun";} echo $numero_affaire5; ?></td>
      <td><?php if($tab_affaire_jeudi[0]['visite_medicale'] == 0){$numero_affaire6 = 'N°'.$tab_affaire_jeudi[5]['numero_affaire'].' - '.$tab_affaire_jeudi[5]['heure_affaire'].'H';}else {$numero_affaire6=$tab_affaire_jeudi[0]['visite_medicale'];} if($numero_affaire6 == "N°0 - 0.0H") {$numero_affaire6="Aucun";} echo $numero_affaire6; ?></td>
      <td><?php if($tab_affaire_jeudi[0]['formation'] == 0){$numero_affaire7 = 'N°'.$tab_affaire_jeudi[6]['numero_affaire'].' - '.$tab_affaire_jeudi[6]['heure_affaire'].'H';}else {$numero_affaire7=$tab_affaire_jeudi[0]['formation'];} if($numero_affaire7 == "N°0 - 0.0H") {$numero_affaire7="Aucun";} echo $numero_affaire7; ?></td>
    </tr>
    <tr>
      <th scope="row">Vendredi <?php echo ($jour[5]);?></th>
      <td><?php echo $tab_affaire_vendredi[0]['prime_nuit'];?></td>
      <td><?php echo $tab_affaire_vendredi[0]['prime_divers'];?></td>
      <td><?php echo $tab_affaire_vendredi[0]['prime_chef_equipe'];?></td>
      <td><?php echo $tab_affaire_vendredi[0]['prime_hauteurM'];?></td>
      <td><?php echo $tab_affaire_vendredi[0]['prime_four'];?></td>
      <td><?php echo $tab_affaire_vendredi[0]['prime_chaleur'];?></td>
      <td><?php echo $tab_affaire_vendredi[0]['prime_insalubrite'];?></td>
      <td><?php echo $tab_affaire_vendredi[0]['prime_temps_voyage'];?></td>
      <td><?php echo $tab_affaire_vendredi[0]['prime_chauffeur'];?></td>
      <td><?php echo $tab_affaire_vendredi[0]['prime_panier'];?></td>
      <td><?php echo $tab_affaire_vendredi[0]['prime_deplacement'];?></td>
      <td><?php echo $totalvendredi; ?></td>
      <td><?php $numero_affaire1 = 'N°'.$tab_affaire_vendredi[0]['numero_affaire'].' - '.$tab_affaire_vendredi[0]['heure_affaire'].'H'; if($numero_affaire1 == "N°0 - 0.0H") {$numero_affaire1="Aucun"; echo $numero_affaire1;} else { echo $numero_affaire1;} ?></td>
      <td><?php $numero_affaire2 = 'N°'.$tab_affaire_vendredi[1]['numero_affaire'].' - '.$tab_affaire_vendredi[1]['heure_affaire'].'H'; if($numero_affaire2 == "N°0 - 0.0H") {$numero_affaire2="Aucun"; echo $numero_affaire2;} else { echo $numero_affaire2;} ?></td>      
      <td><?php $numero_affaire3 = 'N°'.$tab_affaire_vendredi[2]['numero_affaire'].' - '.$tab_affaire_vendredi[2]['heure_affaire'].'H'; if($numero_affaire3 == "N°0 - 0.0H") {$numero_affaire3="Aucun"; echo $numero_affaire3;} else { echo $numero_affaire3;} ?></td>
      <td><?php if(!empty($tab_affaire_vendredi[0]['absencej'])){$numero_affaire4 = $tab_affaire_vendredi[0]['absencej'];} else {$numero_affaire4='N°'.$tab_affaire_vendredi[3]['numero_affaire'].' - '.$tab_affaire_vendredi[3]['heure_affaire'].'H';} if($numero_affaire4 == "N°0 - 0.0H") {$numero_affaire4="Aucun";} echo $numero_affaire4; ?></td>
      <td><?php if($tab_affaire_vendredi[0]['delegation'] == 0){$numero_affaire5 = 'N°'.$tab_affaire_vendredi[4]['numero_affaire'].' - '.$tab_affaire_vendredi[4]['heure_affaire'].'H';}else {$numero_affaire5=$tab_affaire_vendredi[0]['delegation'];} if($numero_affaire5 == "N°0 - 0.0H") {$numero_affaire5="Aucun";} echo $numero_affaire5; ?></td>
      <td><?php if($tab_affaire_vendredi[0]['visite_medicale'] == 0){$numero_affaire6 = 'N°'.$tab_affaire_vendredi[5]['numero_affaire'].' - '.$tab_affaire_vendredi[5]['heure_affaire'].'H';}else {$numero_affaire6=$tab_affaire_vendredi[0]['visite_medicale'];} if($numero_affaire6 == "N°0 - 0.0H") {$numero_affaire6="Aucun";} echo $numero_affaire6; ?></td>
      <td><?php if($tab_affaire_vendredi[0]['formation'] == 0){$numero_affaire7 = 'N°'.$tab_affaire_vendredi[6]['numero_affaire'].' - '.$tab_affaire_vendredi[6]['heure_affaire'].'H';}else {$numero_affaire7=$tab_affaire_vendredi[0]['formation'];} if($numero_affaire7 == "N°0 - 0.0H") {$numero_affaire7="Aucun";} echo $numero_affaire7; ?></td>
    </tr>
    <tr>
      <th scope="row">Samedi <?php echo ($jour[6]);?></th>
      <td><?php echo $tab_affaire_samedi[0]['prime_nuit'];?></td>
      <td><?php echo $tab_affaire_samedi[0]['prime_divers'];?></td>
      <td><?php echo $tab_affaire_samedi[0]['prime_chef_equipe'];?></td>
      <td><?php echo $tab_affaire_samedi[0]['prime_hauteurM'];?></td>
      <td><?php echo $tab_affaire_samedi[0]['prime_four'];?></td>
      <td><?php echo $tab_affaire_samedi[0]['prime_chaleur'];?></td>
      <td><?php echo $tab_affaire_samedi[0]['prime_insalubrite'];?></td>
      <td><?php echo $tab_affaire_samedi[0]['prime_temps_voyage'];?></td>
      <td><?php echo $tab_affaire_samedi[0]['prime_chauffeur'];?></td>
      <td><?php echo $tab_affaire_samedi[0]['prime_panier'];?></td>
      <td><?php echo $tab_affaire_samedi[0]['prime_deplacement'];?></td>
      <td><?php echo $totalsamedi; ?></td>
      <td><?php $numero_affaire1 = 'N°'.$tab_affaire_samedi[0]['numero_affaire'].' - '.$tab_affaire_samedi[0]['heure_affaire'].'H'; if($numero_affaire1 == "N°0 - 0.0H") {$numero_affaire1="Aucun"; echo $numero_affaire1;} else { echo $numero_affaire1;} ?></td>
      <td><?php $numero_affaire2 = 'N°'.$tab_affaire_samedi[1]['numero_affaire'].' - '.$tab_affaire_samedi[1]['heure_affaire'].'H'; if($numero_affaire2 == "N°0 - 0.0H") {$numero_affaire2="Aucun"; echo $numero_affaire2;} else { echo $numero_affaire2;} ?></td>      
      <td><?php $numero_affaire3 = 'N°'.$tab_affaire_samedi[2]['numero_affaire'].' - '.$tab_affaire_samedi[2]['heure_affaire'].'H'; if($numero_affaire3 == "N°0 - 0.0H") {$numero_affaire3="Aucun"; echo $numero_affaire3;} else { echo $numero_affaire3;} ?></td>
      <td><?php if(!empty($tab_affaire_samedi[0]['absencej'])){$numero_affaire4 = $tab_affaire_samedi[0]['absencej'];} else {$numero_affaire4='N°'.$tab_affaire_samedi[3]['numero_affaire'].' - '.$tab_affaire_samedi[3]['heure_affaire'].'H';} if($numero_affaire4 == "N°0 - 0.0H") {$numero_affaire4="Aucun";} echo $numero_affaire4; ?></td>
      <td><?php if($tab_affaire_samedi[0]['delegation'] == 0){$numero_affaire5 = 'N°'.$tab_affaire_samedi[4]['numero_affaire'].' - '.$tab_affaire_samedi[4]['heure_affaire'].'H';}else {$numero_affaire5=$tab_affaire_samedi[0]['delegation'];} if($numero_affaire5 == "N°0 - 0.0H") {$numero_affaire5="Aucun";} echo $numero_affaire5; ?></td>
      <td><?php if($tab_affaire_samedi[0]['visite_medicale'] == 0){$numero_affaire6 = 'N°'.$tab_affaire_samedi[5]['numero_affaire'].' - '.$tab_affaire_samedi[5]['heure_affaire'].'H';}else {$numero_affaire6=$tab_affaire_samedi[0]['visite_medicale'];} if($numero_affaire6 == "N°0 - 0.0H") {$numero_affaire6="Aucun";} echo $numero_affaire6; ?></td>
      <td><?php if($tab_affaire_samedi[0]['formation'] == 0){$numero_affaire7 = 'N°'.$tab_affaire_samedi[6]['numero_affaire'].' - '.$tab_affaire_samedi[6]['heure_affaire'].'H';}else {$numero_affaire7=$tab_affaire_samedi[0]['formation'];} if($numero_affaire7 == "N°0 - 0.0H") {$numero_affaire7="Aucun";} echo $numero_affaire7; ?></td>
    </tr>
    <tr>
      <th scope="row">Dimanche <?php echo ($jour[7]);?></th>
      <td><?php echo $tab_affaire_dimanche[0]['prime_nuit'];?></td>
      <td><?php echo $tab_affaire_dimanche[0]['prime_divers'];?></td>
      <td><?php echo $tab_affaire_dimanche[0]['prime_chef_equipe'];?></td>
      <td><?php echo $tab_affaire_dimanche[0]['prime_hauteurM'];?></td>
      <td><?php echo $tab_affaire_dimanche[0]['prime_four'];?></td>
      <td><?php echo $tab_affaire_dimanche[0]['prime_chaleur'];?></td>
      <td><?php echo $tab_affaire_dimanche[0]['prime_insalubrite'];?></td>
      <td><?php echo $tab_affaire_dimanche[0]['prime_temps_voyage'];?></td>
      <td><?php echo $tab_affaire_dimanche[0]['prime_chauffeur'];?></td>
      <td><?php echo $tab_affaire_dimanche[0]['prime_panier'];?></td>
      <td><?php echo $tab_affaire_dimanche[0]['prime_deplacement'];?></td>
      <td><?php echo $totaldimanche; ?></td>
      <td><?php $numero_affaire1 = 'N°'.$tab_affaire_dimanche[0]['numero_affaire'].' - '.$tab_affaire_dimanche[0]['heure_affaire'].'H'; if($numero_affaire1 == "N°0 - 0.0H") {$numero_affaire1="Aucun"; echo $numero_affaire1;} else { echo $numero_affaire1;} ?></td>
      <td><?php $numero_affaire2 = 'N°'.$tab_affaire_dimanche[1]['numero_affaire'].' - '.$tab_affaire_dimanche[1]['heure_affaire'].'H'; if($numero_affaire2 == "N°0 - 0.0H") {$numero_affaire2="Aucun"; echo $numero_affaire2;} else { echo $numero_affaire2;} ?></td>      
      <td><?php $numero_affaire3 = 'N°'.$tab_affaire_dimanche[2]['numero_affaire'].' - '.$tab_affaire_dimanche[2]['heure_affaire'].'H'; if($numero_affaire3 == "N°0 - 0.0H") {$numero_affaire3="Aucun"; echo $numero_affaire3;} else { echo $numero_affaire3;} ?></td>
      <td><?php if(!empty($tab_affaire_dimanche[0]['absencej'])){$numero_affaire4 = $tab_affaire_dimanche[0]['absencej'];} else {$numero_affaire4='N°'.$tab_affaire_dimanche[3]['numero_affaire'].' - '.$tab_affaire_dimanche[3]['heure_affaire'].'H';} if($numero_affaire4 == "N°0 - 0.0H") {$numero_affaire4="Aucun";} echo $numero_affaire4; ?></td>
      <td><?php if($tab_affaire_dimanche[0]['delegation'] == 0){$numero_affaire5 = 'N°'.$tab_affaire_dimanche[4]['numero_affaire'].' - '.$tab_affaire_dimanche[4]['heure_affaire'].'H';}else {$numero_affaire5=$tab_affaire_dimanche[0]['delegation'];} if($numero_affaire5 == "N°0 - 0.0H") {$numero_affaire5="Aucun";} echo $numero_affaire5; ?></td>
      <td><?php if($tab_affaire_dimanche[0]['visite_medicale'] == 0){$numero_affaire6 = 'N°'.$tab_affaire_dimanche[5]['numero_affaire'].' - '.$tab_affaire_dimanche[5]['heure_affaire'].'H';}else {$numero_affaire6=$tab_affaire_dimanche[0]['visite_medicale'];} if($numero_affaire6 == "N°0 - 0.0H") {$numero_affaire6="Aucun";} echo $numero_affaire6; ?></td>
      <td><?php if($tab_affaire_dimanche[0]['formation'] == 0){$numero_affaire7 = 'N°'.$tab_affaire_dimanche[6]['numero_affaire'].' - '.$tab_affaire_dimanche[6]['heure_affaire'].'H';}else {$numero_affaire7=$tab_affaire_dimanche[0]['formation'];} if($numero_affaire7 == "N°0 - 0.0H") {$numero_affaire7="Aucun";} echo $numero_affaire7; ?></td>
    </tr>
    <tr>
    <?php $totalsemaine = $totallundi + $totalmardi + $totalmercredi + $totaljeudi + $totalvendredi + $totalsamedi + $totaldimanche; 
    $totalnuit = $tab_affaire_lundi[0]['prime_nuit'] + $tab_affaire_mardi[0]['prime_nuit'] + $tab_affaire_mercredi[0]['prime_nuit'] + $tab_affaire_jeudi[0]['prime_nuit'] +  $tab_affaire_vendredi[0]['prime_nuit'] +  $tab_affaire_samedi[0]['prime_nuit'] + $tab_affaire_dimanche[0]['prime_nuit'];
    $totaldivers = $tab_affaire_lundi[0]['prime_divers'] + $tab_affaire_mardi[0]['prime_divers'] + $tab_affaire_mercredi[0]['prime_divers'] + $tab_affaire_jeudi[0]['prime_divers'] +  $tab_affaire_vendredi[0]['prime_divers'] +  $tab_affaire_samedi[0]['prime_divers'] + $tab_affaire_dimanche[0]['prime_divers'];
    $totalchefequipe = $tab_affaire_lundi[0]['prime_chef_equipe'] + $tab_affaire_mardi[0]['prime_chef_equipe'] + $tab_affaire_mercredi[0]['prime_chef_equipe'] + $tab_affaire_jeudi[0]['prime_chef_equipe'] +  $tab_affaire_vendredi[0]['prime_chef_equipe'] +  $tab_affaire_samedi[0]['prime_chef_equipe'] + $tab_affaire_dimanche[0]['prime_chef_equipe'];
    $totalhauteurM= $tab_affaire_lundi[0]['prime_hauteurM'] + $tab_affaire_mardi[0]['prime_hauteurM'] + $tab_affaire_mercredi[0]['prime_hauteurM'] + $tab_affaire_jeudi[0]['prime_hauteurM'] +  $tab_affaire_vendredi[0]['prime_hauteurM'] +  $tab_affaire_samedi[0]['prime_hauteurM'] + $tab_affaire_dimanche[0]['prime_hauteurM'];
    $totalfour = $tab_affaire_lundi[0]['prime_four'] + $tab_affaire_mardi[0]['prime_four'] + $tab_affaire_mercredi[0]['prime_four'] + $tab_affaire_jeudi[0]['prime_four'] +  $tab_affaire_vendredi[0]['prime_four'] +  $tab_affaire_samedi[0]['prime_four'] + $tab_affaire_dimanche[0]['prime_four'];
    $totalchaleur = $tab_affaire_lundi[0]['prime_chaleur'] + $tab_affaire_mardi[0]['prime_chaleur'] + $tab_affaire_mercredi[0]['prime_chaleur'] + $tab_affaire_jeudi[0]['prime_chaleur'] +  $tab_affaire_vendredi[0]['prime_chaleur'] +  $tab_affaire_samedi[0]['prime_chaleur'] + $tab_affaire_dimanche[0]['prime_chaleur'];
    $totalinsalubrite = $tab_affaire_lundi[0]['prime_insalubrite'] + $tab_affaire_mardi[0]['prime_insalubrite'] + $tab_affaire_mercredi[0]['prime_insalubrite'] + $tab_affaire_jeudi[0]['prime_insalubrite'] +  $tab_affaire_vendredi[0]['prime_insalubrite'] +  $tab_affaire_samedi[0]['prime_insalubrite'] + $tab_affaire_dimanche[0]['prime_insalubrite'];
    $totaltempsvoyage = $tab_affaire_lundi[0]['prime_temps_voyage'] + $tab_affaire_mardi[0]['prime_temps_voyage'] + $tab_affaire_mercredi[0]['prime_temps_voyage'] + $tab_affaire_jeudi[0]['prime_temps_voyage'] +  $tab_affaire_vendredi[0]['prime_temps_voyage'] +  $tab_affaire_samedi[0]['prime_temps_voyage'] + $tab_affaire_dimanche[0]['prime_temps_voyage'];
    $totalchauffeur = $tab_affaire_lundi[0]['prime_chauffeur'] + $tab_affaire_mardi[0]['prime_chauffeur'] + $tab_affaire_mercredi[0]['prime_chauffeur'] + $tab_affaire_jeudi[0]['prime_chauffeur'] +  $tab_affaire_vendredi[0]['prime_chauffeur'] +  $tab_affaire_samedi[0]['prime_chauffeur'] + $tab_affaire_dimanche[0]['prime_chauffeur'];
    $totalpanier = $tab_affaire_lundi[0]['prime_panier'] + $tab_affaire_mardi[0]['prime_panier'] + $tab_affaire_mercredi[0]['prime_panier'] + $tab_affaire_jeudi[0]['prime_panier'] +  $tab_affaire_vendredi[0]['prime_panier'] +  $tab_affaire_samedi[0]['prime_panier'] + $tab_affaire_dimanche[0]['prime_panier'];
    $totaldeplacement = $tab_affaire_lundi[0]['prime_deplacement'] + $tab_affaire_mardi[0]['prime_deplacement'] + $tab_affaire_mercredi[0]['prime_deplacement'] + $tab_affaire_jeudi[0]['prime_deplacement'] +  $tab_affaire_vendredi[0]['prime_deplacement'] +  $tab_affaire_samedi[0]['prime_deplacement'] + $tab_affaire_dimanche[0]['prime_deplacement'];
  
    
    ?>
      <th scope="row">Totaux</th>
      <td><?php echo $totalnuit; ?></td>
      <td><?php echo $totaldivers; ?></td>
      <td><?php echo $totalchefequipe; ?></td>
      <td><?php echo $totalhauteurM; ?></td>
      <td><?php echo $totalfour; ?></td>
      <td><?php echo $totalchaleur; ?></td>
      <td><?php echo $totalinsalubrite; ?></td>
      <td><?php echo $totaltempsvoyage; ?></td>
      <td><?php echo $totalchauffeur; ?></td>
      <td><?php echo $totalpanier; ?></td>
      <td><?php echo $totaldeplacement; ?></td>
      <td><?php echo $totalsemaine;?></td>

    </tr>
    <tr>
    <?php 
    if($totalsemaine > 39)
    {$surplus = $totalsemaine - 39;} 
    else{$surplus = 0;} 
    if($totalsemaine < 39)
    {$manque = $totalsemaine - 39;}
    else{$manque = 0;}
    $vingtcinq = 0;
    if($totalsemaine>44){$vingtcinq = $totalsemaine - 44;}
    if($vingtcinq >= 3){$test = $vingtcinq;}
    $cinquante = 0;
    if($totalsemaine>47){$cinquante = $totalsemaine - 47;}
    $test = $vingtcinq - $cinquante;
    $compteurplus = 0;
    if($totalsemaine>39){$compteurplus = $totalsemaine - 39;}
    if($compteurplus >= 5){$incremente = $compteurplus;}
    $incremente = $compteurplus - $vingtcinq;



    ?>
      <td colspan="2"><?php if(!empty($surplus)){echo $surplus;}else{echo $manque;} ?></td>
    </tr>
    <tr>
      <th>Compteur +</th>
      <td><?php echo $incremente;?></td>
    </tr>
    <th>Compteur - </th>
    <td><?php echo $manque;?></td>
    </tr>
    <th>A payer 25%</th>
    <td><?php echo $test; ?></td> 
    </tr>
    <th>A Payer 50%</th>
    <td><?php if(isset($cinquante)){echo $cinquante;}?></td>
    </tr>
  </tbody>
</table>


      <!-- Bootstrap core JavaScript
      ================================================== -->
      <!-- Placed at the end of the document so the pages load faster -->
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </body>
  </html>
  
  
<!--###################################################################--> 
<!--#                  Projet: Application de pointage                #-->  
<!--#                  Entreprise: Cegelec                            #-->  
<!--#                  Auteurs: Maverick Lafont & Emrik Lecomte       #--> 
<!--#                  Position: Job d'été MIJ                        #--> 
<!--#                  Scolaire: BTS SIO 2ième Année                  #--> 
<!--###################################################################--> 