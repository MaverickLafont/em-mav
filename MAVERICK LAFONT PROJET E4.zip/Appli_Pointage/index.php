<?php
  session_start('cegelec');

    include"php/connexion.php";

  error_reporting(E_ALL);
    ini_set('display_errors', '0');


  if (isset($_SESSION['username'])) {
          echo("<script>location.href = 'index.php';</script>");
        }    
?>
<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="css/index.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">
    </head>
    <body>
<div class="main">
    
    
    <div class="container">
<center>
<div class="middle">
      <div id="login">

        <form action="php/connexion_traitement.php" method="post">

          <fieldset class="clearfix">

            <p ><span class="fa fa-user"></span><input type="text" name="username" Placeholder="NOM.prenom" required></p> <!-- JS because of IE support; better: placeholder="Username" -->
            <p><span class="fa fa-lock"></span><input type="password" name="password" Placeholder="Mot de passe" required></p> <!-- JS because of IE support; better: placeholder="Password" -->
            <?php 
        if(isset($_GET['erreur'])) {
          switch ($_GET['erreur']) {
            case 1:
            echo "utilisateur ou mot de passe incorrect"; break;
            case 2:
            echo "utilisateur ou mot de passe vide"; break;
          }
        }
        ?>
            
             <div>
                                
                                <span style="width:50%; text-align:right;  display: inline-block;">  <button type="submit" name="connexion" id="connexion" class="btn btn-dark">Connexion</button> </span>
                            </div>
          </fieldset>
<div class="clearfix"></div>
        </form>
        <div id="message" class="col-md-4">
          
          </div>

        <div class="clearfix"></div>

      </div> <!-- end login -->
      <div class="logo"><img src="images/cegelec.png" alt="logo-cegelec">
          
          <div class="clearfix"></div>
      </div>
      
      </div>
</center>
    </div>

</div>



 <!-- Bootstrap core JavaScript
      ================================================== -->
      <!-- Placed at the end of the document so the pages load faster -->
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
      <script src="dist/js/jquery.min.js"></script>
    </body>
    </html>