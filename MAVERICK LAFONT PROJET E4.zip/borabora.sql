-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Lun 09 Juillet 2018 à 18:46
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `borabora`
--

-- --------------------------------------------------------

--
-- Structure de la table `cat_cons`
--

CREATE TABLE IF NOT EXISTS `cat_cons` (
  `cat` varchar(6) NOT NULL,
  `libcat` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`cat`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `cat_cons`
--

INSERT INTO `cat_cons` (`cat`, `libcat`) VALUES
('ALCOOL', 'Alcool'),
('APEBIE', 'Apéritif à la bière'),
('APERIT', 'Apéritif'),
('BIEAMB', 'Bière ambrée'),
('BIEBLA', 'Bière blanche'),
('BIEBLO', 'Bière blonde'),
('BIESCO', 'Bière scotch'),
('BIESPE', 'Bière spéciale'),
('COKTAI', 'Coktail'),
('EAUMIN', 'Eaux minérales'),
('JUSFRA', 'Jus de fruits frais'),
('LACAVE', 'La cave'),
('NECTAR', 'Nectars'),
('SODAS', 'Sodas'),
('WHISKY', 'Whisky');

-- --------------------------------------------------------

--
-- Structure de la table `comprend`
--

CREATE TABLE IF NOT EXISTS `comprend` (
  `numfact` int(11) NOT NULL,
  `numcons` int(3) NOT NULL,
  `qte` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`numfact`,`numcons`),
  KEY `fk1_comprend` (`numcons`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `consommation`
--

CREATE TABLE IF NOT EXISTS `consommation` (
  `num_cons` int(3) NOT NULL,
  `lib_cons` varchar(25) DEFAULT NULL,
  `prix_cons` float DEFAULT NULL,
  `cat` varchar(6) DEFAULT NULL,
  PRIMARY KEY (`num_cons`),
  KEY `fk_cat` (`cat`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `consommation`
--

INSERT INTO `consommation` (`num_cons`, `lib_cons`, `prix_cons`, `cat`) VALUES
(1, 'Demi 25cl', 700, 'BIEBLA'),
(2, 'Taverne 33cl', 800, 'BIEBLA'),
(3, 'Brasseur 50cl', 1000, 'BIEBLA'),
(4, 'Formidable 100cl', 1900, 'BIEBLA'),
(5, 'Pichet 1,5l', 3200, 'BIEBLA'),
(6, 'Le mètre 25cl *10', 5000, 'BIEBLA'),
(7, 'Demi 25cl', 700, 'BIEBLO'),
(8, 'Taverne 33cl', 800, 'BIEBLO'),
(9, 'Brasseur 50cl', 1000, 'BIEBLO'),
(10, 'Formidable 100cl', 1900, 'BIEBLO'),
(11, 'Pichet 1,5l', 3200, 'BIEBLO'),
(12, 'Le mètre 25cl *10', 5000, 'BIEBLO'),
(13, 'Demi 25cl', 700, 'BIEBLO'),
(14, 'Taverne 33cl', 800, 'BIEBLO'),
(15, 'Brasseur 50cl', 1000, 'BIEBLO'),
(16, 'Formidable 100cl', 1900, 'BIEBLO'),
(17, 'Pichet 1,5l', 3200, 'BIEBLO'),
(18, 'Le mètre 25cl *10', 5000, 'BIEBLO');

-- --------------------------------------------------------

--
-- Structure de la table `employe`
--

CREATE TABLE IF NOT EXISTS `employe` (
  `id_emp` int(11) NOT NULL AUTO_INCREMENT,
  `nom_emp` varchar(50) NOT NULL,
  `prenom_emp` varchar(50) NOT NULL,
  `login_emp` varchar(50) NOT NULL,
  `mdp_emp` varchar(50) NOT NULL,
  PRIMARY KEY (`id_emp`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `employe`
--

INSERT INTO `employe` (`id_emp`, `nom_emp`, `prenom_emp`, `login_emp`, `mdp_emp`) VALUES
(1, 'Dupont', 'Jean', 'dupont.jean', 'dupont.jean');

-- --------------------------------------------------------

--
-- Structure de la table `facture`
--

CREATE TABLE IF NOT EXISTS `facture` (
  `numfact` int(11) NOT NULL AUTO_INCREMENT,
  `datefac` date DEFAULT NULL,
  PRIMARY KEY (`numfact`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `reservation`
--

CREATE TABLE IF NOT EXISTS `reservation` (
  `num_reservation` int(5) NOT NULL AUTO_INCREMENT,
  `jour_reservation` date NOT NULL,
  `heure_debut` time NOT NULL,
  `heure_fin` time NOT NULL,
  `id_soin` int(5) NOT NULL,
  PRIMARY KEY (`num_reservation`),
  KEY `id_soin` (`id_soin`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Contenu de la table `reservation`
--

INSERT INTO `reservation` (`num_reservation`, `jour_reservation`, `heure_debut`, `heure_fin`, `id_soin`) VALUES
(17, '2018-05-07', '00:08:00', '00:00:00', 3);

-- --------------------------------------------------------

--
-- Structure de la table `soin`
--

CREATE TABLE IF NOT EXISTS `soin` (
  `id_soin` int(11) NOT NULL AUTO_INCREMENT,
  `lib_soin` varchar(150) NOT NULL,
  `duree_soin` time NOT NULL,
  `prix_soin` int(11) NOT NULL,
  PRIMARY KEY (`id_soin`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- Contenu de la table `soin`
--

INSERT INTO `soin` (`id_soin`, `lib_soin`, `duree_soin`, `prix_soin`) VALUES
(1, 'SOIN CONTOUR DES YEUX ÉCLAT', '00:30:00', 6500),
(2, 'SOIN ÉCLAT IMMÉDIAT AUX FLEURS ', '01:00:00', 9500),
(3, 'SOIN PRODIGIEUX® À L’IMMORTELLE BLEUE ', '01:00:00', 12500),
(4, 'SOIN EXPRESS AUX EXTRAITS D’ARBRES - Pour Homme ', '00:30:00', 9500),
(5, 'SOIN AROMA-LACTÉ CRÈME FRAÎCHE ', '01:30:00', 13000),
(6, 'SOIN AROMA-PERFECTION® AUX PLANTES ', '01:30:00', 13000),
(7, 'SOIN ULTRA-RÉCONFORTANT AU MIEL ', '01:30:00', 13000),
(8, 'SOIN BEAU JOUEUR - Pour Homme', '01:30:00', 13000),
(9, 'SOIN BIO-BEAUTÉ', '01:30:00', 13000),
(10, 'SOIN NUXELLENCE', '01:30:00', 16000),
(11, 'SOIN NIRVANESQUE', '01:30:00', 16000),
(12, 'SOIN MERVEILLANCE expert', '01:30:00', 16000),
(13, 'ENVELOPPEMENT', '00:30:00', 6500),
(14, 'SOIN RÉVÉLATEUR D’ÉCLAT IMMÉDIAT', '01:00:00', 9000),
(15, 'SOIN «BODY RELAXANT» ', '01:00:00', 13000),
(16, 'SOIN du dos', '01:30:00', 14000),
(17, 'SOIN PRODIGIEUX', '01:30:00', 14000),
(18, 'SOIN RÊVE DE MIEL', '01:30:00', 15000),
(19, 'SOIN PURETÉ DU DOS - Pour Homme ', '01:30:00', 14000),
(20, 'SOIN RÊVERIE ORIENTALE ', '02:00:00', 18000);

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `comprend`
--
ALTER TABLE `comprend`
  ADD CONSTRAINT `comprend_ibfk_1` FOREIGN KEY (`numcons`) REFERENCES `consommation` (`num_cons`),
  ADD CONSTRAINT `comprend_ibfk_2` FOREIGN KEY (`numfact`) REFERENCES `facture` (`numfact`);

--
-- Contraintes pour la table `consommation`
--
ALTER TABLE `consommation`
  ADD CONSTRAINT `consommation_ibfk_1` FOREIGN KEY (`cat`) REFERENCES `cat_cons` (`cat`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
