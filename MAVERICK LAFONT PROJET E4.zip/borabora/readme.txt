Calendrier de reservation en php mysql--------------------------------------
Url     : http://codes-sources.commentcamarche.net/source/40895-calendrier-de-reservation-en-php-mysqlAuteur  : niconos_sagDate    : 03/08/2013
Licence :
=========

Ce document intitul� � Calendrier de reservation en php mysql � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Calendrier perp&eacute;tuel de r&eacute;servation (pour un gite, ou appartement 
ou autre).
<br />Permet d'afficher pour chaque jours si l'appartement (ou autre
) est pris.
<br /> 
<br />calendrier_bo.php est destin&eacute; &agrave; l'admi
n permet de s&eacute;lectionner ou d'enlever les jours r&eacute;serv&eacute;s.

<br />calendrier.php destin&eacute; au client avec uniquement l'affichage.
<br 
/>
<br />Je pense qu'il y &agrave; des am&eacute;liorations &agrave; faire (opt
imisation du code, possibilit&eacute; de mettre des commentaire etc... je me sui
s arr&ecirc;ter la car je n'ai pas besoin de plus).
<br />
<br />La base du co
des vient d'une source de se site : <a href='http://www.phpcs.com/article.aspx?I
D=248' target='_blank'>http://www.phpcs.com/article.aspx?ID=248</a>
