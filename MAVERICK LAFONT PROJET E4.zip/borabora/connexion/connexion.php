<?php
$serv='localhost';
$util='root';
$pwd='';
$base='borabora';
//connexion au serveur de données
$cx=mysqli_connect($serv,$util,$pwd) or die('connexion au serveur '.$serv.' impossible');
//connexion a la base de données
$cxb=mysqli_select_db($cx,$base) or die('connexion � la base '.$base.' impossible');
?>