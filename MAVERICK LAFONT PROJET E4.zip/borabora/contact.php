<?php $racine = $_SERVER['DOCUMENT_ROOT'] ?><!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="utf-8"/>
  <title>Contacts</title>
  <?php include_once $racine .'/borabora/include/head.php' ?>
</head>
<body>
  <?php include_once $racine .'/borabora/include/header.php' ?>
  
  <!--==============================content================================-->
    <section id="content"></div>
    	<div class="container_12 top">
        	<div class="grid_8">
            	<h2>Ou nous trouvez</h2>
                <div class="map img-border">
                  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d47079.268742577566!2d-151.75847344585898!3d-16.521747221150612!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x76bdbd188a4a98ab%3A0x160a089e92d5ce61!2sBora-Bora!5e0!3m2!1sfr!2s!4v1519616767331" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                </div>
                <div class="right-1">
                	<p>EMAIL</p>
					<p class="clr-1 p2">leborabora@gmail.com</p>
					
					<p>TELEPHONE</p>
					<p class="clr-1 p2">+689 40 603 300</p>
					
					<p>ADRESSE</p>
					<p class="clr-1 p2">BP 502 Vaitape, Bora Bora, 98730, Polynésie française</p>
				</div>
            </div>
            <div class="grid_4">
            	<h2>Contactez nous</h2>
            	<form id="form" method="post" action="mail.php">
                    <fieldset>
                      <label><input type="text" name="name" value="Nom & Prenom" onBlur="if(this.value=='') this.value='Nom & Prenom'" onFocus="if(this.value =='Nom & Prenom' ) this.value=''"></label>
                      <label><input type="text" name="email" value="Email" onBlur="if(this.value=='') this.value='Email'" onFocus="if(this.value =='Email' ) this.value=''"></label>
                      <label><input type="text" name="objet" value="Objet" onBlur="if(this.value=='') this.value='Objet'" onFocus="if(this.value =='Objet' ) this.value=''"></label>
                      <label><textarea name="message" onBlur="if(this.value==''){this.value='Message'}" onFocus="if(this.value=='Message'){this.value=''}">Message</textarea></label>
                      <div class="btns">
                      <a href="#" class="button">Effacer</a>
                      <input type="submit" value="Envoyer"/>
                      </div>
                    </fieldset>  
                  </form> 
            </div>
            <div class="clear"></div>
        </div>
    </section> 
<!--==============================footer=================================-->
  <?php include_once $racine .'/borabora/include/footer.php' ?>	
</body>
</html>