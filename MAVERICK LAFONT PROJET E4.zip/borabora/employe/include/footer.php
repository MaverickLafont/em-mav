<footer>
  <p>© 2018 Le Bora-Bora<br/> Website Template by <a class="link" href="http://store.templatemonster.com?aff=netsib1" target="_blank" rel="nofollow">www.templatemonster.com</a></p>
  <div class="soc-icons">
    <span>Suivez-nous :</span>
    <a href="#"><img src="/borabora/img/icon-1.jpg" alt="Twitter" title="Twitter"></a>
    <a href="#"><img src="/borabora/img/icon-2.jpg" alt="Facebook" title="Facebook"></a>
    <a href="#"><img src="/borabora/img/icon-3.jpg" alt="Google+" title="Google+"></a>
  </div>
</footer>	