<header> 
  <div> 
    <div>                 	
      <h1 class="text-3a"><a href="/">Le BORA<span>-BORA</span></a></h1> 
      <nav>  
        <ul class="menu">
          <li<?php echo $_SERVER['SCRIPT_NAME'] == '/index.php' ? ' class="current"' : '' ?>>
            <a href="/borabora/">Accueil</a>
          </li>
          <li<?php echo $_SERVER['SCRIPT_NAME'] == '/nos-prestations.php' ? ' class="current"' : '' ?>>
            <a href="/borabora/nos-prestations.php">Nos prestations</a>
          </li>
          <li<?php echo $_SERVER['SCRIPT_NAME'] == '/nos-tarifs.php' ? ' class="current"' : '' ?>>
            <a href="/borabora/nos-tarifs.php">Nos tarifs</a>
          </li>
          <li<?php echo $_SERVER['SCRIPT_NAME'] == '/calendrier.php' ? ' class="current"' : '' ?>>
            <a href="../borabora/calendrier.php">Calendrier</a>
          </li>
                    <li<?php echo $_SERVER['SCRIPT_NAME'] == '/calendrier.php' ? ' class="current"' : '' ?>>
            <a href="../borabora/calendrier.php">Reservation</a>
          </li>
          <li<?php echo $_SERVER['SCRIPT_NAME'] == '/contacts.php' ? ' class="current"' : '' ?>>
          <?php 
          if(isset($_SESSION['username'])) {
            $textlogin = '<a href="../connexion/logout.php">Deconnexion</a><br />';
          }
          if(!isset($_SESSION['username'])) {
            $textlogin = '<a href="../connexion/index.php">Login</a><br />';
          }
          echo $textlogin ?>
          </li>
          </li>
        </ul>
      </nav>
      <div class="clear"></div>
    </div>
  </div>
</header>
