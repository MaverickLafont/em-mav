<header> 
  <div> 
    <div>      
        
        
         <h1 class="text-3a"><a href="/">Le BORA<span>-BORA</span></a></h1>     
         <nav>      
         <ul class="menu">
         <li<?php echo $_SERVER['SCRIPT_NAME'] == '/index.php' ? ' class="current"' : '' ?>>
            <a href="/borabora/">Accueil</a>
          </li>
          <li<?php echo $_SERVER['SCRIPT_NAME'] == '/a-propos.php' ? ' class="current"' : '' ?>>
            <a href="/borabora/a-propos.php">A propos</a>
          </li>
          <li class="dropdown"<?php echo $_SERVER['SCRIPT_NAME'] == '/nos-prestations.php' ? ' class="current"' : '' ?>>
          <a href="/borabora/nos-prestations.php">Nos prestations</a>
            <ul>
              <li<?php echo $_SERVER['SCRIPT_NAME'] == '/nos-prestations.php' ? ' class="current"' : '' ?>>
               <a href="/borabora/reservation.php">Reservation</a>
              </li>
            </ul>
          </li>
          <li<?php echo $_SERVER['SCRIPT_NAME'] == '/nos-tarifs.php' ? ' class="current"' : '' ?>>
            <a href="/borabora/nos-tarifs.php">Nos tarifs</a>
          </li>
          <li<?php echo $_SERVER['SCRIPT_NAME'] == '/calendrier.php' ? ' class="current"' : '' ?>>
            <a href="../borabora/calendrier.php">Calendrier</a>
          </li>
          <li<?php echo $_SERVER['SCRIPT_NAME'] == '/contacts.php' ? ' class="current"' : '' ?>>
            <a href="../borabora/contact.php">Contacts</a>
          </li>
          <li<?php echo $_SERVER['SCRIPT_NAME'] == '/contacts.php' ? ' class="current"' : '' ?>>
            <a href="../../Appli_pointage/index.php">Login</a><br />
          </li>
        </ul>
      </nav>
      <div class="clear"></div>
    </div>
  </div>
</header>
