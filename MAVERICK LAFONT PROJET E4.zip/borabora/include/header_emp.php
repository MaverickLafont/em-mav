<header> 
  <div> 
    <div>                 	
      <h1 class="text-3a"><a href="/">Le BORA<span>-BORA</span></a></h1> 
      <nav>  
        <ul class="menu">
          <li<?php echo $_SERVER['SCRIPT_NAME'] == '/index.php' ? ' class="current"' : '' ?>>
            <a href="/borabora/">Accueil</a>
          </li>
          <li<?php echo $_SERVER['SCRIPT_NAME'] == '/nos-prestations.php' ? ' class="current"' : '' ?>>
            <a href="/borabora/nos-prestations.php">Nos prestations</a>
          </li>
          <li<?php echo $_SERVER['SCRIPT_NAME'] == '/nos-tarifs.php' ? ' class="current"' : '' ?>>
            <a href="/borabora/nos-tarifs.php">Nos tarifs</a>
          </li>
          <li<?php echo $_SERVER['SCRIPT_NAME'] == '/google_agenda' ? ' class="current"' : '' ?>>
            <a href="https://calendar.google.com/calendar/b/2/r?pli=1"  onclick="open('https://calendar.google.com/calendar/b/2/r?pli=1', 'Popup', 'scrollbars=1,resizable=1,height=560,width=770'); return false;" >Calendrier</a><br />
          </li>
          <li<?php echo $_SERVER['SCRIPT_NAME'] == '/reservation.php' ? ' class="current"' : '' ?>>
            <a href="/borabora/reservation.php">Reservation</a>
          </li>
          <li<?php echo $_SERVER['SCRIPT_NAME'] == '/deconnexion.php' ? ' class="current"' : '' ?>>
            <a href="../borabora/connexion/logout.php">Deconnexion</a>
          </li>
          </li>
        </ul>
      </nav>
      <div class="clear"></div>
    </div>
  </div>
</header>
