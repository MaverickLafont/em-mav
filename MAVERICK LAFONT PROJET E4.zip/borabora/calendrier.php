<?php 
session_start();
$racine = $_SERVER['DOCUMENT_ROOT'] ?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <title>Accueil - Le Bora-Bora</title>
   <?php 
    if(isset($_SESSION['username'])) {
      $header = include_once $racine .'/borabora/include/header_emp.php';
      }
      if(!isset($_SESSION['username'])) {
      $header = include_once $racine .'/borabora/include/header.php';
      }
  include_once $racine .'/borabora/include/head.php' ?>  
  <link rel="stylesheet" type="text/css" media="screen" href="/borabora/css/slider.css">
  <link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/themes/ui-lightness/jquery-ui.css" type="text/css" media="all" />
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js" type="text/javascript"></script>
  <script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js" type="text/javascript"></script>

  <script>
    $(document).ready(function(){				   	
      $('.slider')._TMS({
        show:0,
        pauseOnHover:true,
        prevBu:false,
        nextBu:false,
        playBu:false,
        duration:800,
        preset:'fade',
        pagination:true,
        pagNums:false,
        slideshow:7000,
        numStatus:false,
        banners:'fade',
        waitBannerAnimation:false,
        progressBar:false
      })		
    });
  </script>
</head>
<body id="demos">
  <?php echo $header; ?>
  
  <!--==============================Diaporama================================-->
  
  <iframe src="https://calendar.google.com/calendar/b/2/embed?mode=WEEK&amp;height=720&amp;wkst=2&amp;bgcolor=%23FFFFFF&amp;src=leboraborahotel%40gmail.com&amp;color=%231B887A&amp;ctz=Pacific%2FNoumea" style="border-width:0" width="1280" height="720" frameborder="0" scrolling="no"></iframe>  <!--==============================footer=================================-->
  <?php include_once $racine .'/borabora/include/footer.php' ?>
</body>
</html>