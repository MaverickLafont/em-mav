<?php $racine = $_SERVER['DOCUMENT_ROOT'] ?>
<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="utf-8"/>
  <title>Calendrier</title>
  <?php include_once $racine .'/borabora/include/head.php' ?>
  <?php include('connexion.php');?>
</head>
<body>
  <?php include_once $racine .'/borabora/include/header.php' ?>
  <?php 
	if(!empty($_POST['bouton_date_debut'])) {
          $date_debut = $_POST['date_debut'];
          header('Location: reservation.php?date='.$date_debut);

         } else {
          $date_debut= date("Y-m-d");
         }
         if(isset($_GET['date'])) {
          if(empty($_POST['bouton_date_debut'])) {
            $date_debut = $_GET['date'];
          }
         }

	 if(!empty($_POST['date_reservation'])) {
		 $date_reservation = $_POST['date_reservation'];
	 }

          setlocale(LC_TIME, 'fr_FR', 'french', 'fre', 'fra');

          $auj = $date_debut;
          $t_auj = strtotime($auj);
          $p_auj = date('N', $t_auj);
          if($p_auj == 1){
            $deb = $t_auj;
            $fin = strtotime($auj.' + 6 day');
          }
          else if($p_auj == 7){
            $deb = strtotime($auj.' - 6 day');
            $fin = $t_auj;
          }
          else{
            $deb = strtotime($auj.' - '.(6-(7-$p_auj)).' day');
            $fin = strtotime($auj.' + '.(7-$p_auj).' day');
          }
          $i = 1;
          while($deb <= $fin){
            $jour[$i] = strftime('%d %B %Y', $deb).'<br />';
            $finjoursemaine[$i] = strftime('%Y-%m-%d', $deb).'<br />';
            $deb += 86400;
            $i++;
          }

          $map = array_map(null, $finjoursemaine);
          $join = join(',', $map);
          list($finjoursemaine1, $finjoursemaine2, $finjoursemaine3, $finjoursemaine4, $finjoursemaine5, $finjoursemaine6, $finjoursemaine7) = explode(",", $join);
          $premierjour= $finjoursemaine1;$deuxiemejour=$finjoursemaine2;$troisiemejour=$finjoursemaine3;$quatriemejour=$finjoursemaine4;$cinquiemejour=$finjoursemaine5;$sixiemejour = $finjoursemaine6;$septiemejour = $finjoursemaine7;
          $clear = strip_tags($premierjour);
          $clear = html_entity_decode($clear);
          $clear = urldecode($clear);
          $clear = preg_replace('/[^A-Za-z0-9]/', ' ', $clear);
          $clear = preg_replace('/ +/', ' ', $clear);
          $clear = trim($clear);
          $test = preg_replace('/\s+/', '-', $clear);
          $date = new DateTime($test);
          $result = $date->format('Y-m-d');

          $clear1 = strip_tags($deuxiemejour);
          $clear1 = html_entity_decode($clear1);
          $clear1 = urldecode($clear1);
          $clear1 = preg_replace('/[^A-Za-z0-9]/', ' ', $clear1);
          $clear1 = preg_replace('/ +/', ' ', $clear1);
          $clear1 = trim($clear1);
          $test1 = preg_replace('/\s+/', '-', $clear1);
          $date1 = new DateTime($test1);
          $result1 = $date1->format('Y-m-d');

          $clear2 = strip_tags($troisiemejour);
          $clear2 = html_entity_decode($clear2);
          $clear2 = urldecode($clear2);
          $clear2 = preg_replace('/[^A-Za-z0-9]/', ' ', $clear2);
          $clear2 = preg_replace('/ +/', ' ', $clear2);
          $clear2 = trim($clear2);
          $test2 = preg_replace('/\s+/', '-', $clear2);
          $date2 = new DateTime($test2);
          $result2 = $date2->format('Y-m-d');

          $clear3 = strip_tags($quatriemejour);
          $clear3 = html_entity_decode($clear3);
          $clear3 = urldecode($clear3);
          $clear3 = preg_replace('/[^A-Za-z0-9]/', ' ', $clear3);
          $clear3 = preg_replace('/ +/', ' ', $clear3);
          $clear3 = trim($clear3);
          $test3 = preg_replace('/\s+/', '-', $clear3);
          $date3 = new DateTime($test3);
          $result3 = $date3->format('Y-m-d');

          $clear4 = strip_tags($cinquiemejour);
          $clear4 = html_entity_decode($clear4);
          $clear4 = urldecode($clear4);
          $clear4 = preg_replace('/[^A-Za-z0-9]/', ' ', $clear4);
          $clear4 = preg_replace('/ +/', ' ', $clear4);
          $clear4 = trim($clear4);
          $test4 = preg_replace('/\s+/', '-', $clear4);
          $date4 = new DateTime($test4);
          $result4 = $date4->format('Y-m-d');

          $clear5 = strip_tags($sixiemejour);
          $clear5 = html_entity_decode($clear5);
          $clear5 = urldecode($clear5);
          $clear5 = preg_replace('/[^A-Za-z0-9]/', ' ', $clear5);
          $clear5 = preg_replace('/ +/', ' ', $clear5);
          $clear5 = trim($clear5);
          $test5 = preg_replace('/\s+/', '-', $clear5);
          $date5 = new DateTime($test5);
          $result5 = $date5->format('Y-m-d');

          $clear6 = strip_tags($septiemejour);
          $clear6 = html_entity_decode($clear6);
          $clear6 = urldecode($clear6);
          $clear6 = preg_replace('/[^A-Za-z0-9]/', ' ', $clear6);
          $clear6 = preg_replace('/ +/', ' ', $clear6);
          $clear6 = trim($clear6);
          $test6 = preg_replace('/\s+/', '-', $clear6);
          $date6 = new DateTime($test6);
          $result6 = $date6->format('Y-m-d');
		 ?>
  <!--==============================DATE================================-->

		  <div class="card text-center">
  <div class="card-header">
   <h6> CHOISIR DATE:</h6>
  </div>
  <div class="card-body">
    <div class="date1">
  <div class="form-group row">
    <label for="example-date-input" class="col-0 col-form-label">Du</label>
    <div class="col-10">
      <form method="post" action="">
       <input class="form-control" type="date" name="date_debut" value="<?php echo $date_debut; ?>" id="example-date-input"/>
    </div>
  </div>
</div>

<div class="date2">
  <div class="form-group row">
    <label for="example-date-input" class="col-0 col-form-label">Au</label>
    <div class="col-10">
         <input class="form-control" type="date" name="date_fin" value="<?php echo $result6; ?>" id="example-date-input" readonly>
    </div>
  </div>
    </div>
  </div>

  <div class="card-footer text-muted">
<div class="boutonok">
<input type='submit' class="btn btn-outline-dark" name="bouton_date_debut" value="VALIDER DATE" />
</form>
</div>
  </div>
</div></BR>

  <!--==============================RESERVATION================================-->

		  <div class="card text-center">
  <div class="card-header">
   <h6> RESERVATION :</h6>
  </div>
  <div class="card-body">
    <div class="date1">
  <div class="form-group row">
    <label for="example-date-input" class="col-0 col-form-label">Le</label>
    <div class="col-10">
      <?php echo "<form method='post' action='ajoutreservation.php?date=$date_debut'>"; ?>
       <input class="form-control" type="date" name="date_reservation" value="<?php echo $date_debut; ?>" id="date_reservation"/>
    </div>
  </div>
</div>

<div class="date2">
  <div class="form-group row">
	<label for="example-date-input" class="col-0 col-form-label">À</label>
	<input type="time" name="heuredebut"
           min="08:00" max="20:00" required>
  </div>
	<?php 
	$req_soin = "SELECT * FROM SOIN" ;
	$res_soin = mysqli_query($cx, $req_soin) or die("Error: ".mysqli_error($cx));
	?>
	<select name="soin" id="soin">
	<?php while($row = mysqli_fetch_array($res_soin)) { ?>
		<option value="<?php echo $row['id_soin']; ?>"><?php echo $row['lib_soin']; ?></option>
	<?php	}?>
    </div>
  </div>

    <div class="card-footer text-muted">
<div class="boutonok">
<input type='submit' class="btn btn-outline-dark" name="bouton_reservation" value="VALIDER RESERVATION" />
</form>
</div>
  </div>
</div></BR>
		 
  <!--==============================content================================-->
  <section id="content">
    <div class="container_12 top">  
		<div class="table-responsive">
            <table class="table table-striped table-bordered">
			<tr>
				<th>HORAIRE</th>
				<th>LUNDI <?php echo ($jour[1]);?></th>
				<th>MARDI <?php echo ($jour[2]);?></th>
				<th>MERCREDI <?php echo ($jour[3]);?></th>
				<th>JEUDI <?php echo ($jour[4]);?></th>
				<th>VENDREDI <?php echo ($jour[5]);?></th>
				<th>SAMEDI <?php echo ($jour[6]);?></th>
				<th>DIMANCHE <?php echo ($jour[7]);?></th>
			</tr>
			<tr>
			<?php
			include ('connexion.php');
			$requet_lundi="SELECT * FROM reservation, soin WHERE soin.id_soin = reservation.id_soin AND jour_reservation='$premierjour' ;";
            $resultat_lundi=mysqli_query($cx,$requet_lundi) or die("Error: ".mysqli_error($cx));
						if(empty($resultat_lundi)){$data_lundi = null;} else { $i = 1;
						while($data_lundi = mysqli_fetch_array($resultat_lundi)){$tab_lundi[$i] = $data_lundi; $i++;}}
            
								include ('connexion.php');
			$requet_mardi="SELECT * FROM reservation, soin WHERE soin.id_soin = reservation.id_soin AND jour_reservation='$deuxiemejour';";
            $resultat_mardi=mysqli_query($cx,$requet_mardi) or die("Error: ".mysqli_error($cx));
            	if(empty($resultat_mardi)){$data_mardi = null;} else { $i = 1;
						while($data_mardi = mysqli_fetch_array($resultat_mardi)){$tab_mardi[$i] = $data_mardi; $i++;}}

								include ('connexion.php');
			$requet_mercredi="SELECT * FROM reservation, soin WHERE soin.id_soin = reservation.id_soin AND jour_reservation='$troisiemejour';";
            $resultat_mercredi=mysqli_query($cx,$requet_mercredi) or die("Error: ".mysqli_error($cx));
            if(empty($resultat_mercredi)){$data_mercredi = null;} else { $i = 1;
						while($data_mercredi = mysqli_fetch_array($resultat_mercredi)){$tab_mercredi[$i] = $data_mercredi; $i++;}}

								include ('connexion.php');
			$requet_jeudi="SELECT * FROM reservation, soin WHERE soin.id_soin = reservation.id_soin AND jour_reservation='$quatriemejour';";
            $resultat_jeudi=mysqli_query($cx,$requet_jeudi) or die("Error: ".mysqli_error($cx));
            if(empty($resultat_jeudi)){$data_jeudi = null;} else { $i = 1;
						while($data_jeudi = mysqli_fetch_array($resultat_jeudi)){$tab_jeudi[$i] = $data_jeudi; $i++;}}

								include ('connexion.php');
			$requet_vendredi="SELECT * FROM reservation, soin WHERE soin.id_soin = reservation.id_soin AND jour_reservation='$cinquiemejour';";
            $resultat_vendredi=mysqli_query($cx,$requet_vendredi) or die("Error: ".mysqli_error($cx));
           if(empty($resultat_vendredi)){$data_vendredi = null;} else { $i = 1;
						while($data_vendredi = mysqli_fetch_array($resultat_vendredi)){$tab_vendredi[$i] = $data_vendredi; $i++;}}

								include ('connexion.php');
			$requet_samedi="SELECT * FROM reservation, soin WHERE soin.id_soin = reservation.id_soin AND jour_reservation='$sixiemejour';";
            $resultat_samedi=mysqli_query($cx,$requet_samedi) or die("Error: ".mysqli_error($cx));
            if(empty($resultat_samedi)){$data_samedi = null;} else { $i = 1;
						while($data_samedi = mysqli_fetch_array($resultat_samedi)){$tab_samedi[$i] = $data_samedi; $i++;}}

								include ('connexion.php');
			$requet_dimanche="SELECT * FROM reservation, soin WHERE soin.id_soin = reservation.id_soin AND jour_reservation='$septiemejour';";
            $resultat_dimanche=mysqli_query($cx,$requet_dimanche) or die("Error: ".mysqli_error($cx));
            if(empty($resultat_dimanche)){$data_dimanche = null;} else { $i = 1;
						while($data_dimanche = mysqli_fetch_array($resultat_dimanche)){$tab_dimanche[$i] = $data_dimanche; $i++;}}

			?>
				<td id="00:08:00-00:08:30">8h00 - 8h30</td>
				<?php if(!empty($tab_lundi)){$i=1;$countTab_lundi = count($tab_lundi);while($i <= $countTab_lundi){ if($tab_lundi[$i]['heure_debut'] == "00:08:00"){echo "<td bgcolor='chocolate'>" .$tab_lundi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mardi)){$i=1;$countTab_mardi = count($tab_mardi);while($i <= $countTab_mardi){if($tab_mardi[$i]['heure_debut'] == "00:08:00"){echo "<td bgcolor='chocolate'>" .$tab_mardi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mercredi)){$i=1;$countTab_mercredi = count($tab_mercredi);while($i <= $countTab_mercredi){if($tab_mercredi[$i]['heure_debut'] == "00:08:00"){echo "<td bgcolor='chocolate'>" .$tab_mercredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_jeudi)){$i=1;$countTab_jeudi = count($tab_jeudi);while($i <= $countTab_jeudi){if($tab_jeudi[$i]['heure_debut'] == "00:08:00"){echo "<td bgcolor='chocolate'>" .$tab_jeudi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_vendredi)){$i=1;$countTab_vendredi = count($tab_vendredi);while($i <= $countTab_vendredi){if($tab_vendredi[$i]['heure_debut'] == "00:08:00"){echo "<td bgcolor='chocolate'>" .$tab_vendredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_samedi)){$i=1;$countTab_samedi = count($tab_samedi);while($i <= $countTab_samedi){if($tab_samedi[$i]['heure_debut'] == "00:08:00"){echo "<td bgcolor='chocolate'>" .$tab_samedi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_dimanche)){$i=1;$countTab_dimanche = count($tab_dimanche);while($i <= $countTab_dimanche){if($tab_dimanche[$i]['heure_debut'] == "00:08:00"){echo "<td bgcolor='chocolate'>" .$tab_dimanche[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
			</tr>
			<tr>
				<td id="00:08:30-00:09:00">8h30 - 9h00</td>
				<?php if(!empty($tab_lundi)){$i=1;$countTab_lundi = count($tab_lundi);while($i <= $countTab_lundi){if($tab_lundi[$i]['heure_debut'] == "00:08:30"){echo "<td bgcolor='chocolate'>" .$tab_lundi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mardi)){$i=1;$countTab_mardi = count($tab_mardi);while($i <= $countTab_mardi){if($tab_mardi[$i]['heure_debut'] == "00:08:30"){echo "<td bgcolor='chocolate'>" .$tab_mardi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mercredi)){$i=1;$countTab_mercredi = count($tab_mercredi);while($i <= $countTab_mercredi){if($tab_mercredi[$i]['heure_debut'] == "00:08:30"){echo "<td bgcolor='chocolate'>" .$tab_mercredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_jeudi)){$i=1;$countTab_jeudi = count($tab_jeudi);while($i <= $countTab_jeudi){if($tab_jeudi[$i]['heure_debut'] == "00:08:30"){echo "<td bgcolor='chocolate'>" .$tab_jeudi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_vendredi)){$i=1;$countTab_vendredi = count($tab_vendredi);while($i <= $countTab_vendredi){if($tab_vendredi[$i]['heure_debut'] == "00:08:30"){echo "<td bgcolor='chocolate'>" .$tab_vendredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_samedi)){$i=1;$countTab_samedi = count($tab_samedi);while($i <= $countTab_samedi){if($tab_samedi[$i]['heure_debut'] == "00:08:30"){echo "<td bgcolor='chocolate'>" .$tab_samedi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_dimanche)){$i=1;$countTab_dimanche = count($tab_dimanche);while($i <= $countTab_dimanche){if($tab_dimanche[$i]['heure_debut'] == "00:08:30"){echo "<td bgcolor='chocolate'>" .$tab_dimanche[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
			</tr>
			<tr>
				<td id="00:09:00-00:09:30">9h00 - 9h30</td>
				<?php if(!empty($tab_lundi)){$i=1;$countTab_lundi = count($tab_lundi);while($i <= $countTab_lundi){ if($tab_lundi[$i]['heure_debut'] == "00:09:00"){echo "<td bgcolor='chocolate'>" .$tab_lundi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mardi)){$i=1;$countTab_mardi = count($tab_mardi);while($i <= $countTab_mardi){if($tab_mardi[$i]['heure_debut'] == "00:09:00"){echo "<td bgcolor='chocolate'>" .$tab_mardi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mercredi)){$i=1;$countTab_mercredi = count($tab_mercredi);while($i <= $countTab_mercredi){if($tab_mercredi[$i]['heure_debut'] == "00:09:00"){echo "<td bgcolor='chocolate'>" .$tab_mercredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_jeudi)){$i=1;$countTab_jeudi = count($tab_jeudi);while($i <= $countTab_jeudi){if($tab_jeudi[$i]['heure_debut'] == "00:09:00"){echo "<td bgcolor='chocolate'>" .$tab_jeudi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_vendredi)){$i=1;$countTab_vendredi = count($tab_vendredi);while($i <= $countTab_vendredi){if($tab_vendredi[$i]['heure_debut'] == "00:09:00"){echo "<td bgcolor='chocolate'>" .$tab_vendredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_samedi)){$i=1;$countTab_samedi = count($tab_samedi);while($i <= $countTab_samedi){if($tab_samedi[$i]['heure_debut'] == "00:09:00"){echo "<td bgcolor='chocolate'>" .$tab_samedi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_dimanche)){$i=1;$countTab_dimanche = count($tab_dimanche);while($i <= $countTab_dimanche){if($tab_dimanche[$i]['heure_debut'] == "00:09:00"){echo "<td bgcolor='chocolate'>" .$tab_dimanche[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
			</tr>
			<tr>
				<td id="00:09:30-00:10:00">9h30 - 10h00</td>
				<?php if(!empty($tab_lundi)){$i=1;$countTab_lundi = count($tab_lundi);while($i <= $countTab_lundi){ if($tab_lundi[$i]['heure_debut'] == "00:09:30"){echo "<td bgcolor='chocolate'>" .$tab_lundi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mardi)){$i=1;$countTab_mardi = count($tab_mardi);while($i <= $countTab_mardi){if($tab_mardi[$i]['heure_debut'] == "00:09:30"){echo "<td bgcolor='chocolate'>" .$tab_mardi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mercredi)){$i=1;$countTab_mercredi = count($tab_mercredi);while($i <= $countTab_mercredi){if($tab_mercredi[$i]['heure_debut'] == "00:09:30"){echo "<td bgcolor='chocolate'>" .$tab_mercredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_jeudi)){$i=1;$countTab_jeudi = count($tab_jeudi);while($i <= $countTab_jeudi){if($tab_jeudi[$i]['heure_debut'] == "00:09:30"){echo "<td bgcolor='chocolate'>" .$tab_jeudi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_vendredi)){$i=1;$countTab_vendredi = count($tab_vendredi);while($i <= $countTab_vendredi){if($tab_vendredi[$i]['heure_debut'] == "00:09:30"){echo "<td bgcolor='chocolate'>" .$tab_vendredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_samedi)){$i=1;$countTab_samedi = count($tab_samedi);while($i <= $countTab_samedi){if($tab_samedi[$i]['heure_debut'] == "00:09:30"){echo "<td bgcolor='chocolate'>" .$tab_samedi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_dimanche)){$i=1;$countTab_dimanche = count($tab_dimanche);while($i <= $countTab_dimanche){if($tab_dimanche[$i]['heure_debut'] == "00:09:30"){echo "<td bgcolor='chocolate'>" .$tab_dimanche[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
			</tr>
			<tr>
				<td id="00:10:00-00:10:30">10h00 - 10h30</td>
				<?php if(!empty($tab_lundi)){$i=1;$countTab_lundi = count($tab_lundi);while($i <= $countTab_lundi){ if($tab_lundi[$i]['heure_debut'] == "00:10:00"){echo "<td bgcolor='chocolate'>" .$tab_lundi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mardi)){$i=1;$countTab_mardi = count($tab_mardi);while($i <= $countTab_mardi){if($tab_mardi[$i]['heure_debut'] == "00:10:00"){echo "<td bgcolor='chocolate'>" .$tab_mardi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mercredi)){$i=1;$countTab_mercredi = count($tab_mercredi);while($i <= $countTab_mercredi){if($tab_mercredi[$i]['heure_debut'] == "00:10:00"){echo "<td bgcolor='chocolate'>" .$tab_mercredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_jeudi)){$i=1;$countTab_jeudi = count($tab_jeudi);while($i <= $countTab_jeudi){if($tab_jeudi[$i]['heure_debut'] == "00:10:00"){echo "<td bgcolor='chocolate'>" .$tab_jeudi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_vendredi)){$i=1;$countTab_vendredi = count($tab_vendredi);while($i <= $countTab_vendredi){if($tab_vendredi[$i]['heure_debut'] == "00:10:00"){echo "<td bgcolor='chocolate'>" .$tab_vendredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_samedi)){$i=1;$countTab_samedi = count($tab_samedi);while($i <= $countTab_samedi){if($tab_samedi[$i]['heure_debut'] == "00:10:00"){echo "<td bgcolor='chocolate'>" .$tab_samedi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_dimanche)){$i=1;$countTab_dimanche = count($tab_dimanche);while($i <= $countTab_dimanche){if($tab_dimanche[$i]['heure_debut'] == "00:10:00"){echo "<td bgcolor='chocolate'>" .$tab_dimanche[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
			</tr>
			<tr>
				<td>10h30 - 11h00</td>
				<?php if(!empty($tab_lundi)){$i=1;$countTab_lundi = count($tab_lundi);while($i <= $countTab_lundi){ if($tab_lundi[$i]['heure_debut'] == "00:10:30"){echo "<td bgcolor='chocolate'>" .$tab_lundi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mardi)){$i=1;$countTab_mardi = count($tab_mardi);while($i <= $countTab_mardi){if($tab_mardi[$i]['heure_debut'] == "00:10:30"){echo "<td bgcolor='chocolate'>" .$tab_mardi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mercredi)){$i=1;$countTab_mercredi = count($tab_mercredi);while($i <= $countTab_mercredi){if($tab_mercredi[$i]['heure_debut'] == "00:10:30"){echo "<td bgcolor='chocolate'>" .$tab_mercredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_jeudi)){$i=1;$countTab_jeudi = count($tab_jeudi);while($i <= $countTab_jeudi){if($tab_jeudi[$i]['heure_debut'] == "00:10:30"){echo "<td bgcolor='chocolate'>" .$tab_jeudi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_vendredi)){$i=1;$countTab_vendredi = count($tab_vendredi);while($i <= $countTab_vendredi){if($tab_vendredi[$i]['heure_debut'] == "00:10:30"){echo "<td bgcolor='chocolate'>" .$tab_vendredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_samedi)){$i=1;$countTab_samedi = count($tab_samedi);while($i <= $countTab_samedi){if($tab_samedi[$i]['heure_debut'] == "00:10:30"){echo "<td bgcolor='chocolate'>" .$tab_samedi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_dimanche)){$i=1;$countTab_dimanche = count($tab_dimanche);while($i <= $countTab_dimanche){if($tab_dimanche[$i]['heure_debut'] == "00:10:30"){echo "<td bgcolor='chocolate'>" .$tab_dimanche[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
			</tr>
			<tr>
				<td>11h00 - 11h30</td>
				<?php if(!empty($tab_lundi)){$i=1;$countTab_lundi = count($tab_lundi);while($i <= $countTab_lundi){ if($tab_lundi[$i]['heure_debut'] == "00:11:00"){echo "<td bgcolor='chocolate'>" .$tab_lundi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mardi)){$i=1;$countTab_mardi = count($tab_mardi);while($i <= $countTab_mardi){if($tab_mardi[$i]['heure_debut'] == "00:11:00"){echo "<td bgcolor='chocolate'>" .$tab_mardi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mercredi)){$i=1;$countTab_mercredi = count($tab_mercredi);while($i <= $countTab_mercredi){if($tab_mercredi[$i]['heure_debut'] == "00:11:00"){echo "<td bgcolor='chocolate'>" .$tab_mercredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_jeudi)){$i=1;$countTab_jeudi = count($tab_jeudi);while($i <= $countTab_jeudi){if($tab_jeudi[$i]['heure_debut'] == "00:11:00"){echo "<td bgcolor='chocolate'>" .$tab_jeudi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_vendredi)){$i=1;$countTab_vendredi = count($tab_vendredi);while($i <= $countTab_vendredi){if($tab_vendredi[$i]['heure_debut'] == "00:11:00"){echo "<td bgcolor='chocolate'>" .$tab_vendredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_samedi)){$i=1;$countTab_samedi = count($tab_samedi);while($i <= $countTab_samedi){if($tab_samedi[$i]['heure_debut'] == "00:11:00"){echo "<td bgcolor='chocolate'>" .$tab_samedi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_dimanche)){$i=1;$countTab_dimanche = count($tab_dimanche);while($i <= $countTab_dimanche){if($tab_dimanche[$i]['heure_debut'] == "00:11:00"){echo "<td bgcolor='chocolate'>" .$tab_dimanche[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
			</tr>
			<tr>
				<td>11h30 - 12h00</td>
				<?php if(!empty($tab_lundi)){$i=1;$countTab_lundi = count($tab_lundi);while($i <= $countTab_lundi){ if($tab_lundi[$i]['heure_debut'] == "00:11:30"){echo "<td bgcolor='chocolate'>" .$tab_lundi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mardi)){$i=1;$countTab_mardi = count($tab_mardi);while($i <= $countTab_mardi){if($tab_mardi[$i]['heure_debut'] == "00:11:30"){echo "<td bgcolor='chocolate'>" .$tab_mardi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mercredi)){$i=1;$countTab_mercredi = count($tab_mercredi);while($i <= $countTab_mercredi){if($tab_mercredi[$i]['heure_debut'] == "00:11:30"){echo "<td bgcolor='chocolate'>" .$tab_mercredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_jeudi)){$i=1;$countTab_jeudi = count($tab_jeudi);while($i <= $countTab_jeudi){if($tab_jeudi[$i]['heure_debut'] == "00:11:30"){echo "<td bgcolor='chocolate'>" .$tab_jeudi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_vendredi)){$i=1;$countTab_vendredi = count($tab_vendredi);while($i <= $countTab_vendredi){if($tab_vendredi[$i]['heure_debut'] == "00:11:30"){echo "<td bgcolor='chocolate'>" .$tab_vendredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_samedi)){$i=1;$countTab_samedi = count($tab_samedi);while($i <= $countTab_samedi){if($tab_samedi[$i]['heure_debut'] == "00:11:30"){echo "<td bgcolor='chocolate'>" .$tab_samedi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_dimanche)){$i=1;$countTab_dimanche = count($tab_dimanche);while($i <= $countTab_dimanche){if($tab_dimanche[$i]['heure_debut'] == "00:11:30"){echo "<td bgcolor='chocolate'>" .$tab_dimanche[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
			</tr>
			<tr>
				<td>12h00 - 12h30</td>
				<?php if(!empty($tab_lundi)){$i=1;$countTab_lundi = count($tab_lundi);while($i <= $countTab_lundi){ if($tab_lundi[$i]['heure_debut'] == "00:12:00"){echo "<td bgcolor='chocolate'>" .$tab_lundi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mardi)){$i=1;$countTab_mardi = count($tab_mardi);while($i <= $countTab_mardi){if($tab_mardi[$i]['heure_debut'] == "00:12:00"){echo "<td bgcolor='chocolate'>" .$tab_mardi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mercredi)){$i=1;$countTab_mercredi = count($tab_mercredi);while($i <= $countTab_mercredi){if($tab_mercredi[$i]['heure_debut'] == "00:12:00"){echo "<td bgcolor='chocolate'>" .$tab_mercredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_jeudi)){$i=1;$countTab_jeudi = count($tab_jeudi);while($i <= $countTab_jeudi){if($tab_jeudi[$i]['heure_debut'] == "00:12:00"){echo "<td bgcolor='chocolate'>" .$tab_jeudi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_vendredi)){$i=1;$countTab_vendredi = count($tab_vendredi);while($i <= $countTab_vendredi){if($tab_vendredi[$i]['heure_debut'] == "00:12:00"){echo "<td bgcolor='chocolate'>" .$tab_vendredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_samedi)){$i=1;$countTab_samedi = count($tab_samedi);while($i <= $countTab_samedi){if($tab_samedi[$i]['heure_debut'] == "00:12:00"){echo "<td bgcolor='chocolate'>" .$tab_samedi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_dimanche)){$i=1;$countTab_dimanche = count($tab_dimanche);while($i <= $countTab_dimanche){if($tab_dimanche[$i]['heure_debut'] == "00:12:00"){echo "<td bgcolor='chocolate'>" .$tab_dimanche[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
			</tr>
			<tr>
				<td>12h30 - 13h00</td>
				<?php if(!empty($tab_lundi)){$i=1;$countTab_lundi = count($tab_lundi);while($i <= $countTab_lundi){ if($tab_lundi[$i]['heure_debut'] == "00:12:30"){echo "<td bgcolor='chocolate'>" .$tab_lundi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mardi)){$i=1;$countTab_mardi = count($tab_mardi);while($i <= $countTab_mardi){if($tab_mardi[$i]['heure_debut'] == "00:12:30"){echo "<td bgcolor='chocolate'>" .$tab_mardi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mercredi)){$i=1;$countTab_mercredi = count($tab_mercredi);while($i <= $countTab_mercredi){if($tab_mercredi[$i]['heure_debut'] == "00:12:30"){echo "<td bgcolor='chocolate'>" .$tab_mercredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_jeudi)){$i=1;$countTab_jeudi = count($tab_jeudi);while($i <= $countTab_jeudi){if($tab_jeudi[$i]['heure_debut'] == "00:12:30"){echo "<td bgcolor='chocolate'>" .$tab_jeudi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_vendredi)){$i=1;$countTab_vendredi = count($tab_vendredi);while($i <= $countTab_vendredi){if($tab_vendredi[$i]['heure_debut'] == "00:12:30"){echo "<td bgcolor='chocolate'>" .$tab_vendredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_samedi)){$i=1;$countTab_samedi = count($tab_samedi);while($i <= $countTab_samedi){if($tab_samedi[$i]['heure_debut'] == "00:12:30"){echo "<td bgcolor='chocolate'>" .$tab_samedi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_dimanche)){$i=1;$countTab_dimanche = count($tab_dimanche);while($i <= $countTab_dimanche){if($tab_dimanche[$i]['heure_debut'] == "00:12:30"){echo "<td bgcolor='chocolate'>" .$tab_dimanche[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
			</tr>
			<tr>
				<td>13h00 - 13h30</td>
				<?php if(!empty($tab_lundi)){$i=1;$countTab_lundi = count($tab_lundi);while($i <= $countTab_lundi){ if($tab_lundi[$i]['heure_debut'] == "00:13:00"){echo "<td bgcolor='chocolate'>" .$tab_lundi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mardi)){$i=1;$countTab_mardi = count($tab_mardi);while($i <= $countTab_mardi){if($tab_mardi[$i]['heure_debut'] == "00:13:00"){echo "<td bgcolor='chocolate'>" .$tab_mardi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mercredi)){$i=1;$countTab_mercredi = count($tab_mercredi);while($i <= $countTab_mercredi){if($tab_mercredi[$i]['heure_debut'] == "00:13:00"){echo "<td bgcolor='chocolate'>" .$tab_mercredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_jeudi)){$i=1;$countTab_jeudi = count($tab_jeudi);while($i <= $countTab_jeudi){if($tab_jeudi[$i]['heure_debut'] == "00:13:00"){echo "<td bgcolor='chocolate'>" .$tab_jeudi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_vendredi)){$i=1;$countTab_vendredi = count($tab_vendredi);while($i <= $countTab_vendredi){if($tab_vendredi[$i]['heure_debut'] == "00:13:00"){echo "<td bgcolor='chocolate'>" .$tab_vendredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_samedi)){$i=1;$countTab_samedi = count($tab_samedi);while($i <= $countTab_samedi){if($tab_samedi[$i]['heure_debut'] == "00:13:00"){echo "<td bgcolor='chocolate'>" .$tab_samedi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_dimanche)){$i=1;$countTab_dimanche = count($tab_dimanche);while($i <= $countTab_dimanche){if($tab_dimanche[$i]['heure_debut'] == "00:13:00"){echo "<td bgcolor='chocolate'>" .$tab_dimanche[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
			</tr>
			<tr>
				<td>13h30 - 14h00</td>
				<?php if(!empty($tab_lundi)){$i=1;$countTab_lundi = count($tab_lundi);while($i <= $countTab_lundi){ if($tab_lundi[$i]['heure_debut'] == "00:13:30"){echo "<td bgcolor='chocolate'>" .$tab_lundi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mardi)){$i=1;$countTab_mardi = count($tab_mardi);while($i <= $countTab_mardi){if($tab_mardi[$i]['heure_debut'] == "00:13:30"){echo "<td bgcolor='chocolate'>" .$tab_mardi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mercredi)){$i=1;$countTab_mercredi = count($tab_mercredi);while($i <= $countTab_mercredi){if($tab_mercredi[$i]['heure_debut'] == "00:13:30"){echo "<td bgcolor='chocolate'>" .$tab_mercredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_jeudi)){$i=1;$countTab_jeudi = count($tab_jeudi);while($i <= $countTab_jeudi){if($tab_jeudi[$i]['heure_debut'] == "00:13:30"){echo "<td bgcolor='chocolate'>" .$tab_jeudi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_vendredi)){$i=1;$countTab_vendredi = count($tab_vendredi);while($i <= $countTab_vendredi){if($tab_vendredi[$i]['heure_debut'] == "00:13:30"){echo "<td bgcolor='chocolate'>" .$tab_vendredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_samedi)){$i=1;$countTab_samedi = count($tab_samedi);while($i <= $countTab_samedi){if($tab_samedi[$i]['heure_debut'] == "00:13:30"){echo "<td bgcolor='chocolate'>" .$tab_samedi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_dimanche)){$i=1;$countTab_dimanche = count($tab_dimanche);while($i <= $countTab_dimanche){if($tab_dimanche[$i]['heure_debut'] == "00:13:30"){echo "<td bgcolor='chocolate'>" .$tab_dimanche[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
			</tr>
			<tr>
				<td>14h00 - 14h30</td>
				<?php if(!empty($tab_lundi)){$i=1;$countTab_lundi = count($tab_lundi);while($i <= $countTab_lundi){ if($tab_lundi[$i]['heure_debut'] == "00:14:00"){echo "<td bgcolor='chocolate'>" .$tab_lundi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mardi)){$i=1;$countTab_mardi = count($tab_mardi);while($i <= $countTab_mardi){if($tab_mardi[$i]['heure_debut'] == "00:14:00"){echo "<td bgcolor='chocolate'>" .$tab_mardi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mercredi)){$i=1;$countTab_mercredi = count($tab_mercredi);while($i <= $countTab_mercredi){if($tab_mercredi[$i]['heure_debut'] == "00:14:00"){echo "<td bgcolor='chocolate'>" .$tab_mercredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_jeudi)){$i=1;$countTab_jeudi = count($tab_jeudi);while($i <= $countTab_jeudi){if($tab_jeudi[$i]['heure_debut'] == "00:14:00"){echo "<td bgcolor='chocolate'>" .$tab_jeudi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_vendredi)){$i=1;$countTab_vendredi = count($tab_vendredi);while($i <= $countTab_vendredi){if($tab_vendredi[$i]['heure_debut'] == "00:14:00"){echo "<td bgcolor='chocolate'>" .$tab_vendredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_samedi)){$i=1;$countTab_samedi = count($tab_samedi);while($i <= $countTab_samedi){if($tab_samedi[$i]['heure_debut'] == "00:14:00"){echo "<td bgcolor='chocolate'>" .$tab_samedi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_dimanche)){$i=1;$countTab_dimanche = count($tab_dimanche);while($i <= $countTab_dimanche){if($tab_dimanche[$i]['heure_debut'] == "00:14:00"){echo "<td bgcolor='chocolate'>" .$tab_dimanche[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
			</tr>
			<tr>
				<td>14h30 - 15h00</td>
				<?php if(!empty($tab_lundi)){$i=1;$countTab_lundi = count($tab_lundi);while($i <= $countTab_lundi){ if($tab_lundi[$i]['heure_debut'] == "00:14:30"){echo "<td bgcolor='chocolate'>" .$tab_lundi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mardi)){$i=1;$countTab_mardi = count($tab_mardi);while($i <= $countTab_mardi){if($tab_mardi[$i]['heure_debut'] == "00:14:30"){echo "<td bgcolor='chocolate'>" .$tab_mardi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mercredi)){$i=1;$countTab_mercredi = count($tab_mercredi);while($i <= $countTab_mercredi){if($tab_mercredi[$i]['heure_debut'] == "00:14:30"){echo "<td bgcolor='chocolate'>" .$tab_mercredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_jeudi)){$i=1;$countTab_jeudi = count($tab_jeudi);while($i <= $countTab_jeudi){if($tab_jeudi[$i]['heure_debut'] == "00:14:30"){echo "<td bgcolor='chocolate'>" .$tab_jeudi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_vendredi)){$i=1;$countTab_vendredi = count($tab_vendredi);while($i <= $countTab_vendredi){if($tab_vendredi[$i]['heure_debut'] == "00:14:30"){echo "<td bgcolor='chocolate'>" .$tab_vendredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_samedi)){$i=1;$countTab_samedi = count($tab_samedi);while($i <= $countTab_samedi){if($tab_samedi[$i]['heure_debut'] == "00:14:30"){echo "<td bgcolor='chocolate'>" .$tab_samedi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_dimanche)){$i=1;$countTab_dimanche = count($tab_dimanche);while($i <= $countTab_dimanche){if($tab_dimanche[$i]['heure_debut'] == "00:14:30"){echo "<td bgcolor='chocolate'>" .$tab_dimanche[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
			</tr>
			<tr>
				<td>15h00 - 15h30</td>
				<?php if(!empty($tab_lundi)){$i=1;$countTab_lundi = count($tab_lundi);while($i <= $countTab_lundi){ if($tab_lundi[$i]['heure_debut'] == "00:15:00"){echo "<td bgcolor='chocolate'>" .$tab_lundi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mardi)){$i=1;$countTab_mardi = count($tab_mardi);while($i <= $countTab_mardi){if($tab_mardi[$i]['heure_debut'] == "00:15:00"){echo "<td bgcolor='chocolate'>" .$tab_mardi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mercredi)){$i=1;$countTab_mercredi = count($tab_mercredi);while($i <= $countTab_mercredi){if($tab_mercredi[$i]['heure_debut'] == "00:15:00"){echo "<td bgcolor='chocolate'>" .$tab_mercredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_jeudi)){$i=1;$countTab_jeudi = count($tab_jeudi);while($i <= $countTab_jeudi){if($tab_jeudi[$i]['heure_debut'] == "00:15:00"){echo "<td bgcolor='chocolate'>" .$tab_jeudi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_vendredi)){$i=1;$countTab_vendredi = count($tab_vendredi);while($i <= $countTab_vendredi){if($tab_vendredi[$i]['heure_debut'] == "00:15:00"){echo "<td bgcolor='chocolate'>" .$tab_vendredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_samedi)){$i=1;$countTab_samedi = count($tab_samedi);while($i <= $countTab_samedi){if($tab_samedi[$i]['heure_debut'] == "00:15:00"){echo "<td bgcolor='chocolate'>" .$tab_samedi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_dimanche)){$i=1;$countTab_dimanche = count($tab_dimanche);while($i <= $countTab_dimanche){if($tab_dimanche[$i]['heure_debut'] == "00:15:00"){echo "<td bgcolor='chocolate'>" .$tab_dimanche[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
			</tr>
			<tr>
				<td>15h30 - 16h00</td>
				<?php if(!empty($tab_lundi)){$i=1;$countTab_lundi = count($tab_lundi);while($i <= $countTab_lundi){ if($tab_lundi[$i]['heure_debut'] == "00:15:30"){echo "<td bgcolor='chocolate'>" .$tab_lundi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mardi)){$i=1;$countTab_mardi = count($tab_mardi);while($i <= $countTab_mardi){if($tab_mardi[$i]['heure_debut'] == "00:15:30"){echo "<td bgcolor='chocolate'>" .$tab_mardi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mercredi)){$i=1;$countTab_mercredi = count($tab_mercredi);while($i <= $countTab_mercredi){if($tab_mercredi[$i]['heure_debut'] == "00:15:30"){echo "<td bgcolor='chocolate'>" .$tab_mercredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_jeudi)){$i=1;$countTab_jeudi = count($tab_jeudi);while($i <= $countTab_jeudi){if($tab_jeudi[$i]['heure_debut'] == "00:15:30"){echo "<td bgcolor='chocolate'>" .$tab_jeudi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_vendredi)){$i=1;$countTab_vendredi = count($tab_vendredi);while($i <= $countTab_vendredi){if($tab_vendredi[$i]['heure_debut'] == "00:15:30"){echo "<td bgcolor='chocolate'>" .$tab_vendredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_samedi)){$i=1;$countTab_samedi = count($tab_samedi);while($i <= $countTab_samedi){if($tab_samedi[$i]['heure_debut'] == "00:15:30"){echo "<td bgcolor='chocolate'>" .$tab_samedi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_dimanche)){$i=1;$countTab_dimanche = count($tab_dimanche);while($i <= $countTab_dimanche){if($tab_dimanche[$i]['heure_debut'] == "00:15:30"){echo "<td bgcolor='chocolate'>" .$tab_dimanche[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
			</tr>
			<tr>
				<td>16h00 - 16h30</td>
				<?php if(!empty($tab_lundi)){$i=1;$countTab_lundi = count($tab_lundi);while($i <= $countTab_lundi){ if($tab_lundi[$i]['heure_debut'] == "00:16:00"){echo "<td bgcolor='chocolate'>" .$tab_lundi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mardi)){$i=1;$countTab_mardi = count($tab_mardi);while($i <= $countTab_mardi){if($tab_mardi[$i]['heure_debut'] == "00:16:00"){echo "<td bgcolor='chocolate'>" .$tab_mardi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mercredi)){$i=1;$countTab_mercredi = count($tab_mercredi);while($i <= $countTab_mercredi){if($tab_mercredi[$i]['heure_debut'] == "00:16:00"){echo "<td bgcolor='chocolate'>" .$tab_mercredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_jeudi)){$i=1;$countTab_jeudi = count($tab_jeudi);while($i <= $countTab_jeudi){if($tab_jeudi[$i]['heure_debut'] == "00:16:00"){echo "<td bgcolor='chocolate'>" .$tab_jeudi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_vendredi)){$i=1;$countTab_vendredi = count($tab_vendredi);while($i <= $countTab_vendredi){if($tab_vendredi[$i]['heure_debut'] == "00:16:00"){echo "<td bgcolor='chocolate'>" .$tab_vendredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_samedi)){$i=1;$countTab_samedi = count($tab_samedi);while($i <= $countTab_samedi){if($tab_samedi[$i]['heure_debut'] == "00:16:00"){echo "<td bgcolor='chocolate'>" .$tab_samedi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_dimanche)){$i=1;$countTab_dimanche = count($tab_dimanche);while($i <= $countTab_dimanche){if($tab_dimanche[$i]['heure_debut'] == "00:16:00"){echo "<td bgcolor='chocolate'>" .$tab_dimanche[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
			</tr>
			<tr>
				<td>16h30 - 17h00</td>
				<?php if(!empty($tab_lundi)){$i=1;$countTab_lundi = count($tab_lundi);while($i <= $countTab_lundi){ if($tab_lundi[$i]['heure_debut'] == "00:16:30"){echo "<td bgcolor='chocolate'>" .$tab_lundi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mardi)){$i=1;$countTab_mardi = count($tab_mardi);while($i <= $countTab_mardi){if($tab_mardi[$i]['heure_debut'] == "00:16:30"){echo "<td bgcolor='chocolate'>" .$tab_mardi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mercredi)){$i=1;$countTab_mercredi = count($tab_mercredi);while($i <= $countTab_mercredi){if($tab_mercredi[$i]['heure_debut'] == "00:16:30"){echo "<td bgcolor='chocolate'>" .$tab_mercredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_jeudi)){$i=1;$countTab_jeudi = count($tab_jeudi);while($i <= $countTab_jeudi){if($tab_jeudi[$i]['heure_debut'] == "00:16:30"){echo "<td bgcolor='chocolate'>" .$tab_jeudi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_vendredi)){$i=1;$countTab_vendredi = count($tab_vendredi);while($i <= $countTab_vendredi){if($tab_vendredi[$i]['heure_debut'] == "00:16:30"){echo "<td bgcolor='chocolate'>" .$tab_vendredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_samedi)){$i=1;$countTab_samedi = count($tab_samedi);while($i <= $countTab_samedi){if($tab_samedi[$i]['heure_debut'] == "00:16:30"){echo "<td bgcolor='chocolate'>" .$tab_samedi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_dimanche)){$i=1;$countTab_dimanche = count($tab_dimanche);while($i <= $countTab_dimanche){if($tab_dimanche[$i]['heure_debut'] == "00:16:30"){echo "<td bgcolor='chocolate'>" .$tab_dimanche[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
			</tr>
			<tr>
				<td>17h00 - 17h30</td>
				<?php if(!empty($tab_lundi)){$i=1;$countTab_lundi = count($tab_lundi);while($i <= $countTab_lundi){ if($tab_lundi[$i]['heure_debut'] == "00:17:00"){echo "<td bgcolor='chocolate'>" .$tab_lundi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mardi)){$i=1;$countTab_mardi = count($tab_mardi);while($i <= $countTab_mardi){if($tab_mardi[$i]['heure_debut'] == "00:17:00"){echo "<td bgcolor='chocolate'>" .$tab_mardi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mercredi)){$i=1;$countTab_mercredi = count($tab_mercredi);while($i <= $countTab_mercredi){if($tab_mercredi[$i]['heure_debut'] == "00:17:00"){echo "<td bgcolor='chocolate'>" .$tab_mercredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_jeudi)){$i=1;$countTab_jeudi = count($tab_jeudi);while($i <= $countTab_jeudi){if($tab_jeudi[$i]['heure_debut'] == "00:17:00"){echo "<td bgcolor='chocolate'>" .$tab_jeudi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_vendredi)){$i=1;$countTab_vendredi = count($tab_vendredi);while($i <= $countTab_vendredi){if($tab_vendredi[$i]['heure_debut'] == "00:17:00"){echo "<td bgcolor='chocolate'>" .$tab_vendredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_samedi)){$i=1;$countTab_samedi = count($tab_samedi);while($i <= $countTab_samedi){if($tab_samedi[$i]['heure_debut'] == "00:17:00"){echo "<td bgcolor='chocolate'>" .$tab_samedi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_dimanche)){$i=1;$countTab_dimanche = count($tab_dimanche);while($i <= $countTab_dimanche){if($tab_dimanche[$i]['heure_debut'] == "00:17:00"){echo "<td bgcolor='chocolate'>" .$tab_dimanche[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
			</tr>
			<tr>
				<td>17h30 - 18h00</td>
				<?php if(!empty($tab_lundi)){$i=1;$countTab_lundi = count($tab_lundi);while($i <= $countTab_lundi){ if($tab_lundi[$i]['heure_debut'] == "00:17:30"){echo "<td bgcolor='chocolate'>" .$tab_lundi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mardi)){$i=1;$countTab_mardi = count($tab_mardi);while($i <= $countTab_mardi){if($tab_mardi[$i]['heure_debut'] == "00:17:30"){echo "<td bgcolor='chocolate'>" .$tab_mardi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mercredi)){$i=1;$countTab_mercredi = count($tab_mercredi);while($i <= $countTab_mercredi){if($tab_mercredi[$i]['heure_debut'] == "00:17:30"){echo "<td bgcolor='chocolate'>" .$tab_mercredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_jeudi)){$i=1;$countTab_jeudi = count($tab_jeudi);while($i <= $countTab_jeudi){if($tab_jeudi[$i]['heure_debut'] == "00:17:30"){echo "<td bgcolor='chocolate'>" .$tab_jeudi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_vendredi)){$i=1;$countTab_vendredi = count($tab_vendredi);while($i <= $countTab_vendredi){if($tab_vendredi[$i]['heure_debut'] == "00:17:30"){echo "<td bgcolor='chocolate'>" .$tab_vendredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_samedi)){$i=1;$countTab_samedi = count($tab_samedi);while($i <= $countTab_samedi){if($tab_samedi[$i]['heure_debut'] == "00:17:30"){echo "<td bgcolor='chocolate'>" .$tab_samedi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_dimanche)){$i=1;$countTab_dimanche = count($tab_dimanche);while($i <= $countTab_dimanche){if($tab_dimanche[$i]['heure_debut'] == "00:17:30"){echo "<td bgcolor='chocolate'>" .$tab_dimanche[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
			</tr>
			<tr>
				<td>18h00 - 18h30</td>
				<?php if(!empty($tab_lundi)){$i=1;$countTab_lundi = count($tab_lundi);while($i <= $countTab_lundi){ if($tab_lundi[$i]['heure_debut'] == "00:18:00"){echo "<td bgcolor='chocolate'>" .$tab_lundi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mardi)){$i=1;$countTab_mardi = count($tab_mardi);while($i <= $countTab_mardi){if($tab_mardi[$i]['heure_debut'] == "00:18:00"){echo "<td bgcolor='chocolate'>" .$tab_mardi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mercredi)){$i=1;$countTab_mercredi = count($tab_mercredi);while($i <= $countTab_mercredi){if($tab_mercredi[$i]['heure_debut'] == "00:18:00"){echo "<td bgcolor='chocolate'>" .$tab_mercredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_jeudi)){$i=1;$countTab_jeudi = count($tab_jeudi);while($i <= $countTab_jeudi){if($tab_jeudi[$i]['heure_debut'] == "00:18:00"){echo "<td bgcolor='chocolate'>" .$tab_jeudi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_vendredi)){$i=1;$countTab_vendredi = count($tab_vendredi);while($i <= $countTab_vendredi){if($tab_vendredi[$i]['heure_debut'] == "00:18:00"){echo "<td bgcolor='chocolate'>" .$tab_vendredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_samedi)){$i=1;$countTab_samedi = count($tab_samedi);while($i <= $countTab_samedi){if($tab_samedi[$i]['heure_debut'] == "00:18:00"){echo "<td bgcolor='chocolate'>" .$tab_samedi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_dimanche)){$i=1;$countTab_dimanche = count($tab_dimanche);while($i <= $countTab_dimanche){if($tab_dimanche[$i]['heure_debut'] == "00:18:00"){echo "<td bgcolor='chocolate'>" .$tab_dimanche[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
			</tr>
			<tr>
				<td>18h30 - 19h00</td>
				<?php if(!empty($tab_lundi)){$i=1;$countTab_lundi = count($tab_lundi);while($i <= $countTab_lundi){ if($tab_lundi[$i]['heure_debut'] == "00:18:30"){echo "<td bgcolor='chocolate'>" .$tab_lundi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mardi)){$i=1;$countTab_mardi = count($tab_mardi);while($i <= $countTab_mardi){if($tab_mardi[$i]['heure_debut'] == "00:18:30"){echo "<td bgcolor='chocolate'>" .$tab_mardi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mercredi)){$i=1;$countTab_mercredi = count($tab_mercredi);while($i <= $countTab_mercredi){if($tab_mercredi[$i]['heure_debut'] == "00:18:30"){echo "<td bgcolor='chocolate'>" .$tab_mercredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_jeudi)){$i=1;$countTab_jeudi = count($tab_jeudi);while($i <= $countTab_jeudi){if($tab_jeudi[$i]['heure_debut'] == "00:18:30"){echo "<td bgcolor='chocolate'>" .$tab_jeudi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_vendredi)){$i=1;$countTab_vendredi = count($tab_vendredi);while($i <= $countTab_vendredi){if($tab_vendredi[$i]['heure_debut'] == "00:18:30"){echo "<td bgcolor='chocolate'>" .$tab_vendredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_samedi)){$i=1;$countTab_samedi = count($tab_samedi);while($i <= $countTab_samedi){if($tab_samedi[$i]['heure_debut'] == "00:18:30"){echo "<td bgcolor='chocolate'>" .$tab_samedi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_dimanche)){$i=1;$countTab_dimanche = count($tab_dimanche);while($i <= $countTab_dimanche){if($tab_dimanche[$i]['heure_debut'] == "00:18:30"){echo "<td bgcolor='chocolate'>" .$tab_dimanche[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
			</tr>
			<tr>
				<td>19h00 - 19h30</td>
				<?php if(!empty($tab_lundi)){$i=1;$countTab_lundi = count($tab_lundi);while($i <= $countTab_lundi){ if($tab_lundi[$i]['heure_debut'] == "00:19:00"){echo "<td bgcolor='chocolate'>" .$tab_lundi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mardi)){$i=1;$countTab_mardi = count($tab_mardi);while($i <= $countTab_mardi){if($tab_mardi[$i]['heure_debut'] == "00:19:00"){echo "<td bgcolor='chocolate'>" .$tab_mardi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mercredi)){$i=1;$countTab_mercredi = count($tab_mercredi);while($i <= $countTab_mercredi){if($tab_mercredi[$i]['heure_debut'] == "00:19:00"){echo "<td bgcolor='chocolate'>" .$tab_mercredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_jeudi)){$i=1;$countTab_jeudi = count($tab_jeudi);while($i <= $countTab_jeudi){if($tab_jeudi[$i]['heure_debut'] == "00:19:00"){echo "<td bgcolor='chocolate'>" .$tab_jeudi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_vendredi)){$i=1;$countTab_vendredi = count($tab_vendredi);while($i <= $countTab_vendredi){if($tab_vendredi[$i]['heure_debut'] == "00:19:00"){echo "<td bgcolor='chocolate'>" .$tab_vendredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_samedi)){$i=1;$countTab_samedi = count($tab_samedi);while($i <= $countTab_samedi){if($tab_samedi[$i]['heure_debut'] == "00:19:00"){echo "<td bgcolor='chocolate'>" .$tab_samedi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_dimanche)){$i=1;$countTab_dimanche = count($tab_dimanche);while($i <= $countTab_dimanche){if($tab_dimanche[$i]['heure_debut'] == "00:19:00"){echo "<td bgcolor='chocolate'>" .$tab_dimanche[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
			</tr>
			<tr>
				<td>19h30 - 20h00</td>
				<?php if(!empty($tab_lundi)){$i=1;$countTab_lundi = count($tab_lundi);while($i <= $countTab_lundi){ if($tab_lundi[$i]['heure_debut'] == "00:19:30"){echo "<td bgcolor='chocolate'>" .$tab_lundi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mardi)){$i=1;$countTab_mardi = count($tab_mardi);while($i <= $countTab_mardi){if($tab_mardi[$i]['heure_debut'] == "00:19:30"){echo "<td bgcolor='chocolate'>" .$tab_mardi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_mercredi)){$i=1;$countTab_mercredi = count($tab_mercredi);while($i <= $countTab_mercredi){if($tab_mercredi[$i]['heure_debut'] == "00:19:30"){echo "<td bgcolor='chocolate'>" .$tab_mercredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_jeudi)){$i=1;$countTab_jeudi = count($tab_jeudi);while($i <= $countTab_jeudi){if($tab_jeudi[$i]['heure_debut'] == "00:19:30"){echo "<td bgcolor='chocolate'>" .$tab_jeudi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_vendredi)){$i=1;$countTab_vendredi = count($tab_vendredi);while($i <= $countTab_vendredi){if($tab_vendredi[$i]['heure_debut'] == "00:19:30"){echo "<td bgcolor='chocolate'>" .$tab_vendredi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_samedi)){$i=1;$countTab_samedi = count($tab_samedi);while($i <= $countTab_samedi){if($tab_samedi[$i]['heure_debut'] == "00:19:30"){echo "<td bgcolor='chocolate'>" .$tab_samedi[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
				<?php if(!empty($tab_dimanche)){$i=1;$countTab_dimanche = count($tab_dimanche);while($i <= $countTab_dimanche){if($tab_dimanche[$i]['heure_debut'] == "00:19:30"){echo "<td bgcolor='chocolate'>" .$tab_dimanche[$i]['lib_soin']. "</td>"; break;}$i++;}}else { echo "<td></td>";}?>
			</tr>
			</table> 
		</div>	
    </div>

      
      <div class="clear"></div>
    </div>
  </section>
  
  <!--==============================footer=================================-->
  <?php include_once $racine .'/borabora/include/footer.php' ?>
       <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</body>
</html>