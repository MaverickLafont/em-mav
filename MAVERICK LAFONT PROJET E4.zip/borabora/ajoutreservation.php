<?php
include('connexion.php');
$date_debut=$_GET['date'];
$heuredebut= '00:'.$_POST['heuredebut'];
$id_soin = $_POST['soin'];
$date_reservation = $_POST['date_reservation'];
if(!empty($date_reservation)){
    $date_debut = $date_reservation;
}
$req_reservation = "insert into reservation(jour_reservation, heure_debut, id_soin) values('$date_debut','".$heuredebut."','".$id_soin."');";
$res_reservation=mysqli_query($cx,$req_reservation);
if($res_reservation)
{
    header('location: reservation.php?reservation=1.php&date='.$date_debut);
} else {
    header('location: reservation.php?reservation=0.php&date='.$date_debut);
}
?>