Cufon.replace('ul.menu li a, .text-1, h2, .text-3, .date strong, .button, .soc-icons span', { fontFamily: 'Bilbo', hover:true});
