-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Lun 09 Juillet 2018 à 18:45
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `sauvegardeborabora`
--

-- --------------------------------------------------------

--
-- Structure de la table `pointage_affaire`
--

CREATE TABLE IF NOT EXISTS `pointage_affaire` (
  `pointage_id` int(10) NOT NULL AUTO_INCREMENT,
  `employe_matricule_affaire` int(11) NOT NULL,
  `date_affaire` date NOT NULL,
  `S` int(11) NOT NULL,
  `validation_RA` tinyint(1) NOT NULL DEFAULT '0',
  `notif` int(11) NOT NULL DEFAULT '0',
  `numero_affaire` varchar(30) DEFAULT NULL,
  `heure_affaire` float(3,1) DEFAULT NULL,
  `prime_nuit` float DEFAULT NULL,
  `prime_divers` float DEFAULT NULL,
  `prime_chef_equipe` float DEFAULT NULL,
  `prime_hauteurM` float DEFAULT NULL,
  `prime_four` float DEFAULT NULL,
  `prime_chaleur` float DEFAULT NULL,
  `prime_insalubrite` float DEFAULT NULL,
  `prime_temps_voyage` int(7) DEFAULT NULL,
  `prime_chauffeur` int(7) DEFAULT NULL,
  `prime_panier` int(1) NOT NULL DEFAULT '0',
  `prime_deplacement` int(7) DEFAULT NULL,
  `absencej` varchar(5) DEFAULT NULL,
  `delegation` float(3,1) DEFAULT NULL,
  `visite_medicale` float(3,1) DEFAULT NULL,
  `formation` float(3,1) DEFAULT NULL,
  PRIMARY KEY (`pointage_id`),
  KEY `fk_matricule_affaire` (`employe_matricule_affaire`),
  KEY `numero_affaire1` (`numero_affaire`),
  KEY `numero_affaire1_2` (`numero_affaire`),
  KEY `employe_matricule_affaire` (`employe_matricule_affaire`),
  KEY `numero_affaire` (`numero_affaire`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=345 ;

--
-- Contenu de la table `pointage_affaire`
--

INSERT INTO `pointage_affaire` (`pointage_id`, `employe_matricule_affaire`, `date_affaire`, `S`, `validation_RA`, `notif`, `numero_affaire`, `heure_affaire`, `prime_nuit`, `prime_divers`, `prime_chef_equipe`, `prime_hauteurM`, `prime_four`, `prime_chaleur`, `prime_insalubrite`, `prime_temps_voyage`, `prime_chauffeur`, `prime_panier`, `prime_deplacement`, `absencej`, `delegation`, `visite_medicale`, `formation`) VALUES
(329, 1077, '2018-07-09', 28, 0, 0, 'B0007.02', 2.0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, '', 0.0, 0.0, 0.0),
(330, 1077, '2018-07-09', 28, 0, 0, 'C0148.02', 2.0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, '', 0.0, 0.0, 0.0),
(332, 1077, '2018-07-09', 28, 0, 0, 'M0006.12', 5.0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, '', 0.0, 0.0, 0.0),
(333, 1077, '2018-07-09', 28, 0, 0, 'M0006.13', 5.0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, '', 0.0, 0.0, 0.0),
(334, 1077, '2018-07-09', 28, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 'CP', 0.0, 0.0, 0.0),
(335, 1077, '2018-07-11', 28, 0, 0, 'E0010.01', 4.0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, '', 0.0, 0.0, 0.0),
(337, 1077, '2018-07-10', 28, 0, 0, 'M0006.12', 4.5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, '', 0.0, 0.0, 0.0),
(342, 1077, '2018-07-09', 28, 0, 0, 'C0148.02', 5.0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, '', 0.0, 0.0, 0.0),
(343, 1077, '2018-07-11', 28, 0, 0, 'E0010.01', 4.0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, '', 0.0, 0.0, 0.0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
